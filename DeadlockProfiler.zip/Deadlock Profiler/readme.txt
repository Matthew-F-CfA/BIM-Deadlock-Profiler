To execute the Deadlock Profiler use the following commands from the Deadlock Profiler root install directory:

For main deadlock profiling:
java bim.deadlock.DeadlockExecutor <absolute file path of root directory where packages to be profiled are located>

If the profiler finishes execution then two files will be created. "Synchronized.txt" which contains each
synchronizable object and its relationship to other synchronizable objects. "Threats.txt" which contains
each conflict of synchronization where deadlock could occur.


For getting an estimate of how long the main deadlock profiling application will take:
java bim.deadlock.DeadlockExecutorCounter <absolute file path of root directory where packages to be profiled are located>

If the profiler finishes execution then two files will be created. "ParsedClassLineCount.txt" which contains
the number of lines parsed in each java file. "ParsedFunctionLineCount.txt" which contains the number of
lines to be parsed in each root execution entry point(execution entry points are "public static void main" and
functions inside interface names that end with "Listener" and functions inside super classes with names that
end with "Adapter").


Inside bim/deadlock/DeadlockExecutor.java and bim/deadlock/DeadlockExecutorCounter.java there are a few
boolean fields that can be used for debugging code. They are: "blnDoShowEntryPoints" if true then each
execution entry point will be printed out as it is executed, "blnDoShowOutput" if true then each instruction
that is parsed will be printed out, "blnDoShowOutputExtended" if true then extended information about each
instruction will be printed out.