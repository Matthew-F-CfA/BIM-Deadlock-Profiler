package bim.deadlock;

import java.io.Serializable;

class PrintOutStringLong
implements Serializable {
  String strStr;
  Long lngLng=new Long(-1l);

  PrintOutStringLong(String strStr, long lngLng) {
    this.strStr=strStr;
    this.lngLng=new Long(lngLng);
  }

  public String getStr() {
    return strStr;
  }

  public void setStr(String strStr) {
    this.strStr=strStr;
  }

  public long getLong() {
    return lngLng.longValue();
  }

  public void setLong(long lngLng) {
    this.lngLng=new Long(lngLng);
  }
}
