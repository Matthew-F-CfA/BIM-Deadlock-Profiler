package bim.deadlock;

import java.io.Serializable;

class PrintOutStringInt
implements Serializable {
  String strStr;
  Integer intInt=new Integer(-1);

  PrintOutStringInt(String strStr, int intInt) {
    this.strStr=strStr;
    this.intInt=new Integer(intInt);
  }

  public String getStr() {
    return strStr;
  }

  public void setStr(String strStr) {
    this.strStr=strStr;
  }

  public int getInt() {
    return intInt.intValue();
  }

  public void setInt(int intInt) {
    this.intInt=new Integer(intInt);
  }
}
