package bim.deadlock;

class StringContainer {
  String strStr;

  StringContainer() {
  }

  StringContainer(String strStr) {
    this.strStr=strStr;
  }

  public String getStr() {
    return strStr;
  }

  public void setStr(String strStr) {
    this.strStr=strStr;
  }
}