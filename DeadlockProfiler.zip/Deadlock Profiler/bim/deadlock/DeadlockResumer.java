package bim.deadlock;

import java.io.*;
import java.util.*;

class DeadlockResumer
implements Serializable {
  static int EXECUTION_LEVEL_TYPE_NEITHER=0;
  static int EXECUTION_LEVEL_TYPE_CONSTRUCTOR=1;
  static int EXECUTION_LEVEL_TYPE_FUNCTION=2;

  static int EXECUTION_LEVEL_INSTRUCTION=0;
  static int EXECUTION_LEVEL_INSTRUCTIONS=1;

  Integer intEntryPointIndex=new Integer(0);
  Integer intStaticInitializerIndex=new Integer(-1);

  Vector vecClassNames=new Vector(); //Elements are String class names
  Vector vecLocalFields=new Vector(); //Elements are Vectors of Vectors based on current brace vectors

  Hashtable hashSynchronized=new Hashtable(); //Keys are SynchronizableKey and Values are SynchronizableObject

  Vector vecBraceInfo=new Vector(); //Elements are BraceInfoObject which contain hashBraceSynchronized and hashBraceMarker
  Hashtable hashBraceSynchronized=new Hashtable(); //Keys are Integer curly brace index and Values are SynchronizableObject
  Hashtable hashBraceMarker=new Hashtable(); //Keys are Integer curly brace index and Values are SynchronizableMarker

  Vector vecSynchronizedThreats=new Vector(); //Elements are String
  Vector vecSynchronizedLocalThreats=new Vector();

  Integer intBraceIndex=new Integer(-1);

  Vector vecExecutingConstructors=new Vector(); //Elements are ConstructorSignature
  Vector vecExecutingFunctions=new Vector(); //Elements are FunctionSignature
  Vector vecExecutingConstructorsMarkers=new Vector(); //Elements are SynchronizableMarker
  Vector vecExecutingFunctionsMarkers=new Vector(); //Elements are SynchronizableMarker

  Hashtable hashClassesLines=new Hashtable(); //Keys are ClassObject and Values are Vector

  Vector vecAbsoluteLineNumbers=new Vector(); //Elements are Integer
  Vector vecInstructionIndices=new Vector(); //Elements are Integer
  Vector vecExecutionLevelType=new Vector(); //Elements are any of EXECUTION_LEVEL_TYPE_NEITHER, EXECUTION_LEVEL_TYPE_CONSTRUCTOR, EXECUTION_LEVEL_TYPE_FUNCTION
  Vector vecExecutionLevel=new Vector(); //Elements are any of EXECUTION_LEVEL_INSTRUCTION or EXECUTION_LEVEL_INSTRUCTIONS

  DeadlockResumer() {
  }

  public boolean hasMoreElements() {
    if(vecClassNames.size()>0)
      return true;

    return false;
  }

  public int getEntryPointIndex() {
    return intEntryPointIndex.intValue();
  }

  public void setEntryPointIndex(int intEntryPointIndex) {
    this.intEntryPointIndex=new Integer(intEntryPointIndex);
  }

  public int getStaticInitializerIndex() {
    return intStaticInitializerIndex.intValue();
  }

  public void setStaticInitializerIndex(int intStaticInitializerIndex) {
    this.intStaticInitializerIndex=new Integer(intStaticInitializerIndex);
  }

  public Vector getClassNames() {
    return vecClassNames;
  }

  public void setClassNames(Vector vecClassNames) {
    this.vecClassNames=vecClassNames;
  }

  public String nextClassName() {
    String strRet=(String)vecClassNames.elementAt(0);
    vecClassNames.removeElementAt(0);

    return strRet;
  }

  public Vector getLocalFields() {
    return vecLocalFields;
  }

  public void setLocalFields(Vector vecLocalFields) {
    this.vecLocalFields=vecLocalFields;
  }

  public Vector nextLocalField() {
    Vector vecRet=(Vector)vecLocalFields.elementAt(0);
    vecLocalFields.removeElementAt(0);

    return vecRet;
  }

  public Hashtable getSynchronized() {
    return hashSynchronized;
  }

  public void setSynchronized(Hashtable hashSynchronized) {
    this.hashSynchronized=hashSynchronized;
  }

  public Vector getBraceInfo() {
    return vecBraceInfo;
  }

  public void setBraceInfo(Vector vecBraceInfo) {
    this.vecBraceInfo=vecBraceInfo;
  }

  public Hashtable getBraceSynchronized() {
    return hashBraceSynchronized;
  }

  public void setBraceSynchronized(Hashtable hashBraceSynchronized) {
    this.hashBraceSynchronized=hashBraceSynchronized;
  }

  public Hashtable getBraceMarker() {
    return hashBraceMarker;
  }

  public void setBraceMarker(Hashtable hashBraceMarker) {
    this.hashBraceMarker=hashBraceMarker;
  }

  public Vector getSynchronizedThreats() {
    return vecSynchronizedThreats;
  }

  public void setSynchronizedThreats(Vector vecSynchronizedThreats) {
    this.vecSynchronizedThreats=vecSynchronizedThreats;
  }

  public Vector getSynchronizedLocalThreats() {
    return vecSynchronizedLocalThreats;
  }

  public void setSynchronizedLocalThreats(Vector vecSynchronizedLocalThreats) {
    this.vecSynchronizedLocalThreats=vecSynchronizedLocalThreats;
  }

  public int getBraceIndex() {
    return intBraceIndex.intValue();
  }

  public void setBraceIndex(int intBraceIndex) {
    this.intBraceIndex=new Integer(intBraceIndex);
  }

  public Vector getExecutingConstructors() {
    return vecExecutingConstructors;
  }

  public void setExecutingConstructors(Vector vecExecutingConstructors) {
    this.vecExecutingConstructors=vecExecutingConstructors;
  }

  public Vector getExecutingFunctions() {
    return vecExecutingFunctions;
  }

  public void setExecutingFunctions(Vector vecExecutingFunctions) {
    this.vecExecutingFunctions=vecExecutingFunctions;
  }

  public Vector getExecutingConstructorsMarkers() {
    return vecExecutingConstructorsMarkers;
  }

  public void setExecutingConstructorsMarkers(Vector vecExecutingConstructorsMarkers) {
    this.vecExecutingConstructorsMarkers=vecExecutingConstructorsMarkers;
  }

  public Vector getExecutingFunctionsMarkers() {
    return vecExecutingFunctionsMarkers;
  }

  public void setExecutingFunctionsMarkers(Vector vecExecutingFunctionsMarkers) {
    this.vecExecutingFunctionsMarkers=vecExecutingFunctionsMarkers;
  }

  public Hashtable getClassesLines() {
    return hashClassesLines;
  }

  public void setClassesLines(Hashtable hashClassesLines) {
    this.hashClassesLines=hashClassesLines;
  }

  public Vector getAbsoluteLineNumbers() {
    return vecAbsoluteLineNumbers;
  }

  public void setAbsoluteLineNumbers(Vector vecAbsoluteLineNumbers) {
    this.vecAbsoluteLineNumbers=vecAbsoluteLineNumbers;
  }

  public int nextAbsoluteLineNumber() {
    int intRet=((Integer)vecAbsoluteLineNumbers.elementAt(0)).intValue();
    vecAbsoluteLineNumbers.removeElementAt(0);

    return intRet;
  }

  public Vector getInstructionIndices() {
    return vecInstructionIndices;
  }

  public void setInstructionIndices(Vector vecInstructionIndices) {
    this.vecInstructionIndices=vecInstructionIndices;
  }

  public int nextInstructionIndex() {
    int intRet=((Integer)vecInstructionIndices.elementAt(0)).intValue();
    vecInstructionIndices.removeElementAt(0);

    return intRet;
  }

  public Vector getExecutionLevelType() {
    return vecExecutionLevelType;
  }

  public void setExecutionLevelType(Vector vecExecutionLevelType) {
    this.vecExecutionLevelType=vecExecutionLevelType;
  }

  public int nextExecutionLevelType() {
    int intRet=((Integer)vecExecutionLevelType.elementAt(0)).intValue();
    vecExecutionLevelType.removeElementAt(0);

    return intRet;
  }

  public int peekExecutionLevelType() {
    return ((Integer)vecExecutionLevelType.elementAt(0)).intValue();
  }

  public Vector getExecutionLevel() {
    return vecExecutionLevel;
  }

  public void setExecutionLevel(Vector vecExecutionLevel) {
    this.vecExecutionLevel=vecExecutionLevel;
  }

  public int nextExecutionLevel() {
    int intRet=((Integer)vecExecutionLevel.elementAt(0)).intValue();
    vecExecutionLevel.removeElementAt(0);

    return intRet;
  }

  public int peekExecutionLevel() {
    return ((Integer)vecExecutionLevel.elementAt(0)).intValue();
  }
}