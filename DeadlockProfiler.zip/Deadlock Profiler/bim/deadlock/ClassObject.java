package bim.deadlock;

import java.util.Vector;
import java.util.Hashtable;
import java.util.Map;
import java.util.Iterator;
import java.io.Serializable;

class ClassObject
implements Serializable {
  String strFilePath="";
  String strClassName;
  Hashtable hashImported=new Hashtable();
  String strSubclass="";
  Vector vecSubclasses=new Vector();
  String strSuperclass="";
  DeadlockConstructorHashtable hashConstructors=new DeadlockConstructorHashtable();
  Hashtable hashInstanceFields=new Hashtable();
  DeadlockFunctionHashtable hashInstanceFunctions=new DeadlockFunctionHashtable();
  Hashtable hashStaticFields=new Hashtable();
  DeadlockFunctionHashtable hashStaticFunctions=new DeadlockFunctionHashtable();
  String strOuterClass="";
  Hashtable hashInstanceInnerClasses=new Hashtable();
  Hashtable hashStaticInnerClasses=new Hashtable();
  Hashtable hashEnums=new Hashtable();
  Vector vecInterfaces=new Vector();

  ClassObject() {
  }

  ClassObject(String strClassName) {
    this.strClassName=strClassName;
  }

  ClassObject(String strClassName, String strSuperclass) {
    this.strClassName=strClassName;
    this.strSuperclass=strSuperclass;
  }

  ClassObject(String strClassName, String strSuperclass, String strOuterClass) {
    this.strClassName=strClassName;
    this.strSuperclass=strSuperclass;
    this.strOuterClass=strOuterClass;
  }

  public String getFilePath() {
    return strFilePath;
  }

  public void setFilePath(String strFilePath) {
    this.strFilePath=strFilePath;
  }

  public String getClassName() {
    return strClassName;
  }

  public void setClassName(String strClassName) {
    this.strClassName=strClassName;
  }

  public Hashtable getImported() {
    return hashImported;
  }

  public void setImported(Hashtable hashImported) {
    this.hashImported=hashImported;
  }

  public Vector getSubclasses() {
    return vecSubclasses;
  }

  public void setSubclasses(Vector vecSubclasses) {
    this.vecSubclasses=vecSubclasses;
  }

  public String getSuperclass() {
    return strSuperclass;
  }

  public void setSuperclass(String strSuperclass) {
    this.strSuperclass=strSuperclass;
  }

  public Hashtable getConstructors() {
    return hashConstructors;
  }

  public void setConstructors(DeadlockConstructorHashtable hashConstructors) {
    this.hashConstructors=hashConstructors;
  }

  public Hashtable getInstanceFields() {
    return hashInstanceFields;
  }

  public void setInstanceFields(Hashtable hashInstanceFields) {
    this.hashInstanceFields=hashInstanceFields;
  }

  public Hashtable getInstanceFunctions() {
    return hashInstanceFunctions;
  }

  public void setInstanceFunctions(DeadlockFunctionHashtable hashInstanceFunctions) {
    this.hashInstanceFunctions=hashInstanceFunctions;
  }

  public Hashtable getStaticFields() {
    return hashStaticFields;
  }

  public void setStaticFields(Hashtable hashStaticFields) {
    this.hashStaticFields=hashStaticFields;
  }

  public Hashtable getStaticFunctions() {
    return hashStaticFunctions;
  }

  public void setStaticFunctions(DeadlockFunctionHashtable hashStaticFunctions) {
    this.hashStaticFunctions=hashStaticFunctions;
  }

  public String getOuterClass() {
    return strOuterClass;
  }

  public void setOuterClass(String strOuterClass) {
    this.strOuterClass=strOuterClass;
  }

  public Hashtable getInstanceInnerClasses() {
    return hashInstanceInnerClasses;
  }

  public void setInstanceInnerClasses(Hashtable hashInstanceInnerClasses) {
    this.hashInstanceInnerClasses=hashInstanceInnerClasses;
  }

  public Hashtable getStaticInnerClasses() {
    return hashStaticInnerClasses;
  }

  public void setStaticInnerClasses(Hashtable hashStaticInnerClasses) {
    this.hashStaticInnerClasses=hashStaticInnerClasses;
  }

  public Hashtable getEnums() {
    return hashEnums;
  }

  public void setEnums(Hashtable hashEnums) {
    this.hashEnums=hashEnums;
  }

  public Vector getInterfaces() {
    return vecInterfaces;
  }

  public void setInterfaces(Vector vecInterfaces) {
    this.vecInterfaces=vecInterfaces;
  }

  public void addInterface(String strInterface) {
    vecInterfaces.addElement(strInterface);
  }

  public FieldObject getFieldObjectByName(String strFieldName, BooleanContainer blnContainer) {
//Hashtable hashStaticFields0=getStaticFields();
//System.out.println("static fields:"+hashStaticFields0.size());
//Iterator iter0=hashStaticFields0.entrySet().iterator();
//while(iter0.hasNext()) {
//Map.Entry mEntry=(Map.Entry)iter0.next();
//System.out.println(mEntry.getKey());
//FieldObject fObj=(FieldObject)mEntry.getValue();
//System.out.println(fObj.getClassName());
//}

    FieldObject fieldObj=null;

    Hashtable hashInstanceFields=getInstanceFields();
    fieldObj=(FieldObject)hashInstanceFields.get(strFieldName);
    if(fieldObj==null) {
      Hashtable hashStaticFields=getStaticFields();
      fieldObj=(FieldObject)hashStaticFields.get(strFieldName);
      if(fieldObj!=null)
        blnContainer.setBln(true);
    }
    else
      blnContainer.setBln(false);

    return fieldObj;
  }

  public FunctionObject getFunctionObjectBySignature(FunctionSignature signature, BooleanContainer blnContainer) {
//Hashtable hashInstanceFunctions0=getInstanceFunctions();
//System.out.println("hashInstanceFunctionsSize: "+getClassName()+":"+hashInstanceFunctions0.size());
//Iterator iter0=hashInstanceFunctions0.entrySet().iterator();
//while(iter0.hasNext()) {
//Map.Entry mEntry=(Map.Entry)iter0.next();
//System.out.println(mEntry.getKey());
//}

    FunctionObject functionObj=null;

    Hashtable hashInstanceFunctions=getInstanceFunctions();
    functionObj=(FunctionObject)hashInstanceFunctions.get(signature);
    if(functionObj==null) {
      Hashtable hashStaticFunctions=getStaticFunctions();
      functionObj=(FunctionObject)hashStaticFunctions.get(signature);
      if(functionObj!=null)
        blnContainer.setBln(true);
    }
    else
      blnContainer.setBln(false);

    return functionObj;
  }

  public static ClassObject merge(ClassObject classInnerObj, ClassObject classObj2) {
    ClassObject classObj3=new ClassObject();


    classObj3.strFilePath=classInnerObj.strFilePath;
    classObj3.strClassName=classInnerObj.strClassName;
    classObj3.hashImported=classObj2.hashImported;
    classObj3.strSubclass=classInnerObj.strSubclass;
    classObj3.vecSubclasses=classInnerObj.vecSubclasses;
    classObj3.strSuperclass=classInnerObj.strSuperclass;
    classObj3.hashConstructors=classInnerObj.hashConstructors;

    Hashtable hashInstanceFields=new Hashtable();
    Iterator iter=classInnerObj.hashInstanceFields.entrySet().iterator();
    while(iter.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iter.next();
      hashInstanceFields.put(mEntry.getKey(), mEntry.getValue());
    }
    iter=classObj2.hashInstanceFields.entrySet().iterator();
    while(iter.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iter.next();
      hashInstanceFields.put(mEntry.getKey(), mEntry.getValue());
    }
    classObj3.hashInstanceFields=hashInstanceFields;

    DeadlockFunctionHashtable hashInstanceFunctions=new DeadlockFunctionHashtable();
    iter=classInnerObj.hashInstanceFunctions.entrySet().iterator();
    while(iter.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iter.next();
      hashInstanceFunctions.put(mEntry.getKey(), mEntry.getValue());
    }
    iter=classObj2.hashInstanceFunctions.entrySet().iterator();
    while(iter.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iter.next();
      hashInstanceFunctions.put(mEntry.getKey(), mEntry.getValue());
    }
    classObj3.hashInstanceFunctions=hashInstanceFunctions;

/*
    Hashtable hashStaticFields=new Hashtable();
    iter=classInnerObj.hashStaticFields.entrySet().iterator();
    while(iter.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iter.next();
      hashStaticFields.put(mEntry.getKey(), mEntry.getValue());
    }
*/
/*
    iter=classObj2.hashStaticFields.entrySet().iterator();
    while(iter.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iter.next();
      hashStaticFields.put(mEntry.getKey(), mEntry.getValue());
    }
*/
    classObj3.hashStaticFields=classInnerObj.hashStaticFields;


/*
    Hashtable hashStaticFunctions=new Hashtable();
    iter=classInnerObj.hashStaticFunctions.entrySet().iterator();
    while(iter.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iter.next();
      hashStaticFunctions.put(mEntry.getKey(), mEntry.getValue());
    }
*/
/*
    iter=classObj2.hashStaticFunctions.entrySet().iterator();
    while(iter.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iter.next();
      hashStaticFunctions.put(mEntry.getKey(), mEntry.getValue());
    }
*/
    classObj3.hashStaticFunctions=classInnerObj.hashStaticFunctions;

    classObj3.strOuterClass=classInnerObj.strOuterClass;

    Hashtable hashEnumsInner=classInnerObj.getEnums();
    Hashtable hashEnumsOuter=classObj2.getEnums();
    Hashtable hashEnumsMerged=classObj3.getEnums();
    Iterator iterEnumsInner=hashEnumsInner.entrySet().iterator();
    while(iterEnumsInner.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iterEnumsInner.next();

      hashEnumsMerged.put(mEntry.getKey(), mEntry.getValue());
    }
    Iterator iterEnumsOuter=hashEnumsOuter.entrySet().iterator();
    while(iterEnumsOuter.hasNext()) {
      Map.Entry mEntry=(Map.Entry)iterEnumsOuter.next();

      hashEnumsMerged.put(mEntry.getKey(), mEntry.getValue());
    }

    classObj3.vecInterfaces=classInnerObj.vecInterfaces;


    return classObj3;
  }
}