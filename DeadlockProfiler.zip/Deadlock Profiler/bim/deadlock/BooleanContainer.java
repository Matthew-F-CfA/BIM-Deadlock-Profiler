package bim.deadlock;

class BooleanContainer {
  boolean blnBln=false;

  BooleanContainer() {
  }

  BooleanContainer(boolean blnBln) {
    this.blnBln=blnBln;
  }

  public boolean getBln() {
    return blnBln;
  }

  public void setBln(boolean blnBln) {
    this.blnBln=blnBln;
  }
}