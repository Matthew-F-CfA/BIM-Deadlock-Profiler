package bim.deadlock;

import java.util.Vector;
import java.util.Hashtable;
import java.util.Map;
import java.util.Iterator;
import java.util.Arrays;
import java.io.*;
import java.lang.reflect.*;
import java.net.URL;
import java.net.URLClassLoader;

class DeadlockExecutorCounter {
  static Hashtable hashClasses=new Hashtable();
  static Hashtable hashPackages=new Hashtable();
  static Vector vecImportedLocal=new Vector();
  static Hashtable hashImported=new Hashtable();
  static String strFilePath="";
  static String strPackage="";
  static Vector vecExecutionEntryPoints=new Vector();
  static Vector vecExecutionStaticInitializers=new Vector();
  static Hashtable hashSynchronized=new Hashtable(); //Keys are SynchronizableKey and Values are SynchronizableObject
  static Hashtable hashBraceSynchronized=new Hashtable(); //Keys are Integer curly brace index and Values are SynchronizableObject
  static Hashtable hashBraceMarker=new Hashtable(); //Keys are Integer curly brace index and Values are SynchronizableMarker
  static int intBraceIndex=-1;
//  static String strDoExecuteCommandNewOuterClass="";
  static boolean blnDoShowEntryPoints=true;
  static boolean blnDoShowOutput=false;
  static boolean blnDoShowOutputExtended=false;

  static Hashtable hashFunctionCountsEntryPoint=new Hashtable();
  static Vector vecCounts=new Vector();
  static Hashtable hashConstructorCounts=new Hashtable();
  static Hashtable hashFunctionCounts=new Hashtable();

//  static Vector vecExecutedConstructors=new Vector();
//  static Vector vecExecutedFunctions=new Vector();
  static Vector vecExecutingConstructors=new Vector();
  static Vector vecExecutingFunctions=new Vector();

  static Hashtable hashClassesLines=new Hashtable();

/*
static int intPrevInstruction[]=new int[10];
static String strPrevInstruction[]=new String[10];
static int intPrevInstructionIndex=0;

static Vector vecAllInstructionsIndex=new Vector();
static Vector vecAllInstructionsString=new Vector();
*/

//static Vector vecExecutedInstructions=new Vector();


  public static void main(String args[]) {
    try {
      if(args.length==0) {
        System.out.println("Usage:");
        System.out.println("  java bim.deadlock.DeadlockExecutorCounter <folder 0> <folder 1> <folder 2>...");
        System.out.println("Each folder should be the directory containing package roots.");

        return;
      }

//BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream(new File("checkpoints.txt"))));
//String strNextLine="";
//while((strNextLine=br.readLine())!=null)
//vecExecutedInstructions.addElement(strNextLine);
//br.close();


      ObjectInputStream ois=new ObjectInputStream(new FileInputStream(new File("builtInPackageClasses")));
      hashPackages=(Hashtable)ois.readObject();
      ois.close();

      Vector vecFolders=new Vector();
      for(int i=0;i<args.length;i++) {
        File nextFile=new File(args[i]);
        if(!nextFile.exists())
          continue;

        if(nextFile.isFile())
          continue;

        String strFile=nextFile.getAbsolutePath();
        if(vecFolders.contains(strFile))
          continue;

        vecFolders.addElement(strFile);
      }

      for(int i=0;i<vecFolders.size();i++)
        appendImportedLocal((String)vecFolders.elementAt(i));


      for(int i=0;i<vecFolders.size();i++)
        addPath((String)vecFolders.elementAt(i));


      for(int i=0;i<vecFolders.size();i++)
        parseClassFolder((String)vecFolders.elementAt(i));


      Vector vecClasses=new Vector();
      Iterator iter=hashClasses.entrySet().iterator();
      while(iter.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter.next();
        vecClasses.addElement(mEntry.getValue());
      }

      for(int i=0;i<vecClasses.size();i++) {
        ClassObject classObj=(ClassObject)vecClasses.elementAt(i);
        String strClassName=classObj.getClassName();
        Class class0=Class.forName(strClassName);

        Vector vecSubclasses=new Vector();

        for(int ia=0;ia<i;ia++) {
          ClassObject classObj2=(ClassObject)vecClasses.elementAt(ia);
          String strClassName2=classObj2.getClassName();
          Class class1=Class.forName(strClassName2);

          try {
            class1.asSubclass(class0);

            vecSubclasses.addElement(strClassName2);
          }
          catch(Exception ex) {
          }
        }
        for(int ia=i+1;ia<vecClasses.size();ia++) {
          ClassObject classObj2=(ClassObject)vecClasses.elementAt(ia);
          String strClassName2=classObj2.getClassName();
          Class class1=Class.forName(strClassName2);

          try {
            class1.asSubclass(class0);

            vecSubclasses.addElement(strClassName2);
          }
          catch(Exception ex) {
          }
        }

        classObj.setSubclasses(vecSubclasses);

        Vector vecInterfaces=classObj.getInterfaces();
        for(int ia=0;ia<vecInterfaces.size();ia++) {
          String strNextInterface=(String)vecInterfaces.elementAt(ia);

          do {

            ClassObject classObj2=(ClassObject)hashClasses.get(strNextInterface);

            if(classObj2==null) {
              Class classBuiltIn=Class.forName(strNextInterface);

              Field fieldsBuiltIn[]=classBuiltIn.getDeclaredFields();

              for(int iz=0;iz<fieldsBuiltIn.length;iz++) {
                String strFieldClass=fieldsBuiltIn[iz].getType().getName();
                strFieldClass=FieldObject.convertFromBuiltInClassToDeadlockProfilerClass(strFieldClass);

                String strFieldName=fieldsBuiltIn[iz].getName();

                FieldObject fieldObj=new FieldObject(strFieldName, strFieldClass, classObj.getOuterClass());

                classObj.getInstanceFields().put(strFieldName, fieldObj);
              
                for(int iz2=0;iz2<vecSubclasses.size();iz2++) {
                  String strNextSubclass=(String)vecSubclasses.elementAt(iz2);
                  ClassObject classNextSubclass=(ClassObject)hashClasses.get(strNextSubclass);

                  fieldObj=new FieldObject(strFieldName, strFieldClass, classNextSubclass.getOuterClass());

                  classNextSubclass.getInstanceFields().put(strFieldName, fieldObj);
                }
              }

              Class classBuiltInSuper[]=classBuiltIn.getInterfaces();

              if(classBuiltInSuper.length==0)
                break;

              strNextInterface=classBuiltInSuper[0].getName();
            }
            else {
              Hashtable hashInstanceFields=classObj2.getInstanceFields();

              Iterator iterZ=hashInstanceFields.entrySet().iterator();
              while(iterZ.hasNext()) {
                Map.Entry mEntry=(Map.Entry)iterZ.next();

                classObj.getInstanceFields().put(mEntry.getKey(), mEntry.getValue());

                for(int iz=0;iz<vecSubclasses.size();iz++) {
                  String strNextSubclass=(String)vecSubclasses.elementAt(iz);
                  ClassObject classNextSubclass=(ClassObject)hashClasses.get(strNextSubclass);

                  classNextSubclass.getInstanceFields().put(mEntry.getKey(), mEntry.getValue());
                }
              }

              strNextInterface=classObj2.getSuperclass();

              if(strNextInterface.length()==0)
                break;
            }

          } while(true);
        }
      }


      for(int i=0;i<vecExecutionEntryPoints.size();i++)
        executeEntryPoint((ExecutionEntryPoint)vecExecutionEntryPoints.elementAt(i));

      for(int i=0;i<vecExecutionStaticInitializers.size();i++)
        executeStaticInitializer((StaticInitializerObject)vecExecutionStaticInitializers.elementAt(i));


      PrintOutStringInt printOSI[]=new PrintOutStringInt[hashClassesLines.size()];

      int intTotalLines=0;

      int intCountLines=0;

      int intCountIter=0;

      Iterator iter0=hashClassesLines.entrySet().iterator();
      while(iter0.hasNext()) {
        intCountLines=0;

        Map.Entry mEntry=(Map.Entry)iter0.next();

        Vector vecClassLines=(Vector)mEntry.getValue();

        for(int i=0;i<vecClassLines.size();i++) {
          boolean blnLineRead=((Boolean)vecClassLines.elementAt(i)).booleanValue();
          if(blnLineRead)
            ++intCountLines;
        }

        String strClassName=(String)mEntry.getKey();

        printOSI[intCountIter++]=new PrintOutStringInt(strClassName, intCountLines);
//        System.out.println(strClassName+":"+intCountLines);

        intTotalLines+=intCountLines;
      }

      Arrays.sort(printOSI, new PrintOutStringIntComparator());

      File fileParsed=new File("ParsedClassLineCount.txt");
      if(fileParsed.exists()) {
        fileParsed.delete();
      }
        
      RandomAccessFile raf=new RandomAccessFile(fileParsed, "rw");

      for(int i=0;i<printOSI.length;i++) {
        raf.writeBytes(printOSI[i].getStr()+":"+String.valueOf(printOSI[i].getInt()));
        raf.write(13);
        raf.write(10);
        raf.write(13);
        raf.write(10);
//        System.out.println(printOSI[i].getStr()+":"+printOSI[i].getInt());
      }

      raf.close();

      System.out.println("\n\nLines Parsed: "+intTotalLines);




      PrintOutStringLong printOSL[]=new PrintOutStringLong[hashFunctionCountsEntryPoint.size()];

      intCountIter=0;

      iter0=hashFunctionCountsEntryPoint.entrySet().iterator();
      while(iter0.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter0.next();

        printOSL[intCountIter++]=new PrintOutStringLong(mEntry.getKey().toString(), ((Long)mEntry.getValue()).longValue());
//        System.out.println(mEntry.getKey());
//        System.out.println(mEntry.getValue()+"\n");
      }

      Arrays.sort(printOSL, new PrintOutStringLongComparator());

      File fileCounted=new File("ParsedFunctionLineCount.txt");
      if(fileCounted.exists()) {
        fileCounted.delete();
      }
        
      raf=new RandomAccessFile(fileCounted, "rw");

      for(int i=0;i<printOSL.length;i++) {
        raf.writeBytes(printOSL[i].getStr()+":"+String.valueOf(printOSL[i].getLong()));
        raf.write(13);
        raf.write(10);
        raf.write(13);
        raf.write(10);
//        System.out.println(printOSL[i].getStr()+":"+printOSL[i].getLong());
      }

      raf.close();

/*
      File fileSynchronized=new File("Synchronized.txt");
      if(fileSynchronized.exists()) {
        fileSynchronized.delete();

//        System.out.println("\nFile \"Synchronized.txt\" already exists. If you want synchronizable profile then delete the file \"Synchronized.txt\" and execute DeadlockExecutorCounter again.");
//        return;
      }
        
      raf=new RandomAccessFile(fileSynchronized, "rw");

      iter0=hashSynchronized.entrySet().iterator();
      while(iter0.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iter0.next();

        SynchronizableObject sObj=(SynchronizableObject)mEntry.getValue();
        SynchronizableKey sKey=sObj.getKey();

        if(sKey.getClassName()==null)
          raf.writeBytes("local:"+sKey.getFieldName());
        else
          raf.writeBytes(sKey.getClassName()+":"+sKey.getFieldName());
        raf.write(13);
        raf.write(10);

        raf.writeBytes("Higher Priority:");
        raf.write(13);
        raf.write(10);

        Vector vecHigherPriority=sObj.getHigherPriority();

        if(vecHigherPriority.size()==0) {
          raf.write(13);
          raf.write(10);
        }

        for(int i=0;i<vecHigherPriority.size();i++) {
          SynchronizableObject sObj2=(SynchronizableObject)vecHigherPriority.elementAt(i);

          SynchronizableKey sKey2=sObj2.getKey();

          if(sKey2.getClassName()==null)
            raf.writeBytes("  local:"+sKey2.getFieldName());
          else
            raf.writeBytes("  "+sKey2.getClassName()+":"+sKey2.getFieldName());
          raf.write(13);
          raf.write(10);
        }

        if(vecHigherPriority.size()>0) {
          raf.write(13);
          raf.write(10);
        }

        raf.writeBytes("Lower Priority:");
        raf.write(13);
        raf.write(10);

        Vector vecLowerPriority=sObj.getLowerPriority();

        if(vecLowerPriority.size()==0) {
          raf.write(13);
          raf.write(10);
        }

        for(int i=0;i<vecLowerPriority.size();i++) {
          SynchronizableObject sObj2=(SynchronizableObject)vecLowerPriority.elementAt(i);

          SynchronizableKey sKey2=sObj2.getKey();

          if(sKey2.getClassName()==null)
            raf.writeBytes("  local:"+sKey2.getFieldName());
          else
            raf.writeBytes("  "+sKey2.getClassName()+":"+sKey2.getFieldName());
          raf.write(13);
          raf.write(10);
        }

        if(vecLowerPriority.size()>0) {
          raf.write(13);
          raf.write(10);
        }
      }

      raf.close();
*/

    }
    catch(Exception ex) {
//      System.out.println(ex);
      ex.printStackTrace();
    }
  }

  DeadlockExecutorCounter() {
  }

  public static void addPath(String s) throws Exception {
    File f=new File(s);
    URL u=f.toURI().toURL();
    URLClassLoader urlClassLoader=(URLClassLoader)ClassLoader.getSystemClassLoader();
    Class urlClass=URLClassLoader.class;
    Class classParameters[]=new Class[1];
    classParameters[0]=URL.class;
    Method method=urlClass.getDeclaredMethod("addURL", classParameters);
//    Method method=urlClass.getDeclaredMethod("addURL", new Class[]{URL.class});
    method.setAccessible(true);
    Object objParameters[]=new Object[1];
    objParameters[0]=u;
    method.invoke(urlClassLoader, objParameters);
  }

  public static void appendImportedLocal(String strFolderPath) throws Exception {
    File fileFolder=new File(strFolderPath);

    Vector vecClasses=new Vector();

    File fileFiles[]=fileFolder.listFiles();
    for(int i=0;i<fileFiles.length;i++) {
      if(fileFiles[i].isDirectory())
        appendImportedLocal(fileFiles[i].getAbsolutePath(), fileFiles[i].getName()+".");
      else {
        String strFileName=fileFiles[i].getName();
        if(strFileName.endsWith(".java")) {
          Vector vecClasses0=appendImportedLocalFile(fileFiles[i].getAbsolutePath(), "");
          for(int ia=0;ia<vecClasses0.size();ia++)
            vecClasses.addElement(vecClasses0.elementAt(ia));
        }
      }
    }

    hashPackages.put("*", vecClasses);
  }

  public static void appendImportedLocal(String strFolderPath, String strPackagePath) throws Exception {
    File fileFolder=new File(strFolderPath);

    Vector vecClasses=new Vector();

    File fileFiles[]=fileFolder.listFiles();
    for(int i=0;i<fileFiles.length;i++) {
      if(fileFiles[i].isDirectory())
        appendImportedLocal(fileFiles[i].getAbsolutePath(), strPackagePath+fileFiles[i].getName()+".");
      else {
        String strFileName=fileFiles[i].getName();
        if(strFileName.endsWith(".java")) {
          Vector vecClasses0=appendImportedLocalFile(fileFiles[i].getAbsolutePath(), strPackagePath);
          for(int ia=0;ia<vecClasses0.size();ia++)
            vecClasses.addElement(vecClasses0.elementAt(ia));
        }
      }
    }

    hashPackages.put(strPackagePath+"*", vecClasses);
  }

  public static Vector appendImportedLocalFile(String strFilePath, String strPackagePath) throws Exception {
    Vector vecClasses=new Vector();

    File fileFile=new File(strFilePath);

    BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream(fileFile)));

    String strFileName=fileFile.getName();
    strFileName=strFileName.substring(0, strFileName.length()-5);

    String strFullClassName=strPackagePath+strFileName;

    if(vecImportedLocal.contains(strFullClassName))
      throw new Exception("Duplicate full class with package paths for file: "+strFilePath);
    else {
      vecImportedLocal.addElement(strFullClassName);
      vecClasses.addElement(strFullClassName);
    }

    String strNextLine="";
    while((strNextLine=br.readLine())!=null) {
      int intIndex=strNextLine.indexOf("class");
      if(intIndex==-1)
        continue;

      intIndex+=6;

      int intIndex2=strNextLine.indexOf(" ", intIndex);
      if(intIndex2==-1)
        intIndex2=strNextLine.length();

      String strClassName=strNextLine.substring(intIndex, intIndex2);

      if(strClassName.equals(strFileName))
        continue;

      try {
        Class class0=Class.forName(strFullClassName+"$"+strClassName);

        if(!vecImportedLocal.contains(strFullClassName+"$"+strClassName)) {
          vecImportedLocal.addElement(strFullClassName+"$"+strClassName);
          vecClasses.addElement(strFullClassName+"$"+strClassName);
        }
      }
      catch(Exception ex) {
      }
    }

    br.close();

    return vecClasses;
  }

  public static void parseClassFolder(String strFolderPath) throws Exception {
    File fileFolder=new File(strFolderPath);

    Vector vecPackagePath=new Vector();

    File fileFiles[]=fileFolder.listFiles();
    for(int i=0;i<fileFiles.length;i++) {
      if(fileFiles[i].isDirectory()) {
        String strFileName=fileFiles[i].getName();
        vecPackagePath.addElement(strFileName);
        parseClassFolder(fileFiles[i].getAbsolutePath(), vecPackagePath);
        vecPackagePath.removeElementAt(vecPackagePath.size()-1);
      }
      else {
        parseClassFile(fileFiles[i].getAbsolutePath(), vecPackagePath);
      }
    }
  }

  public static void parseClassFolder(String strFolderPath, Vector vecPackagePath) throws Exception {
    File fileFolder=new File(strFolderPath);

    File fileFiles[]=fileFolder.listFiles();
    for(int i=0;i<fileFiles.length;i++) {
      if(fileFiles[i].isDirectory()) {
        String strFileName=fileFiles[i].getName();
        vecPackagePath.addElement(strFileName);
        parseClassFolder(fileFiles[i].getAbsolutePath(), vecPackagePath);
        vecPackagePath.removeElementAt(vecPackagePath.size()-1);
      }
      else {
        parseClassFile(fileFiles[i].getAbsolutePath(), vecPackagePath);
      }
    }
  }

  public static void parseClassFile(String strFilePath, Vector vecPackagePath) throws Exception {
    if(!strFilePath.endsWith(".java"))
      return;

    DeadlockExecutorCounter.strFilePath=strFilePath.toString();

    File fileFile=new File(strFilePath);

    String strNextLine="";

    Vector vecLines=new Vector();
    byte byteNewLineBuf[]=new String("\n").getBytes();
    int intNewLineLength=byteNewLineBuf.length;


    int intByteCount=0;

    int intAbsoluteLineNumber=1;

    Vector vecClassLines=new Vector();

//parse out characters

    BufferedReader br0=new BufferedReader(new InputStreamReader(new FileInputStream(fileFile)));
    while((strNextLine=br0.readLine())!=null) {
      ++intAbsoluteLineNumber;

      vecClassLines.addElement(new Boolean(false));

      StringBuffer sBuf=new StringBuffer();


      while(true) {
        if(strNextLine.length()==0)
          break;

        char chr=strNextLine.charAt(0);
        strNextLine=strNextLine.substring(1);

        sBuf.append(chr);

        if(chr=='\"') {
          while(true) {
            if(strNextLine.length()==0)
              throw new Exception("Double quotes must be kept in a single line for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
            chr=strNextLine.charAt(0);
            strNextLine=strNextLine.substring(1);

            sBuf.append(chr);

            if(chr=='\\') {
              sBuf.append(strNextLine.charAt(0));

              strNextLine=strNextLine.substring(1);
            }
            else if(chr=='\"') {
              break;
            }
          }

          continue;
        }

        if(chr=='\'') {
          chr=strNextLine.charAt(0);
          if(chr=='\\') {
            strNextLine=strNextLine.substring(3);
          }
          else {
            strNextLine=strNextLine.substring(2);
          }

          sBuf.append('a');
          sBuf.append('\'');
        }
      }

      strNextLine=sBuf.toString();

      vecLines.addElement(strNextLine);
      intByteCount+=strNextLine.length()+intNewLineLength;
    }

    byte byteBuf[]=new byte[intByteCount];
    intByteCount=0;
    for(int i=0;i<vecLines.size();i++) {
      strNextLine=(String)vecLines.elementAt(i);
      byte byteNextLine[]=strNextLine.getBytes();
      System.arraycopy(byteNextLine, 0, byteBuf, intByteCount, byteNextLine.length);
      intByteCount+=byteNextLine.length;
      System.arraycopy(byteNewLineBuf, 0, byteBuf, intByteCount, intNewLineLength);
      intByteCount+=intNewLineLength;
    }


    vecLines.removeAllElements();

    intByteCount=0;

    intAbsoluteLineNumber=1;

//parse out strings

    br0=new BufferedReader(new InputStreamReader(new ByteArrayInputStream(byteBuf)));
    while((strNextLine=br0.readLine())!=null) {
//System.out.println("strNextLine:"+strNextLine);
      StringBuffer sBuf=new StringBuffer();

      while(true) {
        if(strNextLine.length()==0)
          break;

        char chr=strNextLine.charAt(0);
        strNextLine=strNextLine.substring(1);

        sBuf.append(chr);

        if(chr=='\"') {
//System.out.println("strNextLine:"+strNextLine);
          while(true) {
            chr=strNextLine.charAt(0);
            strNextLine=strNextLine.substring(1);

            if(chr=='\\') {
              strNextLine=strNextLine.substring(1);
            }
            else if(chr=='\"') {
              sBuf.append('\"');
              break;
            }
          }
        }
      }

//      ++intAbsoluteLineNumber;

      strNextLine=sBuf.toString();

      vecLines.addElement(strNextLine);
      intByteCount+=strNextLine.length()+intNewLineLength;
    }

    byteBuf=new byte[intByteCount];
    intByteCount=0;
    for(int i=0;i<vecLines.size();i++) {
      strNextLine=(String)vecLines.elementAt(i);
      byte byteNextLine[]=strNextLine.getBytes();
      System.arraycopy(byteNextLine, 0, byteBuf, intByteCount, byteNextLine.length);
      intByteCount+=byteNextLine.length;
      System.arraycopy(byteNewLineBuf, 0, byteBuf, intByteCount, intNewLineLength);
      intByteCount+=intNewLineLength;
    }


    vecLines.removeAllElements();

    intByteCount=0;

    intAbsoluteLineNumber=1;

//parse out comments

    br0=new BufferedReader(new InputStreamReader(new ByteArrayInputStream(byteBuf)));
    while((strNextLine=br0.readLine())!=null) {
      int intIndexComment=strNextLine.indexOf("/*");
      if(intIndexComment!=-1 && intIndexComment!=0) {
        throw new Exception("Multiline comment \"/*\" encountered and it isn't at the start of the line for file: "+strFilePath+":"+intAbsoluteLineNumber);
      }

      ++intAbsoluteLineNumber;

      if(intIndexComment==0) {
        vecLines.addElement(new String(""));
        intByteCount+=intNewLineLength;

        while((strNextLine=br0.readLine())!=null) {
          int intIndexComment3=strNextLine.indexOf("*/");
          if(intIndexComment3!=-1 && intIndexComment3!=0) {
            throw new Exception("Multiline comment \"*/\" encountered and it isn't at the start of the line for file: "+strFilePath+":"+intAbsoluteLineNumber);
          }

          ++intAbsoluteLineNumber;

          vecLines.addElement(new String(""));
          intByteCount+=intNewLineLength;

          if(intIndexComment3==0) {
            break;
          }
        }

        continue;
      }

      int intIndexComment2=strNextLine.indexOf("//");

      if(intIndexComment2>=0)
        strNextLine=strNextLine.substring(0, intIndexComment2);

      vecLines.addElement(strNextLine);
      intByteCount+=strNextLine.length()+intNewLineLength;
    }

    byteBuf=new byte[intByteCount];
    intByteCount=0;
    for(int i=0;i<vecLines.size();i++) {
      strNextLine=(String)vecLines.elementAt(i);
      byte byteNextLine[]=strNextLine.getBytes();
      System.arraycopy(byteNextLine, 0, byteBuf, intByteCount, byteNextLine.length);
      intByteCount+=byteNextLine.length;
      System.arraycopy(byteNewLineBuf, 0, byteBuf, intByteCount, intNewLineLength);
      intByteCount+=intNewLineLength;
    }


    vecLines.removeAllElements();

    intByteCount=0;

    intAbsoluteLineNumber=1;

//parse out anonymous inner classes

    br0=new BufferedReader(new InputStreamReader(new ByteArrayInputStream(byteBuf)));
    while((strNextLine=br0.readLine())!=null) {
      ++intAbsoluteLineNumber;

      int intIndexNew=strNextLine.indexOf("new ");

      if(intIndexNew==-1) {
        vecLines.addElement(strNextLine);
        intByteCount+=strNextLine.length()+intNewLineLength;
        continue;
      }
      else {
        int intIndexParenthesis=strNextLine.indexOf("(", intIndexNew);
        if(intIndexParenthesis==-1) {
          vecLines.addElement(strNextLine);
          intByteCount+=strNextLine.length()+intNewLineLength;
          continue;
        }

        int intIndexBracket=strNextLine.indexOf("[", intIndexNew);
        if(intIndexBracket==-1)
          intIndexBracket=Integer.MAX_VALUE;

        if(intIndexBracket<intIndexParenthesis) {
          vecLines.addElement(strNextLine);
          intByteCount+=strNextLine.length()+intNewLineLength;
          continue;
        }

        int intParenthesisCount=1;

        ++intIndexParenthesis;

        while(true) {
          char chr=strNextLine.charAt(intIndexParenthesis);

          if(chr=='(') {
            ++intParenthesisCount;
          }
          else if(chr==')') {
            --intParenthesisCount;

            if(intParenthesisCount==0)
              break;
          }

          ++intIndexParenthesis;
        }

        ++intIndexParenthesis;

        char chr='a';
        while(true) {
          chr=strNextLine.charAt(intIndexParenthesis);

          if(chr!=' ')
            break;

          ++intIndexParenthesis;
        }

        if(chr!='{') {
          vecLines.addElement(strNextLine);
          intByteCount+=strNextLine.length()+intNewLineLength;
          continue;
        }
      }

      int intParenthesisCount=0;

      for(int i=0;i<intIndexNew;i++) {
        char chr=strNextLine.charAt(i);
 
        if(chr=='(') {
          ++intParenthesisCount;
        }
        else if(chr==')') {
          --intParenthesisCount;
        }
      }

      if(intParenthesisCount==0) {
        int intLastBrace=strNextLine.lastIndexOf("{");

        if(intLastBrace==-1) {
          vecLines.addElement(strNextLine);
          intByteCount+=strNextLine.length()+intNewLineLength;
          continue;
        }
        else {
          int intBraceCount=1;

          int intLastParenthesis=strNextLine.lastIndexOf(")");

          strNextLine=strNextLine.substring(0, intLastParenthesis+1);
          strNextLine+=";";
          vecLines.addElement(strNextLine);
          intByteCount+=strNextLine.length()+intNewLineLength;

          while((strNextLine=br0.readLine())!=null) {
            ++intAbsoluteLineNumber;

            int intIndexBraceOpen=strNextLine.indexOf("{");
            int intIndexBraceClose=strNextLine.indexOf("}");

            if(intIndexBraceOpen!=-1) {
              ++intBraceCount;
            }
            else if(intIndexBraceClose!=-1) {
              --intBraceCount;

              if(intBraceCount==0)
                break;
            }

            String strNextLine0="";
            vecLines.addElement(strNextLine0);
            intByteCount+=strNextLine0.length()+intNewLineLength;
            continue;
          }

          String strNextLine0="";
          vecLines.addElement(strNextLine0);
          intByteCount+=strNextLine0.length()+intNewLineLength;
          continue;
        }
      }
      else if(intParenthesisCount==1) {
        int intLastBrace=strNextLine.lastIndexOf("{");

        if(intLastBrace==-1) {
          vecLines.addElement(strNextLine);
          intByteCount+=strNextLine.length()+intNewLineLength;
          continue;
        }
        else {
          int intBraceCount=1;

          int intLastParenthesis=strNextLine.lastIndexOf(")");

          strNextLine=strNextLine.substring(0, intLastParenthesis+1);
          strNextLine+=");";
          vecLines.addElement(strNextLine);
          intByteCount+=strNextLine.length()+intNewLineLength;

          while((strNextLine=br0.readLine())!=null) {
            ++intAbsoluteLineNumber;

            int intIndexBraceOpen=strNextLine.indexOf("{");
            int intIndexBraceClose=strNextLine.indexOf("}");

            if(intIndexBraceOpen!=-1) {
              ++intBraceCount;
            }
            else if(intIndexBraceClose!=-1) {
              --intBraceCount;

              if(intBraceCount==0)
                break;
            }

            String strNextLine0="";
            vecLines.addElement(strNextLine0);
            intByteCount+=strNextLine0.length()+intNewLineLength;
            continue;
          }

          String strNextLine0="";
          vecLines.addElement(strNextLine0);
          intByteCount+=strNextLine0.length()+intNewLineLength;
          continue;
        }
      }
      else {
        throw new Exception("Encountered an anonymous inner class with parenthesis depth greater than 1 for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
      }
    }

    byteBuf=new byte[intByteCount];
    intByteCount=0;
    for(int i=0;i<vecLines.size();i++) {
      strNextLine=(String)vecLines.elementAt(i);
      byte byteNextLine[]=strNextLine.getBytes();
      System.arraycopy(byteNextLine, 0, byteBuf, intByteCount, byteNextLine.length);
      intByteCount+=byteNextLine.length;
      System.arraycopy(byteNewLineBuf, 0, byteBuf, intByteCount, intNewLineLength);
      intByteCount+=intNewLineLength;
    }


    vecLines.removeAllElements();

    intByteCount=0;

    intAbsoluteLineNumber=1;


/*
System.out.println("before trim string");
    vecLines.removeAllElements();
    intByteCount=0;

//    intAbsoluteLineNumber=1;

    br0=new BufferedReader(new InputStreamReader(new ByteArrayInputStream(byteBuf)));
    while((strNextLine=br0.readLine())!=null) {
System.out.println(strNextLine);
      strNextLine=trimString(strNextLine);
System.out.println(strNextLine);

      vecLines.addElement(strNextLine);
      intByteCount+=strNextLine.length()+intNewLineLength;
    }

System.out.println("after trim string");

    byteBuf=new byte[intByteCount];
    intByteCount=0;
    for(int i=0;i<vecLines.size();i++) {
      strNextLine=(String)vecLines.elementAt(i);
      byte byteNextLine[]=strNextLine.getBytes();
      System.arraycopy(byteNextLine, 0, byteBuf, intByteCount, byteNextLine.length);
      intByteCount+=byteNextLine.length;
      System.arraycopy(byteNewLineBuf, 0, byteBuf, intByteCount, intNewLineLength);
      intByteCount+=intNewLineLength;
    }
*/


    br0=new BufferedReader(new InputStreamReader(new ByteArrayInputStream(byteBuf)));
    Vector vecLines2=new Vector();
    while((strNextLine=br0.readLine())!=null)
      vecLines2.addElement(strNextLine);

    String strLines[]=new String[vecLines2.size()];
    for(int i=0;i<strLines.length;i++)
      strLines[i]=(String)vecLines2.elementAt(i);

    BufferedReaderArray br=new BufferedReaderArray(strLines);

    strNextLine=br.readLine();

    if(strNextLine==null) {
      return;
//      throw new Exception("Empty source file found for file: "+strFilePath);
    }

    strPackage="";

    if(vecPackagePath.size()==0) {
      if(strNextLine.startsWith("package")) {
        throw new Exception("\"package\" found where none should exist for file: "+strFilePath);
      }

      intAbsoluteLineNumber=1;
    }
    else {
      if(!strNextLine.startsWith("package")) {
        throw new Exception("\"package\" not found where one should exist for file: "+strFilePath);
      }

      String strPackagePath=strNextLine.substring(8);
      for(int i=0;i<(vecPackagePath.size()-1);i++) {
        String strNextPathItem=(String)vecPackagePath.elementAt(i);
        int intIndex=strPackagePath.indexOf('.');
        if(intIndex==-1) {
          throw new Exception("Package path doesn't match for file: "+strFilePath);
        }
        String strNextPackage=strPackagePath.substring(0, intIndex);
        if(!strNextPathItem.equals(strNextPackage)) {
          throw new Exception("Package path doesn't match for file: "+strFilePath);
        }
        strPackage+=strNextPackage+".";
        strPackagePath=strPackagePath.substring(intIndex+1);
      }

      String strNextPathItem=(String)vecPackagePath.elementAt(vecPackagePath.size()-1);
      int intIndex=strPackagePath.indexOf(';');
      if(intIndex==-1) {
        throw new Exception("Package path doesn't match for file: "+strFilePath);
      }
      String strNextPackage=strPackagePath.substring(0, intIndex);
      if(!strNextPathItem.equals(strNextPackage)) {
        throw new Exception("Package path doesn't match for file: "+strFilePath);
      }
      strPackage+=strNextPackage+".";

      intAbsoluteLineNumber=1;

      while((strNextLine=br.readLine())!=null) {
        ++intAbsoluteLineNumber;

        if(strNextLine.length()>0)
          break;
      }
    }

    if(!(strNextLine.startsWith("import") || strNextLine.startsWith("class") || strNextLine.startsWith("interface") || strNextLine.startsWith("public") || strNextLine.startsWith("abstract"))) {
      while((strNextLine=br.readLine())!=null) {
//System.out.println(intAbsoluteLineNumber+":"+strNextLine);
        intAbsoluteLineNumber+=1;

        if(strNextLine.startsWith("import"))
          break;
        else if(strNextLine.startsWith("class"))
          break;
        else if(strNextLine.startsWith("interface"))
          break;
        else if(strNextLine.startsWith("public"))
          break;
        else if(strNextLine.startsWith("abstract"))
          break;
      }
    }

    if(strNextLine==null) {
      return;
//      throw new Exception("Empty source file found for file: "+strFilePath);
    }

    Vector vecImportedSingle=new Vector();
    Vector vecImported=new Vector();

    if(strNextLine.startsWith("import")) {
      String strImportPath=strNextLine.substring(7);
      if(!strImportPath.endsWith(";")) {
        throw new Exception("Source file contains import path that doesn't end with ';' for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
      }

      strImportPath=strImportPath.substring(0, strImportPath.length()-1);

      if(strImportPath.endsWith("*")) {
        if(hashPackages.containsKey(strImportPath)) {
          Vector vecClasses=(Vector)hashPackages.get(strImportPath);
          for(int i=0;i<vecClasses.size();i++) {
//System.out.println(vecClasses.elementAt(i));
            vecImported.addElement(vecClasses.elementAt(i));
          }
        }
        else {
          throw new Exception("Source file contains import path that ends with '*', but the package \""+strImportPath+"\" couldn't be found for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
        }
      }
      else {
        vecImportedSingle.addElement(strImportPath);
      }

      while((strNextLine=br.readLine())!=null) {
        intAbsoluteLineNumber+=1;

        if(!strNextLine.startsWith("import")) {

          while((strNextLine=br.readLine())!=null) {
            ++intAbsoluteLineNumber;

            if(strNextLine.length()>0)
              break;
          }

//          strNextLine=br.readLine();

          break;
        }

        strImportPath=strNextLine.substring(7);
        if(!strImportPath.endsWith(";")) {
          throw new Exception("Source file contains import path that doesn't end with ';' for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
        }

        strImportPath=strImportPath.substring(0, strImportPath.length()-1);

        if(strImportPath.endsWith("*")) {
          if(hashPackages.containsKey(strImportPath)) {
            Vector vecClasses=(Vector)hashPackages.get(strImportPath);
            for(int i=0;i<vecClasses.size();i++)
              vecImported.addElement(vecClasses.elementAt(i));
//              vecImported.addElement(strImportPath.substring(0, strImportPath.length()-1)+((String)vecClasses.elementAt(i)));
          }
          else {
            throw new Exception("Source file contains import path that ends with '*', but the package \""+strImportPath+"\" couldn't be found for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
          }
        }
        else {
          vecImportedSingle.addElement(strImportPath);
        }
      }

      if(strNextLine==null) {
        return;
//        throw new Exception("Empty source file found for file: "+strFilePath);
      }
    }

    Vector vecClasses=(Vector)hashPackages.get("java.lang.*");
    for(int i=0;i<vecClasses.size();i++) {
//System.out.println(vecClasses.elementAt(i));
      vecImported.addElement(vecClasses.elementAt(i));
    }

    for(int i=0;i<vecImportedLocal.size();i++)
      vecImported.addElement(vecImportedLocal.elementAt(i));

    for(int i=0;i<vecImportedSingle.size();i++) {
      String strNextImport=(String)vecImportedSingle.elementAt(i);

      int intImportIndex=strNextImport.lastIndexOf(".");

      if(intImportIndex==-1)
        continue;

      String strImportPackage=strNextImport.substring(0, intImportIndex+1)+"*";

      Vector vecClasses2=(Vector)hashPackages.get(strImportPackage);

      if(vecClasses2==null)
        continue;

      for(int ia=0;ia<vecClasses2.size();ia++) {
        String strNextImport2=(String)vecClasses2.elementAt(ia);

        if(strNextImport2.startsWith(strNextImport)) {
          if(!strNextImport2.equals(strNextImport)) {
            vecImported.addElement(strNextImport2);
          }
        }
      }
    }

/*
Iterator iterZ=hashPackages.entrySet().iterator();
while(iterZ.hasNext()) {
Map.Entry mEntry=(Map.Entry)iterZ.next();
Vector vecClasses2=(Vector)mEntry.getValue();
for(int i=0;i<vecClasses2.size();i++)
vecImported.addElement(vecClasses2.elementAt(i));
}
*/


    hashImported=new Hashtable();
//    hashImported.clear();

    hashImported.put("boolean", "boolean");
    hashImported.put("char", "char");
    hashImported.put("byte", "byte");
    hashImported.put("short", "short");
    hashImported.put("int", "int");
    hashImported.put("float", "float");
    hashImported.put("long", "long");
    hashImported.put("double", "double");

    for(int i=0;i<vecImportedSingle.size();i++) {
      String strNextImport=(String)vecImportedSingle.elementAt(i);

      int intImportIndex=strNextImport.lastIndexOf('.');
      if(intImportIndex==-1)
        hashImported.put(strNextImport, strNextImport);
      else {
        String strNextImportClass=strNextImport.substring(intImportIndex+1);
        hashImported.put(strNextImportClass, strNextImport);
      }
    }

    for(int i=0;i<vecImported.size();i++) {
      String strNextImport=(String)vecImported.elementAt(i);

//if(strNextImport.indexOf("Map$Entry")!=-1)
//System.out.println("strNextImport: "+strNextImport);

      int intImportIndex=strNextImport.lastIndexOf('.');
      if(intImportIndex==-1)
        hashImported.put(strNextImport, strNextImport);
      else {
        String strNextImportClass=strNextImport.substring(intImportIndex+1);
        hashImported.put(strNextImportClass, strNextImport);
      }
    }

//System.out.println(hashImported.get("Map$Entry"));

    IntegerContainer intInt=new IntegerContainer();

//    --intAbsoluteLineNumber;

    ClassObject classObj=parseClass(br, intAbsoluteLineNumber, intInt);

    if(!classObj.getClassName().endsWith("Dialog")) {
      if(!classObj.getConstructors().containsKey(new ConstructorSignature(classObj.getClassName(), new Vector())))
        throw new Exception("Error. Class \""+classObj.getClassName()+"\" doesn't contain an empty constructor for file: "+strFilePath);
    }

    hashClassesLines.put(classObj.getClassName(), vecClassLines);

    if(br.isAtEnd())
      return;

    intAbsoluteLineNumber=intInt.getInt();

    

/*
    while(true) {
      int intAbsoluteLineNumberClassStart=intAbsoluteLineNumber;

      IntegerContainer intInt=new IntegerContainer();

      StringContainer strStr=new StringContainer();

      if(strNextLine.indexOf("static")==-1) {
        ClassObject classObj2=parseInnerClass(br, strNextLine, intAbsoluteLineNumberClassStart, strClassName, intInt, strStr);
        classObj.getInstanceInnerClasses().put(classObj2.getClassName(), classObj2);
      }
      else {
        ClassObject classObj2=parseInnerClass(br, strNextLine, intAbsoluteLineNumberClassStart, strClassName, intInt, strStr);
        classObj.getStaticInnerClasses().put(classObj2.getClassName(), classObj2);
      }

      strNextLine=strStr.getStr();

      if(strNextLine==null)
        break;

      intAbsoluteLineNumber=intInt.getInt();
    }
*/
  }

  public static ClassObject parseClass(BufferedReaderArray br, int intAbsoluteLineNumber, IntegerContainer intInt0) throws Exception {
    return parseClass(br, intAbsoluteLineNumber, intInt0, "");
  }

  public static ClassObject parseClass(BufferedReaderArray br, int intAbsoluteLineNumber, IntegerContainer intInt0, String strOuterClassName) throws Exception {
    String strOuterClassName0=strOuterClassName;
    int intPeriodIndex=strOuterClassName.lastIndexOf('.');
    if(intPeriodIndex!=-1)
      strOuterClassName0=strOuterClassName.substring(intPeriodIndex+1);

    ++intAbsoluteLineNumber;
    br.pushLine();

    String strNextLine=br.readLine();
//System.out.println("parseClass:0:"+strNextLine);


    if(strNextLine.startsWith("public static class")) {
      strNextLine=strNextLine.substring(20);
    }
    else if(strNextLine.startsWith("protected static class")) {
      strNextLine=strNextLine.substring(23);
    }
    else if(strNextLine.startsWith("private static class")) {
      strNextLine=strNextLine.substring(21);
    }
    else if(strNextLine.startsWith("static class")) {
      strNextLine=strNextLine.substring(13);
    }
    else if(strNextLine.startsWith("public class")) {
      strNextLine=strNextLine.substring(13);
    }
    else if(strNextLine.startsWith("public abstract class")) {
      strNextLine=strNextLine.substring(22);
    }
    else if(strNextLine.startsWith("protected class")) {
      strNextLine=strNextLine.substring(16);
    }
    else if(strNextLine.startsWith("private class")) {
      strNextLine=strNextLine.substring(14);
    }
    else if(strNextLine.startsWith("abstract class")) {
      strNextLine=strNextLine.substring(15);
    }
    else if(strNextLine.startsWith("class")) {
      strNextLine=strNextLine.substring(6);
    }
    else if(strNextLine.startsWith("public interface")) {
      strNextLine=strNextLine.substring(17);
    }
    else if(strNextLine.startsWith("interface")) {
      strNextLine=strNextLine.substring(10);
    }
    else {
      throw new Exception("Source file doesn't start with \"class\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
    }


    String strClassName="";
    String strExtendsClassName="";
    String strClassName0="";

    Vector vecInterfaces=new Vector();

    int intSpaceIndex=strNextLine.indexOf(' ');
    if(intSpaceIndex==-1) {
      intSpaceIndex=strNextLine.length();

      if(strOuterClassName.length()>0) {
        strClassName=strNextLine.substring(0, intSpaceIndex);
        strClassName0=strClassName.toString();
        strClassName=strOuterClassName0+"$"+strClassName;
        hashImported.put(strClassName, strPackage+strClassName);
        strClassName=strPackage+strClassName;
      }
      else {
        strClassName=strNextLine.substring(0, intSpaceIndex);
        strClassName0=strClassName.toString();
        hashImported.put(strClassName, strPackage+strClassName);
        strClassName=strPackage+strClassName;
      }

      strNextLine=br.readLine();
//System.out.println("Missing:"+strNextLine);
      intAbsoluteLineNumber+=1;

      if(strNextLine==null) {
        return null;
//        throw new Exception("Empty source file found for file: "+strFilePath);
      }

      if(!strNextLine.startsWith("implements")) {
        throw new Exception("Missing \"implements\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
      }


      boolean blnMustBreak=false;

      strNextLine=strNextLine.substring(11);

      while(true) {
        int intCommaIndex=strNextLine.indexOf(',');

        if(intCommaIndex==-1) {
          intCommaIndex=strNextLine.indexOf(' ');
          blnMustBreak=true;
        }

        String strNextInterface=strNextLine.substring(0, intCommaIndex);

        vecInterfaces.addElement(hashImported.get(strNextInterface));

        strNextLine=strNextLine.substring(intCommaIndex+2);
        

        if(strNextInterface.endsWith("Listener")) {
          strNextInterface=(String)hashImported.get(strNextInterface);
          if(strNextInterface.startsWith("java.awt.event.") || strNextInterface.startsWith("javax.swing.event.")) {

            Class class0=Class.forName(strNextInterface);

            Method methods[]=class0.getDeclaredMethods();
            for(int i=0;i<methods.length;i++) {
              String strMethodName=methods[i].getName();

              Vector vecParameters=new Vector();

              Class classA[]=methods[i].getParameterTypes();
              for(int ia=0;ia<classA.length;ia++) {
                String strNextParameterClass=classA[ia].getName();
                String strArray="";
                while(true) {
                  if(strNextParameterClass.charAt(0)=='[') {
                    strNextParameterClass=strNextParameterClass.substring(1);
                    strArray+="[]";
                    continue;
                  }

                  break;
                }

                if(strArray.length()>0) {
                  strNextParameterClass=strNextParameterClass.substring(1);
                  strNextParameterClass+=strArray;
                }

                vecParameters.addElement(new FieldObject(strNextParameterClass));
              }

              vecExecutionEntryPoints.addElement(new ExecutionEntryPoint(strClassName, new FunctionSignature(strClassName, strMethodName, vecParameters), false));
            }

          }
        }

        if(blnMustBreak)
          break;
      }


      strNextLine=br.readLine();
      intAbsoluteLineNumber+=1;
    }
    else {
      if(strOuterClassName.length()>0) {
        strClassName=strNextLine.substring(0, intSpaceIndex);
        strClassName0=strClassName.toString();
        strClassName=strOuterClassName0+"$"+strClassName;
        hashImported.put(strClassName, strPackage+strClassName);
        strClassName=strPackage+strClassName;
      }
      else {
        strClassName=strNextLine.substring(0, intSpaceIndex);
        strClassName0=strClassName.toString();
        hashImported.put(strClassName, strPackage+strClassName);
        strClassName=strPackage+strClassName;
      }

      int intExtendsIndex=strNextLine.indexOf("extends", intSpaceIndex+1);

      if(intExtendsIndex!=-1) {
        intExtendsIndex+=8;

        strNextLine=strNextLine.substring(intExtendsIndex);

        intSpaceIndex=strNextLine.indexOf(' ');

        if(intSpaceIndex==-1)
          strExtendsClassName=strNextLine;
        else
          strExtendsClassName=strNextLine.substring(0, intSpaceIndex);
      }

      strNextLine=br.readLine();

      intAbsoluteLineNumber+=1;

      if(strNextLine.startsWith("implements")) {

        boolean blnMustBreak=false;

        strNextLine=strNextLine.substring(11);

        while(true) {
          int intCommaIndex=strNextLine.indexOf(',');

          if(intCommaIndex==-1) {
            intCommaIndex=strNextLine.indexOf(' ');
            blnMustBreak=true;
          }

          String strNextInterface=strNextLine.substring(0, intCommaIndex);

          vecInterfaces.addElement(hashImported.get(strNextInterface));

          strNextLine=strNextLine.substring(intCommaIndex+2);
        

          if(strNextInterface.endsWith("Listener")) {
            strNextInterface=(String)hashImported.get(strNextInterface);
            if(strNextInterface.startsWith("java.awt.event.") || strNextInterface.startsWith("javax.swing.event.")) {

              Class class0=Class.forName(strNextInterface);

              Method methods[]=class0.getDeclaredMethods();
              for(int i=0;i<methods.length;i++) {
                String strMethodName=methods[i].getName();

                Vector vecParameters=new Vector();

                Class classA[]=methods[i].getParameterTypes();
                for(int ia=0;ia<classA.length;ia++) {
                  String strNextParameterClass=classA[ia].getName();
                  String strArray="";
                  while(true) {
                    if(strNextParameterClass.charAt(0)=='[') {
                      strNextParameterClass=strNextParameterClass.substring(1);
                      strArray+="[]";
                      continue;
                    }

                    break;
                  }

                  if(strArray.length()>0) {
                    strNextParameterClass=strNextParameterClass.substring(1);
                    strNextParameterClass+=strArray;
                  }

                  vecParameters.addElement(new FieldObject(strNextParameterClass));
                }

                vecExecutionEntryPoints.addElement(new ExecutionEntryPoint(strClassName, new FunctionSignature(strClassName, strMethodName, vecParameters), false));
              }

            }
          }

          if(blnMustBreak)
            break;
        }


//        strNextLine=br.readLine();
//        intAbsoluteLineNumber+=1;
      }
//      else {
//        br.pushLine();
//      }
    }

    --intAbsoluteLineNumber;
    br.pushLine();

    if(hashImported.containsKey(strExtendsClassName)) {
      strExtendsClassName=(String)hashImported.get(strExtendsClassName);
    }
    else {
      strExtendsClassName="java.lang.Object";
    }

//System.out.println("outer class:"+strClassName);

    ClassObject classObj=new ClassObject(strClassName, strExtendsClassName, strOuterClassName);


    classObj.setFilePath(DeadlockExecutorCounter.strFilePath.toString());

    hashClasses.put(strClassName, classObj);

    classObj.setImported(HashtableClone.cloneH(hashImported));

    classObj.setInterfaces(vecInterfaces);

    if(strExtendsClassName.length()>0) {
      if(strExtendsClassName.endsWith("Adapter")) {
        String strFullClassName=strExtendsClassName;
        if(strFullClassName.startsWith("java.awt.event.") || strFullClassName.startsWith("javax.swing.event.")) {
          Class class0=Class.forName(strFullClassName);

          Method methods[]=class0.getDeclaredMethods();
          for(int i=0;i<methods.length;i++) {
            String strMethodName=methods[i].getName();

            Vector vecParameters=new Vector();

            Class classA[]=methods[i].getParameterTypes();
            for(int ia=0;ia<classA.length;ia++) {
              String strNextParameterClass=classA[ia].getName();
              String strArray="";
              while(true) {
                if(strNextParameterClass.charAt(0)=='[') {
                  strNextParameterClass=strNextParameterClass.substring(1);
                  strArray+="[]";
                  continue;
                }

                break;
              }

              if(strArray.length()>0) {
                strNextParameterClass=strNextParameterClass.substring(1);
                strNextParameterClass+=strArray;
              }

              vecParameters.addElement(new FieldObject(strNextParameterClass));
            }

            vecExecutionEntryPoints.addElement(new ExecutionEntryPoint(strClassName, new FunctionSignature(strClassName, strMethodName, vecParameters), false));
          }
        }
      }
    }

    strNextLine=br.readLine();
    if(strNextLine==null) {
      intInt0.setInt(intAbsoluteLineNumber+1);

      return classObj;
    }
    else {
      if(!strNextLine.startsWith("implements"))
        br.pushLine();
      else
        ++intAbsoluteLineNumber;
    }

    boolean blnNoConstructor=false;

    while((strNextLine=br.readLine())!=null) {
//System.out.println("before constructor:0:"+strNextLine);

//      if(strNextLine.startsWith("implements"))
//        continue;

//System.out.println("strNextLine:"+strNextLine+":"+intAbsoluteLineNumber);
      intAbsoluteLineNumber+=1;

      if(strNextLine.equals("}")) {
        intInt0.setInt(intAbsoluteLineNumber);

        return classObj;
      }

//System.out.println(strNextLine);

      if(strNextLine.startsWith("  static {") || strNextLine.startsWith("static {")) {
        int intAbsoluteLineNumberFunctionStart=intAbsoluteLineNumber;
        IntegerContainer intInt=new IntegerContainer();

        StaticInitializerObject staticObj=parseStaticInitializer(br, intAbsoluteLineNumberFunctionStart, strClassName, intInt);

        intAbsoluteLineNumber=intInt.getInt();

        vecExecutionStaticInitializers.addElement(staticObj);

        continue;
      }

      if(strNextLine.startsWith("  public static void main(String") || strNextLine.startsWith("public static void main(String")) {

        int intAbsoluteLineNumberFunctionStart=intAbsoluteLineNumber;
//System.out.println("parse function line number: "+intAbsoluteLineNumber);
        IntegerContainer intInt=new IntegerContainer();

        BooleanContainer blnBln=new BooleanContainer();

        FunctionObject functionObj=parseFunction(br, strNextLine, intAbsoluteLineNumberFunctionStart, strClassName, intInt, blnBln);

        if(blnBln.getBln()) {
//System.out.println("main:0");
          classObj.getStaticFunctions().put(functionObj.getSignature(), functionObj);

          if(functionObj.getFunctionName().equals("main")) {
//System.out.println("main:1");
            Vector vecParameters=functionObj.getParameters();

            if(vecParameters.size()==1) {
//System.out.println("main:2");
              FieldObject fObj=(FieldObject)vecParameters.elementAt(0);

//System.out.println(fObj.getClassName());
//System.out.println(hashImported.get("String"));
//System.out.println(hashImported.get("Object"));
              if(fObj.getClassName().equals("java.lang.String[]")) {
//System.out.println("main:3");
                vecExecutionEntryPoints.addElement(new ExecutionEntryPoint(strClassName, functionObj.getSignature(), true));
              }
            }

          }
        }
        else
          throw new Exception("Encountered an instance function where static main was expected for file: "+strFilePath+":"+intAbsoluteLineNumber);

        intAbsoluteLineNumber=intInt.getInt();

        continue;
      }

      boolean blnMustContinue2=false;

      while(true) {
        if(strNextLine.length()==0) {
          blnMustContinue2=true;
          break;
        }

        if(strNextLine.charAt(0)==' ') {
          strNextLine=strNextLine.substring(1);
          continue;
        }

        break;
      }

      if(blnMustContinue2)
        continue;

      if(strNextLine.startsWith("public "+strClassName0+"(")) {
        break;
      }
      else if(strNextLine.startsWith("protected "+strClassName0+"(")) {
        break;
      }
      else if(strNextLine.startsWith("private "+strClassName0+"(")) {
        break;
      }
      else if(strNextLine.startsWith(strClassName0+"(")) {
//System.out.println("constructor:0:"+strClassName0);
        break;
      }


      if(strNextLine.startsWith("public")) {
        int intParenthesisIndex=strNextLine.indexOf("(");

        if(intParenthesisIndex!=-1) {
          int intEqualsIndex=strNextLine.indexOf("=");
          if(intEqualsIndex==-1)
            intEqualsIndex=Integer.MAX_VALUE;

          if(intParenthesisIndex<intEqualsIndex) {
            blnNoConstructor=true;
            break;
          }
        }
      }
      else if(strNextLine.startsWith("protected")) {
        int intParenthesisIndex=strNextLine.indexOf("(");

        if(intParenthesisIndex!=-1) {
          int intEqualsIndex=strNextLine.indexOf("=");
          if(intEqualsIndex==-1)
            intEqualsIndex=Integer.MAX_VALUE;

          if(intParenthesisIndex<intEqualsIndex) {
            blnNoConstructor=true;
            break;
          }
        }
      }
      else if(strNextLine.startsWith("private")) {
        int intParenthesisIndex=strNextLine.indexOf("(");

        if(intParenthesisIndex!=-1) {
          int intEqualsIndex=strNextLine.indexOf("=");
          if(intEqualsIndex==-1)
            intEqualsIndex=Integer.MAX_VALUE;

          if(intParenthesisIndex<intEqualsIndex) {
            blnNoConstructor=true;
            break;
          }
        }
      }


      String strNextItem=null;
      boolean blnIsStatic=false;

//System.out.println(strNextLine);
      while(true) {
        intSpaceIndex=strNextLine.indexOf(' ');

        strNextItem=strNextLine.substring(0, intSpaceIndex);

        strNextLine=strNextLine.substring(intSpaceIndex+1);

        if(strNextItem.equals("public"))
          continue;
        else if(strNextItem.equals("protected"))
          continue;
        else if(strNextItem.equals("private"))
          continue;
        else if(strNextItem.equals("volatile"))
          continue;
        else if(strNextItem.equals("transient"))
          continue;
        else if(strNextItem.equals("final"))
          continue;
        else if(strNextItem.equals("static")) {
          blnIsStatic=true;
          continue;
        }
        else if(strNextItem.equals("enum")) {
          int intBraceCount=1;

          int intIndex=strNextLine.indexOf(' ');

          String strEnumName=strNextLine.substring(0, intIndex);

          Vector vecEnumValues=new Vector();

          intIndex=strNextLine.indexOf('{');

          ++intIndex;

          while(true) {
            if(intIndex>=strNextLine.length()) {
              strNextLine=br.readLine();
              intIndex=0;
            }

            char chr=strNextLine.charAt(intIndex);

            if(Character.isLetter(chr) || Character.isDigit(chr)) {
              int intIndex0=intIndex;

              ++intIndex;

              while(true) {
                if(intIndex>=strNextLine.length())
                  break;

                char chr2=strNextLine.charAt(intIndex);

                if(!(Character.isLetter(chr2) || Character.isDigit(chr2))) {
                  break;
                }

                ++intIndex;
              }

              vecEnumValues.addElement(strNextLine.substring(intIndex0, intIndex));

              if(intIndex==strNextLine.length())
                continue;

              chr=strNextLine.charAt(intIndex);
            }

            if(chr=='{') {
              ++intBraceCount;
            }
            else if(chr=='}') {
              --intBraceCount;

              if(intBraceCount==0)
                break;
            }

            ++intIndex;
          }

          EnumObject enumObj=new EnumObject(strEnumName, vecEnumValues);

//System.out.println("put enum: \""+strEnumName+"\"");
          classObj.getEnums().put(strEnumName, enumObj);

          blnMustContinue2=true;
        }

        break;
      }

      if(blnMustContinue2)
        continue;

      while(true) {
        if(strNextLine.length()==0) {
          throw new Exception("Expected a field name for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
        }

        if(strNextLine.charAt(0)==' ') {
          strNextLine=strNextLine.substring(1);
          continue;
        }

        break;
      }

//      intSpaceIndex=strNextLine.indexOf(' ');

//      String strNextFieldClass=strNextLine.substring(0, intSpaceIndex);

      String strNextFieldClass=strNextItem;


      char chrArr[]={'=', ';'};

      strNextFieldClass=parseFieldParameterClass(strClassName, strNextLine, strNextFieldClass, chrArr);
//System.out.println("field: "+strNextFieldClass);

//      strNextLine=strNextLine.substring(intSpaceIndex+1);

/*
      int intEqualsIndex=strNextLine.indexOf('=');

      if(intEqualsIndex==-1)
        intEqualsIndex=Integer.MAX_VALUE;

      int intSemiColonIndex=strNextLine.indexOf(';');

      if(intSemiColonIndex==-1)
        intSemiColonIndex=Integer.MAX_VALUE;

      intSpaceIndex=strNextLine.indexOf(' ');

      if(intSpaceIndex==-1)
        intSpaceIndex=Integer.MAX_VALUE;

      int intLeastIndex=-1;

      if(intEqualsIndex<intSemiColonIndex) {
        if(intEqualsIndex<intSpaceIndex) {
          intLeastIndex=intEqualsIndex;
        }
        else {
          intLeastIndex=intSpaceIndex;
        }
      }
      else {
        if(intSemiColonIndex<intSpaceIndex) {
          intLeastIndex=intSemiColonIndex;
        }
        else {
          intLeastIndex=intSpaceIndex;
        }
      }
*/

      String strNextFieldName=parseFieldParameterName(strNextLine);
//System.out.println("field: "+strNextFieldName);

//      String strNextFieldName=strNextLine.substring(0, intLeastIndex);

//System.out.println("field recognized: "+strNextFieldClass+" "+strNextFieldName);
      FieldObject fieldObj=new FieldObject(strNextFieldName, strNextFieldClass, strClassName);

      if(blnIsStatic) {
        classObj.getStaticFields().put(strNextFieldName, fieldObj);
      }
      else {
        classObj.getInstanceFields().put(strNextFieldName, fieldObj);
      }
    }

    if(strNextLine==null) {
      throw new Exception("Constructor not found for file: "+strFilePath);
    }

    if(blnNoConstructor) {
      br.pushLine();
      --intAbsoluteLineNumber;
    }

    boolean blnHasInnerClass=false;

    while(true) {

      if(!blnNoConstructor) {

//if(strFilePath.endsWith("AreaBuilder.java")) {
//if(strClassName.endsWith("EditStormsDialog")) {
//System.out.println("constructor");
//System.out.println(strNextLine);
//System.out.println(intAbsoluteLineNumber);
//}
//}

        int intAbsoluteLineNumberConstructorStart=intAbsoluteLineNumber;

        IntegerContainer intInt=new IntegerContainer();

//System.out.println("parseConstructor: "+strNextLine);
        ConstructorObject constructorObj=parseConstructor(br, strNextLine, intAbsoluteLineNumberConstructorStart, strClassName, intInt);

//while((strNextLine=br.readLine())!=null)
//System.out.println("parseConstructorAfter: "+strNextLine);

        classObj.getConstructors().put(constructorObj.getSignature(), constructorObj);

        intAbsoluteLineNumber=intInt.getInt();
      }

      boolean blnMustBreak=false;
      boolean blnMustContinue=false;

      while((strNextLine=br.readLine())!=null) {
        intAbsoluteLineNumber+=1;

        boolean blnMustContinue2=false;

        while(true) {
          if(strNextLine.length()==0) {
            blnMustContinue2=true;
            break;
          }

          if(strNextLine.charAt(0)==' ') {
            strNextLine=strNextLine.substring(1);
            continue;
          }

          break;
        }

        if(blnMustContinue2)
          continue;


        if(strNextLine.startsWith("public "+strClassName0+"(")) {
          blnMustContinue=true;
          break;
        }
        else if(strNextLine.startsWith("protected "+strClassName0+"(")) {
          blnMustContinue=true;
          break;
        }
        else if(strNextLine.startsWith("private "+strClassName0+"(")) {
          blnMustContinue=true;
          break;
        }
        else if(strNextLine.startsWith(strClassName0+"(")) {
          blnMustContinue=true;
          break;
        }




        if(strNextLine.startsWith("public static class")) {
          blnHasInnerClass=true;
          blnMustBreak=true;
          break;
        }
        else if(strNextLine.startsWith("protected static class")) {
          blnHasInnerClass=true;
          blnMustBreak=true;
          break;
        }
        else if(strNextLine.startsWith("private static class")) {
          blnHasInnerClass=true;
          blnMustBreak=true;
          break;
        }
        else if(strNextLine.startsWith("static class")) {
          blnHasInnerClass=true;
          blnMustBreak=true;
          break;
        }
        else if(strNextLine.startsWith("public class")) {
          blnHasInnerClass=true;
          blnMustBreak=true;
          break;
        }
        else if(strNextLine.startsWith("protected class")) {
          blnHasInnerClass=true;
          blnMustBreak=true;
          break;
        }
        else if(strNextLine.startsWith("private class")) {
          blnHasInnerClass=true;
          blnMustBreak=true;
          break;
        }
        else if(strNextLine.startsWith("class")) {
//System.out.println("inner class:0");

          blnHasInnerClass=true;
          blnMustBreak=true;
          break;
        }






        if(strNextLine.startsWith("public")) {
          blnMustBreak=true;
          break;
        }
        else if(strNextLine.startsWith("protected")) {
          blnMustBreak=true;
          break;
        }
        else if(strNextLine.startsWith("private")) {
          blnMustBreak=true;
          break;
        }
        
      }

      if(blnMustContinue)
        continue;

      if(blnMustBreak)
        break;

      if(strNextLine==null)
        break;
    }

    if(strNextLine==null) {
      intInt0.setInt(intAbsoluteLineNumber);

      return classObj;
    }


    if(!blnHasInnerClass) {

      while(true) {
//if(strFilePath.endsWith("AreaBuilder.java")) {
//if(strClassName.endsWith("FindWayDialog")) {
//System.out.println("function");
//System.out.println(strNextLine);
//System.out.println(intAbsoluteLineNumber);
//}
//}

        int intAbsoluteLineNumberFunctionStart=intAbsoluteLineNumber;

        IntegerContainer intInt=new IntegerContainer();

        BooleanContainer blnBln=new BooleanContainer();

        FunctionObject functionObj=parseFunction(br, strNextLine, intAbsoluteLineNumberFunctionStart, strClassName, intInt, blnBln);

        if(functionObj!=null) {

          if(blnBln.getBln()) {
            classObj.getStaticFunctions().put(functionObj.getSignature(), functionObj);

            if(functionObj.getFunctionName().equals("main")) {
              Vector vecParameters=functionObj.getParameters();

              if(vecParameters.size()==1) {
                FieldObject fObj=(FieldObject)vecParameters.elementAt(0);

                if(fObj.getClassName().equals("java.lang.String[]")) {
                  vecExecutionEntryPoints.addElement(new ExecutionEntryPoint(strClassName, functionObj.getSignature(), true));
                }
              }

            }
          }
          else
            classObj.getInstanceFunctions().put(functionObj.getSignature(), functionObj);

          intAbsoluteLineNumber=intInt.getInt();

        }

        boolean blnMustBreak=false;
        boolean blnMustContinue=false;

        while((strNextLine=br.readLine())!=null) {
          intAbsoluteLineNumber+=1;

          boolean blnMustContinue2=false;

          while(true) {
            if(strNextLine.length()==0) {
              blnMustContinue2=true;
              break;
            }

            if(strNextLine.charAt(0)==' ') {
              strNextLine=strNextLine.substring(1);
              continue;
            }

            break;
          }

          if(blnMustContinue2)
            continue;


          if(strNextLine.startsWith("public static class")) {
            blnMustBreak=true;
            break;
          }
          else if(strNextLine.startsWith("protected static class")) {
            blnMustBreak=true;
            break;
          }
          else if(strNextLine.startsWith("private static class")) {
            blnMustBreak=true;
            break;
          }
          else if(strNextLine.startsWith("static class")) {
            blnMustBreak=true;
            break;
          }
          else if(strNextLine.startsWith("public class")) {
            blnMustBreak=true;
            break;
          }
          else if(strNextLine.startsWith("protected class")) {
            blnMustBreak=true;
            break;
          }
          else if(strNextLine.startsWith("private class")) {
            blnMustBreak=true;
            break;
          }
          else if(strNextLine.startsWith("class")) {
            blnMustBreak=true;
            break;
          }

          if(strNextLine.startsWith("public")) {
            blnMustContinue=true;
            break;
          }
          else if(strNextLine.startsWith("protected")) {
            blnMustContinue=true;
            break;
          }
          else if(strNextLine.startsWith("private")) {
            blnMustContinue=true;
            break;
          }

        }

        if(blnMustContinue)
          continue;

        if(blnMustBreak) {
          blnHasInnerClass=true;
//          --intAbsoluteLineNumber;
//          br.pushLine();

          break;
        }

        if(strNextLine==null)
          break;
      }

    }

    if(strNextLine==null) {
      intInt0.setInt(intAbsoluteLineNumber);

      return classObj;
    }

    while(blnHasInnerClass) {
      Vector vecLinesZ=new Vector();

      int intBraceCount=0;
      if(strNextLine.indexOf('{')!=-1)
        ++intBraceCount;

      vecLinesZ.addElement(strNextLine);
//System.out.println("vecLinesZ:0:"+strNextLine);

      int intAbsoluteLineNumberTemp=intAbsoluteLineNumber;

      while((strNextLine=br.readLine())!=null) {
        ++intAbsoluteLineNumberTemp;

        strNextLine=trimString(strNextLine);
        vecLinesZ.addElement(strNextLine);
//System.out.println("vecLinesZ:1:"+strNextLine);

        boolean blnMustBreakZ=false;

        for(int i=0;i<strNextLine.length();i++) {
          if(strNextLine.charAt(i)=='{')
            ++intBraceCount;
          else if(strNextLine.charAt(i)=='}') {
            --intBraceCount;

            if(intBraceCount==0) {
              blnMustBreakZ=true;
              break;
            }
          }
        }

        if(blnMustBreakZ)
          break;
      }

      if(strNextLine==null) {
        intInt0.setInt(intAbsoluteLineNumberTemp);

        return classObj;
      }

      String strLinesZ[]=new String[vecLinesZ.size()];
      for(int i=0;i<strLinesZ.length;i++)
        strLinesZ[i]=(String)vecLinesZ.elementAt(i);

      BufferedReaderArray brZ=new BufferedReaderArray(strLinesZ);

      brZ.readLine();

      IntegerContainer intInt=new IntegerContainer();

      if(strNextLine.indexOf("static")==-1) {
//System.out.println("strClassName: "+classObj.getClassName());
        ClassObject classObj2=parseClass(brZ, intAbsoluteLineNumber-1, intInt, classObj.getClassName());
        if(classObj2!=null) {
/*
String strClassNameZ=classObj2.getClassName();
int intIndexZ=strClassNameZ.indexOf("$");
if(intIndexZ!=-1) {
intIndexZ=strClassNameZ.indexOf("$", intIndexZ+1);
if(intIndexZ!=-1) {
throw new Exception(strClassNameZ);
}
}
*/

//          classObj2.setFilePath(strFilePath.toString());

          if(!classObj2.getClassName().endsWith("Dialog")) {
            if(!classObj2.getConstructors().containsKey(new ConstructorSignature(classObj2.getClassName(), new Vector())))
              throw new Exception("Error. Class \""+classObj2.getClassName()+"\" doesn't contain an empty constructor for file: "+strFilePath);
          }

          classObj.getInstanceInnerClasses().put(classObj2.getClassName(), classObj2);
        }
      }
      else {
//System.out.println("\n\n\n\n\n\n"+strNextLine+"\n\n\n\n\n\n");
        ClassObject classObj2=parseClass(brZ, intAbsoluteLineNumber-1, intInt, classObj.getClassName());
        if(classObj2!=null) {

//          classObj2.setFilePath(strFilePath.toString());

          if(!classObj2.getClassName().endsWith("Dialog")) {
            if(!classObj2.getConstructors().containsKey(new ConstructorSignature(classObj2.getClassName(), new Vector())))
              throw new Exception("Error. Class \""+classObj2.getClassName()+"\" doesn't contain an empty constructor for file: "+strFilePath);
          }

          classObj.getStaticInnerClasses().put(classObj2.getClassName(), classObj2);
        }
      }

      intAbsoluteLineNumber=intInt.getInt();


      while((strNextLine=br.readLine())!=null) {
        strNextLine=trimString(strNextLine);

        ++intAbsoluteLineNumber;

        if(strNextLine.startsWith("public static class")) {
          break;
        }
        else if(strNextLine.startsWith("protected static class")) {
          break;
        }
        else if(strNextLine.startsWith("private static class")) {
          break;
        }
        else if(strNextLine.startsWith("static class")) {
          break;
        }
        else if(strNextLine.startsWith("public class")) {
          break;
        }
        else if(strNextLine.startsWith("protected class")) {
          break;
        }
        else if(strNextLine.startsWith("private class")) {
          break;
        }
        else if(strNextLine.startsWith("class")) {
          break;
        }
        else if(strNextLine.equals("}")) {
          blnHasInnerClass=false;
          break;
        }
      }

      if(strNextLine==null)
        break;
    }

    intInt0.setInt(intAbsoluteLineNumber);

    return classObj;
  }

  public static ConstructorObject parseConstructor(BufferedReaderArray br, String strNextLine, int intAbsoluteLineNumberConstructorStart, String strClassName, IntegerContainer intInt) throws Exception {
    int intAbsoluteLineNumber=intAbsoluteLineNumberConstructorStart+1;

    Vector vecParameters=new Vector();

    Vector vecConstructorParameters=new Vector();

    int intParenthesisIndex=strNextLine.indexOf('(');

    int intSpaceIndex=-1;

    strNextLine=strNextLine.substring(intParenthesisIndex+1);

    while(true) {
      while(true) {
        if(strNextLine.charAt(0)==' ') {
          strNextLine=strNextLine.substring(1);
          continue;
        }

        break;
      }


      intSpaceIndex=strNextLine.indexOf(' ');

      if(intSpaceIndex==-1)
        intSpaceIndex=Integer.MAX_VALUE;

      int intParenthesis2Index=strNextLine.indexOf(')');

      if(intParenthesis2Index==-1)
        intParenthesis2Index=Integer.MAX_VALUE;

      int intLeastIndex=-1;

      if(intSpaceIndex<intParenthesis2Index) {
        intLeastIndex=intSpaceIndex;
      }
      else {
        intLeastIndex=intParenthesis2Index;
      }

/*
      intSpaceIndex=strNextLine.indexOf(' ');

      if(intSpaceIndex==-1)
        intSpaceIndex=Integer.MAX_VALUE;

      int intCommaIndex=strNextLine.indexOf(',');

      if(intCommaIndex==-1)
        intCommaIndex=Integer.MAX_VALUE;

      int intParenthesis2Index=strNextLine.indexOf(')');

      if(intParenthesis2Index==-1)
        intParenthesis2Index=Integer.MAX_VALUE;

      int intLeastIndex=-1;

      if(intSpaceIndex<intCommaIndex) {
        if(intSpaceIndex<intParenthesis2Index) {
          intLeastIndex=intSpaceIndex;
        }
        else {
          intLeastIndex=intParenthesis2Index;
        }
      }
      else {
        if(intCommaIndex<intParenthesis2Index) {
          intLeastIndex=intCommaIndex;
        }
        else {
          intLeastIndex=intParenthesis2Index;
        }
      }
*/

      if(intLeastIndex==intParenthesis2Index) {
        break;
      }

//intSpaceIndex is intLeastIndex

      String strNextParameterClass=strNextLine.substring(0, intLeastIndex);

      strNextLine=strNextLine.substring(intLeastIndex+1);


      char chrArr[]={',', ')'};

      strNextParameterClass=parseFieldParameterClass(strClassName, strNextLine, strNextParameterClass, chrArr);


      while(true) {
        if(strNextLine.charAt(0)==' ') {
          strNextLine=strNextLine.substring(1);
          continue;
        }

        break;
      }

      int intCommaIndex=strNextLine.indexOf(',');

      if(intCommaIndex==-1)
        intCommaIndex=Integer.MAX_VALUE;

      intParenthesis2Index=strNextLine.indexOf(')');

      if(intParenthesis2Index==-1)
        intParenthesis2Index=Integer.MAX_VALUE;

      intSpaceIndex=strNextLine.indexOf(' ');

      if(intSpaceIndex==-1)
        intSpaceIndex=Integer.MAX_VALUE;

      intLeastIndex=-1;

      if(intSpaceIndex<intCommaIndex) {
        if(intSpaceIndex<intParenthesis2Index) {
          intLeastIndex=intSpaceIndex;
        }
        else {
          intLeastIndex=intParenthesis2Index;
        }
      }
      else {
        if(intCommaIndex<intParenthesis2Index) {
          intLeastIndex=intCommaIndex;
        }
        else {
          intLeastIndex=intParenthesis2Index;
        }
      }

      String strNextParameterName=parseFieldParameterName(strNextLine);

//      String strNextParameterName=strNextLine.substring(0, intLeastIndex);

      vecParameters.addElement(new FieldObject(strNextParameterClass));

//      vecParameters.addElement(new FieldObject(strNextParameterName, strNextParameterClass));

      vecConstructorParameters.addElement(new FieldObject(strNextParameterName, strNextParameterClass));

      if(intLeastIndex==intParenthesis2Index) {
        break;
      }

      strNextLine=strNextLine.substring(intLeastIndex);

      if(intLeastIndex==intSpaceIndex) {
        while(true) {
          if(strNextLine.charAt(0)==' ') {
            strNextLine=strNextLine.substring(1);
            continue;
          }

          break;
        }

        if(strNextLine.charAt(0)==')')
          break;
        else if(strNextLine.charAt(0)==',') {
          strNextLine=strNextLine.substring(1);

          while(true) {
            if(strNextLine.charAt(0)==' ') {
              strNextLine=strNextLine.substring(1);
              continue;
            }

            break;
          }
        }
      }
      else if(intLeastIndex==intCommaIndex) {
        strNextLine=strNextLine.substring(1);

        while(true) {
          if(strNextLine.charAt(0)==' ') {
            strNextLine=strNextLine.substring(1);
            continue;
          }

          break;
        }
      }
    }

    Vector vecInstructions=parseConstructorFunctionInstructions(br);

    intAbsoluteLineNumber+=vecInstructions.size();

    String strInstructions[]=new String[vecInstructions.size()];
    for(int i=0;i<strInstructions.length;i++)
      strInstructions[i]=(String)vecInstructions.elementAt(i);

    ConstructorObject constructorObj=new ConstructorObject(new ConstructorSignature(strClassName, vecParameters), vecConstructorParameters, strInstructions, intAbsoluteLineNumberConstructorStart+1, strClassName);

    intInt.setInt(intAbsoluteLineNumber);

    return constructorObj;
  }

  public static StaticInitializerObject parseStaticInitializer(BufferedReaderArray br, int intAbsoluteLineNumberFunctionStart, String strClassName, IntegerContainer intInt) throws Exception {
    int intAbsoluteLineNumber=intAbsoluteLineNumberFunctionStart+1;

    Vector vecInstructions=parseConstructorFunctionInstructions(br);

    intAbsoluteLineNumber+=vecInstructions.size();

    String strInstructions[]=new String[vecInstructions.size()];
    for(int i=0;i<strInstructions.length;i++)
      strInstructions[i]=(String)vecInstructions.elementAt(i);

    StaticInitializerObject staticObj=new StaticInitializerObject(strClassName, strInstructions, intAbsoluteLineNumberFunctionStart+1);

    intInt.setInt(intAbsoluteLineNumber);

    return staticObj;
  }

  public static FunctionObject parseFunction(BufferedReaderArray br, String strNextLine, int intAbsoluteLineNumberFunctionStart, String strClassName, IntegerContainer intInt, BooleanContainer blnBln) throws Exception {
    if(strNextLine.indexOf(" abstract ")!=-1)
      return null;

    int intAbsoluteLineNumber=intAbsoluteLineNumberFunctionStart+1;


    String strNextLineCopy0=strNextLine.toString();

    String strNextItem=null;

    while(true) {
      int intSpaceIndex=strNextLineCopy0.indexOf(' ');

      strNextItem=strNextLineCopy0.substring(0, intSpaceIndex);

      strNextLineCopy0=strNextLineCopy0.substring(intSpaceIndex+1);

      if(strNextItem.equals("public"))
        continue;
      else if(strNextItem.equals("protected"))
        continue;
      else if(strNextItem.equals("private"))
        continue;
      else if(strNextItem.equals("static"))
        continue;
      else if(strNextItem.equals("final"))
        continue;
      else if(strNextItem.equals("abstract"))
        continue;
      else if(strNextItem.equals("synchronized"))
        continue;
      else if(strNextItem.equals("native"))
        continue;
      else if(strNextItem.equals("strictfp"))
        continue;

      break;
    }

    String strReturnType=strNextItem;

    if(!strReturnType.equals("void")) {
      String strArrays="";
      int intArrayIndex=strReturnType.indexOf("[]");
      if(intArrayIndex!=-1) {
        strArrays=strReturnType.substring(intArrayIndex);
        strReturnType=strReturnType.substring(0, intArrayIndex);
      }
//      strReturnType=(String)hashImported.get(strReturnType);


      String strClassNameZ=strClassName.toString();

      int intDollarIndex=strClassNameZ.indexOf("$");
      if(intDollarIndex!=-1)
        strClassNameZ=strClassNameZ.substring(0, intDollarIndex);

      try {
        Class.forName(strClassNameZ+"$"+strReturnType);

        strReturnType=strClassNameZ+"$"+strReturnType;
      }
      catch(Exception ex) {
        strReturnType=(String)hashImported.get(strReturnType);
      }

      strReturnType+=strArrays;
    }

    Vector vecParameters=new Vector();

    Vector vecFunctionParameters=new Vector();

    int intParenthesisIndex=strNextLine.indexOf('(');

    int intStaticIndex=strNextLine.indexOf("static");
    if(intStaticIndex==-1)
      blnBln.setBln(false);
    else
      blnBln.setBln(true);

    int intSpaceIndex=strNextLine.lastIndexOf(' ', intParenthesisIndex);

    String strFunctionName=strNextLine.substring(intSpaceIndex+1, intParenthesisIndex);


//if(strFilePath.endsWith("AreaBuilder.java")) {
//if(strClassName.endsWith("FindWayDialog")) {
//if(strFunctionName.equals("actionPerformed"))
//System.out.println("function");
//System.out.println(strFunctionName);
//System.out.println(intAbsoluteLineNumberFunctionStart);
//}
//}


    strNextLine=strNextLine.substring(intParenthesisIndex+1);

    while(true) {
      while(true) {
        if(strNextLine.charAt(0)==' ') {
          strNextLine=strNextLine.substring(1);
          continue;
        }

        break;
      }


      intSpaceIndex=strNextLine.indexOf(' ');

      if(intSpaceIndex==-1)
        intSpaceIndex=Integer.MAX_VALUE;

      int intParenthesis2Index=strNextLine.indexOf(')');

      if(intParenthesis2Index==-1)
        intParenthesis2Index=Integer.MAX_VALUE;

      int intLeastIndex=-1;

      if(intSpaceIndex<intParenthesis2Index) {
        intLeastIndex=intSpaceIndex;
      }
      else {
        intLeastIndex=intParenthesis2Index;
      }

/*
      intSpaceIndex=strNextLine.indexOf(' ');

      if(intSpaceIndex==-1)
        intSpaceIndex=Integer.MAX_VALUE;

      int intCommaIndex=strNextLine.indexOf(',');

      if(intCommaIndex==-1)
        intCommaIndex=Integer.MAX_VALUE;

      int intParenthesis2Index=strNextLine.indexOf(')');

      if(intParenthesis2Index==-1)
        intParenthesis2Index=Integer.MAX_VALUE;

      int intLeastIndex=-1;

      if(intSpaceIndex<intCommaIndex) {
        if(intSpaceIndex<intParenthesis2Index) {
          intLeastIndex=intSpaceIndex;
        }
        else {
          intLeastIndex=intParenthesis2Index;
        }
      }
      else {
        if(intCommaIndex<intParenthesis2Index) {
          intLeastIndex=intCommaIndex;
        }
        else {
          intLeastIndex=intParenthesis2Index;
        }
      }
*/

      if(intLeastIndex==intParenthesis2Index) {
        break;
      }

//intSpaceIndex is intLeastIndex

      String strNextParameterClass=strNextLine.substring(0, intLeastIndex);

      strNextLine=strNextLine.substring(intLeastIndex+1);


      char chrArr[]={',', ')'};

      strNextParameterClass=parseFieldParameterClass(strClassName, strNextLine, strNextParameterClass, chrArr);


      while(true) {
        if(strNextLine.charAt(0)==' ') {
          strNextLine=strNextLine.substring(1);
          continue;
        }

        break;
      }

      int intCommaIndex=strNextLine.indexOf(',');

      if(intCommaIndex==-1)
        intCommaIndex=Integer.MAX_VALUE;

      intParenthesis2Index=strNextLine.indexOf(')');

      if(intParenthesis2Index==-1)
        intParenthesis2Index=Integer.MAX_VALUE;

      intSpaceIndex=strNextLine.indexOf(' ');

      if(intSpaceIndex==-1)
        intSpaceIndex=Integer.MAX_VALUE;

      intLeastIndex=-1;

      if(intSpaceIndex<intCommaIndex) {
        if(intSpaceIndex<intParenthesis2Index) {
          intLeastIndex=intSpaceIndex;
        }
        else {
          intLeastIndex=intParenthesis2Index;
        }
      }
      else {
        if(intCommaIndex<intParenthesis2Index) {
          intLeastIndex=intCommaIndex;
        }
        else {
          intLeastIndex=intParenthesis2Index;
        }
      }

      String strNextParameterName=parseFieldParameterName(strNextLine);

//      String strNextParameterName=strNextLine.substring(0, intLeastIndex);

      vecParameters.addElement(new FieldObject(strNextParameterClass));

//      vecParameters.addElement(new FieldObject(strNextParameterName, strNextParameterClass));

      vecFunctionParameters.addElement(new FieldObject(strNextParameterName, strNextParameterClass));

      if(intLeastIndex==intParenthesis2Index) {
        break;
      }

      strNextLine=strNextLine.substring(intLeastIndex);

      if(intLeastIndex==intSpaceIndex) {
        while(true) {
          if(strNextLine.charAt(0)==' ') {
            strNextLine=strNextLine.substring(1);
            continue;
          }

          break;
        }

        if(strNextLine.charAt(0)==')')
          break;
        else if(strNextLine.charAt(0)==',') {
          strNextLine=strNextLine.substring(1);

          while(true) {
            if(strNextLine.charAt(0)==' ') {
              strNextLine=strNextLine.substring(1);
              continue;
            }

            break;
          }
        }
      }
      else if(intLeastIndex==intCommaIndex) {
        strNextLine=strNextLine.substring(1);

        while(true) {
          if(strNextLine.charAt(0)==' ') {
            strNextLine=strNextLine.substring(1);
            continue;
          }

          break;
        }
      }
    }


    Vector vecInstructions=parseConstructorFunctionInstructions(br);

    intAbsoluteLineNumber+=vecInstructions.size();


    String strInstructions[]=new String[vecInstructions.size()];
    for(int i=0;i<strInstructions.length;i++)
      strInstructions[i]=(String)vecInstructions.elementAt(i);

    FunctionObject functionObj=new FunctionObject(new FunctionSignature(strClassName, strFunctionName, vecParameters), vecFunctionParameters, strReturnType, strInstructions, intAbsoluteLineNumberFunctionStart+1, strClassName);

    intInt.setInt(intAbsoluteLineNumber);

    return functionObj;
  }

  public static void executeEntryPoint(ExecutionEntryPoint executionEntryPoint) throws Exception {
if(blnDoShowEntryPoints)
System.out.println("executing entry point");
    String strClassName=executionEntryPoint.getClassName();
if(blnDoShowEntryPoints)
System.out.println(strClassName);
    FunctionSignature signature=executionEntryPoint.getSignature();
if(blnDoShowEntryPoints)
System.out.println(signature.toString());
    boolean isStatic=executionEntryPoint.isStatic();

    ClassObject classObj=(ClassObject)hashClasses.get(strClassName);

    String strOuterClass=classObj.getOuterClass();
    if(strOuterClass.length()>0) {
      ClassObject classObj2=(ClassObject)hashClasses.get(strOuterClass);

      ClassObject classObj3=ClassObject.merge(classObj, classObj2);

      classObj=classObj3;
    }

    FunctionObject functionObj=null;
    if(isStatic) {
      functionObj=(FunctionObject)classObj.getStaticFunctions().get(signature);
    }
    else {
      functionObj=(FunctionObject)classObj.getInstanceFunctions().get(signature);
    }

    if(functionObj==null) {
//      System.out.println("Skipping function: "+signature.toString());
//      System.out.println("From file: "+classObj.getFilePath());

      return;
    }

//    vecExecutedFunctions.addElement(signature);
    vecExecutingFunctions.addElement(signature);

    if(hashFunctionCounts.containsKey(signature)) {
      long lngCount0=((Long)hashFunctionCounts.get(signature)).longValue();

      for(int i=0;i<vecCounts.size();i++) {
        long lngCount=((Long)vecCounts.elementAt(i)).longValue();
        lngCount+=lngCount0;
        vecCounts.setElementAt(new Long(lngCount), i);
      }
    }
    else {
      String strInstructionsZ[]=functionObj.getInstructions();
      for(int i=0;i<vecCounts.size();i++) {
        long lngCount=((Long)vecCounts.elementAt(i)).longValue();
        lngCount+=(long)strInstructionsZ.length;
        vecCounts.setElementAt(new Long(lngCount), i);
      }

      vecCounts.addElement(new Long((long)strInstructionsZ.length));
    }

    String strInstructions[]=functionObj.getInstructions();

    int intAbsoluteLineNumber=functionObj.getAbsoluteLineNumber();

    Vector vecLocalFields=new Vector();
    Vector vecCurrentBraceFields=new Vector();
    vecLocalFields.addElement(vecCurrentBraceFields);

    Vector vecFunctionParameters=functionObj.getFunctionParameters();
    for(int i=0;i<vecFunctionParameters.size();i++)
      vecCurrentBraceFields.addElement(vecFunctionParameters.elementAt(i));

    DeadlockExecutorCounter.hashBraceSynchronized.clear();
    DeadlockExecutorCounter.hashBraceMarker.clear();
    DeadlockExecutorCounter.intBraceIndex=0;

    DeadlockExecutorCounter.strFilePath=classObj.getFilePath().toString();

    executeInstructions(classObj, strInstructions, intAbsoluteLineNumber, 0, vecLocalFields);

    if(!hashFunctionCounts.containsKey(signature)) {
      hashFunctionCounts.put(signature, vecCounts.elementAt(vecCounts.size()-1));

      hashFunctionCountsEntryPoint.put(signature, vecCounts.elementAt(vecCounts.size()-1));

      vecCounts.removeElementAt(vecCounts.size()-1);
    }

    vecExecutingFunctions.removeElementAt(0);
  }

  public static void executeStaticInitializer(StaticInitializerObject staticInitializer) throws Exception {
if(blnDoShowEntryPoints)
System.out.println("executing entry point");
    String strClassName=staticInitializer.getClassName();
if(blnDoShowEntryPoints)
System.out.println(strClassName);

    ClassObject classObj=(ClassObject)hashClasses.get(strClassName);

    String strOuterClass=classObj.getOuterClass();
    if(strOuterClass.length()>0) {
      ClassObject classObj2=(ClassObject)hashClasses.get(strOuterClass);

      ClassObject classObj3=ClassObject.merge(classObj, classObj2);

      classObj=classObj3;
    }

    String strInstructions[]=staticInitializer.getInstructions();

    int intAbsoluteLineNumber=staticInitializer.getAbsoluteLineNumber();

    Vector vecLocalFields=new Vector();
    Vector vecCurrentBraceFields=new Vector();
    vecLocalFields.addElement(vecCurrentBraceFields);

    DeadlockExecutorCounter.hashBraceSynchronized.clear();
    DeadlockExecutorCounter.hashBraceMarker.clear();
    DeadlockExecutorCounter.intBraceIndex=0;

    DeadlockExecutorCounter.strFilePath=classObj.getFilePath().toString();

    executeInstructions(classObj, strInstructions, intAbsoluteLineNumber, 0, vecLocalFields);
  }

  public static int executeInstructions(ClassObject classObj, String strInstructions0[], int intAbsoluteLineNumber, int instructionIndex, Vector vecLocalFields) throws Exception {
    String strFilePathPrevious=DeadlockExecutorCounter.strFilePath.toString();

    DeadlockExecutorCounter.strFilePath=classObj.getFilePath().toString();

    ++DeadlockExecutorCounter.intBraceIndex;

    Hashtable hashImportedPrevious=DeadlockExecutorCounter.hashImported;

    DeadlockExecutorCounter.hashImported=classObj.getImported();

    Vector vecCurrentBraceFields=(Vector)vecLocalFields.elementAt(vecLocalFields.size()-1);

    String strOuterClass=classObj.getOuterClass();
    if(strOuterClass.length()==0)
      strOuterClass=classObj.getClassName();

    String strInstructions[]=new String[strInstructions0.length];
    System.arraycopy(strInstructions0, 0, strInstructions, 0, strInstructions.length);

//int intPrevInstruction=-1;

//String strLastInstruction="";

    String strClassLines=classObj.getClassName();
    int intClassLinesDollarIndex=strClassLines.indexOf("$");
    if(intClassLinesDollarIndex!=-1)
      strClassLines=strClassLines.substring(0, intClassLinesDollarIndex);
    Vector vecClassLines=(Vector)hashClassesLines.get(strClassLines);

    while(instructionIndex<strInstructions.length) {
      boolean blnClassLine=((Boolean)vecClassLines.elementAt(intAbsoluteLineNumber-1)).booleanValue();
      if(blnClassLine) {
        ++instructionIndex;
        ++intAbsoluteLineNumber;
        continue;
      }

//System.out.println(strInstructions[instructionIndex]);

      vecClassLines.setElementAt(new Boolean(true), intAbsoluteLineNumber-1);

      strInstructions[instructionIndex]=trimString(strInstructions[instructionIndex]);

//if(strLastInstruction.equals(strInstructions[instructionIndex]))
//System.out.println("repeat:"+strLastInstruction);
//strLastInstruction=strInstructions[instructionIndex];

//for(int i=0;i<vecExecutedInstructions.size();i++) {
//String strNextInstr=(String)vecExecutedInstructions.elementAt(i);
//if(strNextInstr.equals(strInstructions[instructionIndex]))
//System.out.println(i+":"+strNextInstr);
//}

//if(!vecExecutedInstructions.contains(strInstructions[instructionIndex])) {
//vecExecutedInstructions.addElement(strInstructions[instructionIndex]);
//System.out.println(strInstructions[instructionIndex]);
//}


/*
vecAllInstructionsIndex.addElement(new Integer(instructionIndex));
vecAllInstructionsString.addElement(new String(strInstructions[instructionIndex]));


if(intPrevInstructionIndex==intPrevInstruction.length) {
  boolean blnMatch=false;

  for(int i=1;i<intPrevInstruction.length;i++) {
    intPrevInstruction[i-1]=intPrevInstruction[i];
    strPrevInstruction[i-1]=strPrevInstruction[i];
  }

  intPrevInstruction[9]=instructionIndex;
  strPrevInstruction[9]=strInstructions[instructionIndex];

  int intDisplacement=0;

  while(true) {
    int intIndex=vecAllInstructionsIndex.size()-intPrevInstruction.length*2-intDisplacement;

    if(intIndex<0)
      break;

    ++intDisplacement;

    int intStopIndex=intIndex+intPrevInstruction.length;

    int ia=intIndex;
    for(;ia<intStopIndex;ia++) {
      if(intPrevInstruction[ia-intIndex]!=((Integer)vecAllInstructionsIndex.elementAt(ia)).intValue()) {
        break;
      }
    }

    if(ia==intStopIndex)
      blnMatch=true;

    if(blnMatch) {
      for(int iz=0;iz<strPrevInstruction.length;iz++) {
        System.out.println(iz+":"+strPrevInstruction[iz]);
      }

      break;
    }
  }

  if(blnMatch)
    throw new Exception("Match found.");
}
else {
  intPrevInstruction[intPrevInstructionIndex]=instructionIndex;
  strPrevInstruction[intPrevInstructionIndex++]=strInstructions[instructionIndex];
}
*/


//if(intPrevInstruction==instructionIndex)
//System.out.println("repeating:"+instructionIndex);
//intPrevInstruction=instructionIndex;

//if((intAbsoluteLineNumber%500)==0)
//System.out.println(DeadlockExecutorCounter.strFilePath+":"+intAbsoluteLineNumber);

      if(strInstructions[instructionIndex].length()==0) {
        ++instructionIndex;
        ++intAbsoluteLineNumber;
        continue;
      }

if(blnDoShowOutput)
System.out.println("instruction: "+strInstructions[instructionIndex]);

      if(strInstructions[instructionIndex].startsWith("continue;")) {
        instructionIndex++;
        intAbsoluteLineNumber++;
        continue;
      }
      else if(strInstructions[instructionIndex].startsWith("for(")) {
        String strNextLine=strInstructions[instructionIndex];
        strNextLine=strNextLine.substring(4);
        int intIndex=strNextLine.indexOf(';');
        vecCurrentBraceFields=new Vector();
        vecLocalFields.addElement(vecCurrentBraceFields);
        if(intIndex!=0) {
          String strIntField="";
          if(strNextLine.startsWith("int")) {
            strNextLine=strNextLine.substring(4);
            strIntField=strNextLine.substring(0, strNextLine.indexOf('='));
//System.out.println("int "+strIntField);

            FieldObject fieldObj=new FieldObject(strIntField, "int");
            vecCurrentBraceFields.addElement(fieldObj);
          }
        }

        intIndex=strNextLine.indexOf(';');

        int intIndex2=strNextLine.indexOf(';', intIndex+1);

/*
        int intIndex0=strNextLine.indexOf('<', intIndex);
        int intIndex1=strNextLine.indexOf('>', intIndex);
        if(intIndex0!=-1) {
          strNextLine=strNextLine.substring(intIndex0+1);
          if(strNextLine.charAt(0)=='=')
            strNextLine=strNextLine.substring(1);
        }
        else if(intIndex1!=-1) {
          strNextLine=strNextLine.substring(intIndex1+1);
          if(strNextLine.charAt(0)=='=')
            strNextLine=strNextLine.substring(1);
        }
        int intIndex2=strNextLine.indexOf(';');
*/

        Vector vecOperands=parseOperands(strNextLine.substring(intIndex+1, intIndex2));
        for(int i=0;i<vecOperands.size();i++) {
          String strNextOperand=(String)vecOperands.elementAt(i);
          executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
        }

//        executeCommand(classObj, intAbsoluteLineNumber, strNextLine.substring(0, intIndex2), vecLocalFields);

        strNextLine=strNextLine.substring(intIndex2+1);
        instructionIndex++;
        intAbsoluteLineNumber++;
        if(strNextLine.indexOf('{')!=-1) {
          int instructionIndex2=executeInstructions(classObj, strInstructions, intAbsoluteLineNumber, instructionIndex, vecLocalFields);
          intAbsoluteLineNumber+=(instructionIndex2-instructionIndex);
          instructionIndex=instructionIndex2;
        }
        else {
          executeInstruction(classObj, strInstructions, intAbsoluteLineNumber, instructionIndex, vecLocalFields);
          ++intAbsoluteLineNumber;
          ++instructionIndex;
        }
        vecLocalFields.removeElementAt(vecLocalFields.size()-1);
        vecCurrentBraceFields=(Vector)vecLocalFields.elementAt(vecLocalFields.size()-1);
      }
      else if(strInstructions[instructionIndex].startsWith("new ")) {
        String strNextLine=strInstructions[instructionIndex];

        int intIndexZ0=strNextLine.lastIndexOf(')');

        int intIndexZ1=strNextLine.lastIndexOf(']');

        if(intIndexZ1>intIndexZ0) {
          int intBracketCount=1;

          int intIndex0=intIndexZ1-1;

          while(true) {
            char chr=strNextLine.charAt(intIndex0);
 
            if(chr=='[') {
              --intBracketCount;

              if(intBracketCount==0)
                break;
            }
            else if(chr==']') {
              ++intBracketCount;
            }

            --intIndex0;
          }

          ++intIndex0;

          String strOperands=strNextLine.substring(intIndex0, intIndexZ1);

          Vector vecOperands=parseOperands(strOperands);
          for(int i=0;i<vecOperands.size();i++) {
            String strNextOperand=(String)vecOperands.elementAt(i);
            executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
          }

          instructionIndex++;
          intAbsoluteLineNumber++;
        }
        else {
          parseNew(classObj, vecLocalFields, strNextLine, intAbsoluteLineNumber, classObj.getClassName());

//          int intParseNewAdd=parseNew(classObj, vecLocalFields, strNextLine, intAbsoluteLineNumber);

//          strNextLine=strNextLine.substring(intParseNewAdd);

/*
          int intIndex=0;

          while(true) {
            char chr=strNextLine.charAt(intIndex);

            if(chr==';') {
              break;
            }

            ++intIndex;
          }


          String strOperands=strNextLine.substring(0, intIndex);

          Vector vecOperands=parseOperands(strOperands);
          for(int i=0;i<vecOperands.size();i++) {
            String strNextOperand=(String)vecOperands.elementAt(i);
            executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
          }

//System.out.println("before new: "+strNextLine.substring(0, intIndex));
//          executeCommand(classObj, intAbsoluteLineNumber, strNextLine.substring(0, intIndex), vecLocalFields);

*/

          instructionIndex++;
          intAbsoluteLineNumber++;

          int intCurlyBraceIndex=strNextLine.indexOf('{');
          if(intCurlyBraceIndex!=-1) {
            int instructionIndex2=parseConstructorFunctionInstructions(strInstructions, instructionIndex);
            intAbsoluteLineNumber+=(instructionIndex2-instructionIndex);
            instructionIndex=instructionIndex2;
          }
        }
      }
      else if(strInstructions[instructionIndex].startsWith("switch(")) {
        instructionIndex++;
        intAbsoluteLineNumber++;

        vecCurrentBraceFields=new Vector();
        vecLocalFields.addElement(vecCurrentBraceFields);

        int instructionIndex2=executeInstructions(classObj, strInstructions, intAbsoluteLineNumber, instructionIndex, vecLocalFields);
        intAbsoluteLineNumber+=(instructionIndex2-instructionIndex);
        instructionIndex=instructionIndex2;

        vecLocalFields.removeElementAt(vecLocalFields.size()-1);
        vecCurrentBraceFields=(Vector)vecLocalFields.elementAt(vecLocalFields.size()-1);
      }
      else if(strInstructions[instructionIndex].startsWith("assert ")) {
        String strNextLine=strInstructions[instructionIndex];
        strNextLine=strNextLine.substring(7);
        int intColonIndex=strNextLine.indexOf(':');

        while(true) {
           if(strNextLine.charAt(0)==' ') {
             strNextLine=strNextLine.substring(1);
             continue;
           }

           break;
        }

        if(intColonIndex==-1) {
          int intEndIndex=1;
          while(true) {
            if(strNextLine.charAt(intEndIndex)==' ' || strNextLine.charAt(intEndIndex)==';')
              break;

            ++intEndIndex;
          }

          String strOperands=strNextLine.substring(0, intEndIndex);

          Vector vecOperands=parseOperands(strOperands);
          for(int i=0;i<vecOperands.size();i++) {
            String strNextOperand=(String)vecOperands.elementAt(i);
            executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
          }

//          executeCommand(classObj, intAbsoluteLineNumber, strNextLine.substring(0, intEndIndex), vecLocalFields);
        }
        else {
          int intEndIndex=1;
          while(true) {
            if(strNextLine.charAt(intEndIndex)==' ' || strNextLine.charAt(intEndIndex)==':')
              break;

            ++intEndIndex;
          }

          String strOperands=strNextLine.substring(0, intEndIndex);

          Vector vecOperands=parseOperands(strOperands);
          for(int i=0;i<vecOperands.size();i++) {
            String strNextOperand=(String)vecOperands.elementAt(i);
            executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
          }

//          executeCommand(classObj, intAbsoluteLineNumber, strNextLine.substring(0, intEndIndex), vecLocalFields);

          strNextLine=strNextLine.substring(intColonIndex+1);

          while(true) {
             if(strNextLine.charAt(0)==' ') {
               strNextLine=strNextLine.substring(1);
               continue;
             }

             break;
          }

          intEndIndex=1;
          while(true) {
            if(strNextLine.charAt(intEndIndex)==' ' || strNextLine.charAt(intEndIndex)==';')
              break;

            ++intEndIndex;
          }

          strOperands=strNextLine.substring(0, intEndIndex);

          vecOperands=parseOperands(strOperands);
          for(int i=0;i<vecOperands.size();i++) {
            String strNextOperand=(String)vecOperands.elementAt(i);
            executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
          }

//          executeCommand(classObj, intAbsoluteLineNumber, strNextLine.substring(0, intEndIndex), vecLocalFields);
        }

        instructionIndex++;
        intAbsoluteLineNumber++;
      }
      else if(strInstructions[instructionIndex].startsWith("default:")) {
        String strNextLine=strInstructions[instructionIndex];

        int intIndex=strNextLine.indexOf(':');

        ++intIndex;

        while(true) {
          if(intIndex>=strNextLine.length())
            break;

          char chr=strNextLine.charAt(intIndex);

          if(chr!=' ')
            break;

          ++intIndex;
        }

        if(intIndex==strNextLine.length()) {
          instructionIndex++;
          intAbsoluteLineNumber++;
          continue;
        }

        strInstructions[instructionIndex]=strNextLine.substring(intIndex);

        continue;
      }
      else if(strInstructions[instructionIndex].startsWith("goto ")) {
//not used
        instructionIndex++;
        intAbsoluteLineNumber++;
      }
      else if(strInstructions[instructionIndex].startsWith("synchronized(")) {
        String strNextLine=strInstructions[instructionIndex];

        strNextLine=strNextLine.substring(13);

        int intIndex=strNextLine.lastIndexOf(')');

        String strFieldPath=strNextLine.substring(0, intIndex);
        String strFieldPathZ=strFieldPath.toString();

        ClassObject classContainer=classObj;

        SynchronizableKey key=null;

        int intPeriodIndex=strFieldPath.indexOf('.');
        if(intPeriodIndex==-1) {
          int i=vecLocalFields.size()-1;
          for(;i>=0;i--) {
            Vector vecNextFields=(Vector)vecLocalFields.elementAt(i);

            boolean blnMustBreak=false;

            for(int ia=0;ia<vecNextFields.size();ia++) {
              FieldObject nextFieldObject=(FieldObject)vecNextFields.elementAt(ia);

              if(nextFieldObject.getFieldName().equals(strFieldPath)) {
                key=new SynchronizableKey(strFieldPath);
                blnMustBreak=true;
                break;

//                throw new Exception("Local variables not permitted to be synchronizable for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
              }
            }

            if(blnMustBreak)
              break;
          }

          if(i==-1) {
            key=new SynchronizableKey(classObj.getClassName(), strFieldPath);

//            String strClassName=getFieldObjectClassByName(strFieldPath, classObj, intAbsoluteLineNumber);

//            key=new SynchronizableKey(strClassName, strFieldPath);

/*
            Hashtable hashInstanceFields=classObj.getInstanceFields();
            FieldObject fObj=(FieldObject)hashInstanceFields.get(strFieldPath);
            if(fObj!=null) {
              key=new SynchronizableKey(classObj.getClassName(), strFieldPath);
            }
            else {
              Hashtable hashStaticFields=classObj.getStaticFields();
              fObj=(FieldObject)hashStaticFields.get(strFieldPath);
              if(fObj!=null) {
                key=new SynchronizableKey(classObj.getClassName(), strFieldPath);
              }
              else {
                String strClassObj=classObj.getClassName();

                int intDollarIndex=strClassObj.indexOf("$");

                if(intDollarIndex==-1) {
                  throw new Exception("Unidentified field \""+strFieldPath+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
                }
                else {
                  strClassObj=strClassObj.substring(0, intDollarIndex);

                  ClassObject classObj2=(ClassObject)hashClasses.get(strClassObj);

                  hashInstanceFields=classObj2.getInstanceFields();
                  fObj=(FieldObject)hashInstanceFields.get(strFieldPath);
                  if(fObj!=null) {
                    key=new SynchronizableKey(classObj2.getClassName(), strFieldPath);
                  }
                  else {
                    hashStaticFields=classObj2.getStaticFields();
                    fObj=(FieldObject)hashStaticFields.get(strFieldPath);
                    if(fObj!=null) {
                      key=new SynchronizableKey(classObj2.getClassName(), strFieldPath);
                    }
                    else {
                      throw new Exception("Unidentified field \""+strFieldPath+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
                    }
                  }
                }
              }
            }
*/

          }
        }
        else {
          String strName=strFieldPath.substring(0, intPeriodIndex);

          boolean blnDone=false;

          int i=vecLocalFields.size()-1;
          for(;i>=0;i--) {
            Vector vecNextFields=(Vector)vecLocalFields.elementAt(i);

            boolean blnMustBreak=false;

            for(int ia=0;ia<vecNextFields.size();ia++) {
              FieldObject nextFieldObject=(FieldObject)vecNextFields.elementAt(ia);

              if(nextFieldObject.getFieldName().equals(strName)) {
                strFieldPath=strFieldPath.substring(intPeriodIndex+1);

                if(strFieldPath.indexOf('.')==-1) {
                  key=new SynchronizableKey(nextFieldObject.getClassName(), strFieldPath);

                  blnDone=true;
                }
                else {
                  classContainer=(ClassObject)hashClasses.get(nextFieldObject.getClassName());
                  if(classContainer==null) {
                    int intPeriodCount=0;
                    int intIndexZ=-1;
                    while(true) {
                      intIndexZ=strFieldPath.indexOf('.', intIndexZ+1);

                      if(intIndexZ==-1)
                        break;

                      ++intPeriodCount;
                    }

                    String strClassName=getClassNameFromCommandTrail(nextFieldObject.getClassName(), strFieldPath, classObj, vecLocalFields, intAbsoluteLineNumber, intPeriodCount);

                    key=new SynchronizableKey(strClassName, strFieldPath.substring(strFieldPath.lastIndexOf(".")+1));

                    blnDone=true;
                  }
                  else {
                    intPeriodIndex=strFieldPath.indexOf(".");
                  }
                }

                blnMustBreak=true;
                break;

//                throw new Exception("Local variables not permitted to be synchronizable for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
              }
            }

            if(blnMustBreak)
              break;
          }

          if(!blnDone) {
            if(intPeriodIndex!=-1) {
              do {
                String strName0=strFieldPath.substring(0, intPeriodIndex);

                strFieldPath=strFieldPath.substring(intPeriodIndex+1);

                String strClassName=getFieldObjectClassByName(strName0, classContainer, intAbsoluteLineNumber);

                classContainer=(ClassObject)hashClasses.get(strClassName);

                intPeriodIndex=strFieldPath.indexOf(".");

                if(intPeriodIndex==-1) {
                  key=new SynchronizableKey(strClassName, strFieldPath);

                  blnDone=true;

                  break;
                }
                else {
                  if(classContainer==null) {
                    int intPeriodCount=0;
                    int intIndexZ=-1;
                    while(true) {
                      intIndexZ=strFieldPath.indexOf('.', intIndexZ+1);

                      if(intIndexZ==-1)
                        break;

                      ++intPeriodCount;
                    }

                    strClassName=getClassNameFromCommandTrail(strClassName, strFieldPath, classObj, vecLocalFields, intAbsoluteLineNumber, intPeriodCount);

                    key=new SynchronizableKey(strClassName, strFieldPath.substring(strFieldPath.lastIndexOf(".")+1));

                    blnDone=true;

                    break;
                  }
                }

//                if(intPeriodIndex==-1)
//                  break;

              } while(true);
            }

/*
            if(!blnDone) {
              String strName0=strFieldPath;

              key=new SynchronizableKey(classContainer.getClassName(), strName0);

//              String strClassName=getFieldObjectClassByName(strName0, classContainer, intAbsoluteLineNumber);

//              key=new SynchronizableKey(strClassName, strName0);
            }
*/

          }

/*
          while(true) {
            intPeriodIndex=strFieldPath.indexOf('.');
            if(intPeriodIndex==-1)
              break;

            String strName=strFieldPath.substring(0, intPeriodIndex);
            strFieldPath=strFieldPath.substring(intPeriodIndex+1);

            boolean blnMustBreak=false;

            for(int i=vecLocalFields.size()-1;i>=0;i--) {
              Vector vecNextFields=(Vector)vecLocalFields.elementAt(i);
              for(int ia=0;ia<vecNextFields.size();ia++) {
                FieldObject nextField=(FieldObject)vecNextFields.elementAt(ia);

                if(nextField.getFieldName().equals(strName)) {
                  classContainer=(ClassObject)hashClasses.get(nextField.getClassName());
                  if(classContainer==null)
                    throw new Exception("Built-in members not allowed to be mutexes for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

                  blnMustBreak=true;
                  break;
                }
              }

              if(blnMustBreak)
                break;
            }

            if(!blnMustBreak) {
              Hashtable hashInstanceFields=classContainer.getInstanceFields();
              FieldObject fObj=(FieldObject)hashInstanceFields.get(strName);
              if(fObj!=null) {
                classContainer=(ClassObject)hashClasses.get(fObj.getClassName());
                if(classContainer==null)
                  throw new Exception("Built-in members not allowed to be mutexes for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
              }
              else {
                Hashtable hashStaticFields=classContainer.getStaticFields();
//System.out.println("container:"+classContainer.getClassName());
//System.out.println("field name:"+strName);
                fObj=(FieldObject)hashStaticFields.get(strName);
                if(fObj!=null) {
                  classContainer=(ClassObject)hashClasses.get(fObj.getClassName());
                  if(classContainer==null)
                    throw new Exception("Built-in members not allowed to be mutexes for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
                }
                else {
                  String strStaticClassName=(String)hashImported.get(strName);
                  if(strStaticClassName!=null) {
                    if(strStaticClassName.equals(classContainer.getClassName())) {
                      ;
                    }
                    else
                      throw new Exception("Unidentified field \""+strName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
                  }
                  else
                    throw new Exception("Unidentified field \""+strName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
                }
              }
            }

          }

          String strName=strFieldPath;

          Hashtable hashInstanceFields=classContainer.getInstanceFields();
          FieldObject fObj=(FieldObject)hashInstanceFields.get(strName);
          if(fObj!=null) {
            key=new SynchronizableKey(classContainer.getClassName(), strName);
          }
          else {
            Hashtable hashStaticFields=classContainer.getStaticFields();
            fObj=(FieldObject)hashStaticFields.get(strName);
            if(fObj!=null) {
              key=new SynchronizableKey(classContainer.getClassName(), strName);
            }
            else
              throw new Exception("Unidentified field \""+strName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
          }
*/

        }

        boolean blnIsAlreadyMutex=false;

        SynchronizableObject syncObj=(SynchronizableObject)hashSynchronized.get(key);
        if(syncObj==null) {
          syncObj=new SynchronizableObject(key);
          hashSynchronized.put(key, syncObj);

          Iterator iter=hashBraceSynchronized.entrySet().iterator();
          while(iter.hasNext()) {
            Map.Entry mEntry=(Map.Entry)iter.next();
            SynchronizableObject syncObj2=(SynchronizableObject)mEntry.getValue();

            syncObj2.getLowerPriority().addElement(syncObj);

            syncObj.getHigherPriority().addElement(syncObj2);
          }
        }
        else {
          Iterator iter=hashBraceSynchronized.entrySet().iterator();
          while(iter.hasNext()) {
            Map.Entry mEntry=(Map.Entry)iter.next();
            SynchronizableObject syncObj2=(SynchronizableObject)mEntry.getValue();

            if(syncObj2.getKey().equals(key)) {
              blnIsAlreadyMutex=true;
              break;
            }
          }

/*
          if(!blnIsAlreadyMutex) {
            iter=hashBraceSynchronized.entrySet().iterator();
            while(iter.hasNext()) {
              Map.Entry mEntry=(Map.Entry)iter.next();
              SynchronizableObject syncObj2=(SynchronizableObject)mEntry.getValue();

              if(syncObj2.getHigherPriority().contains(syncObj)) {
                SynchronizableMarker sMarker=(SynchronizableMarker)hashBraceMarker.get(mEntry.getKey());

//                String strDeadlockThreat="\nDeadlock threat:\n";
                String strDeadlockThreat=syncObj2.getKey().getClassName()+":"+syncObj2.getKey().getFieldName()+"\n";
                strDeadlockThreat+="Location: "+sMarker.getFilePath()+":"+sMarker.getAbsoluteLineNumber()+"\n";
                strDeadlockThreat+=syncObj.getKey().getClassName()+":"+syncObj.getKey().getFieldName()+"\n";
                strDeadlockThreat+="Location: "+DeadlockExecutor.strFilePath+":"+(intAbsoluteLineNumber-1);

                vecSynchronizedThreats.addElement(strDeadlockThreat);
//                throw new Exception(strDeadlockThreat);
              }

              syncObj2.getLowerPriority().addElement(syncObj);

              syncObj.getHigherPriority().addElement(syncObj2);
            }
          }
*/

        }

        if(!blnIsAlreadyMutex) {
          hashBraceSynchronized.put(new Integer(DeadlockExecutor.intBraceIndex), syncObj);
          hashBraceMarker.put(new Integer(DeadlockExecutor.intBraceIndex), new SynchronizableMarker(DeadlockExecutor.strFilePath.toString(), (intAbsoluteLineNumber-1)));
        }


        vecCurrentBraceFields=new Vector();
        vecLocalFields.addElement(vecCurrentBraceFields);

//System.out.println("before:"+instructionIndex);

        instructionIndex++;
        intAbsoluteLineNumber++;

//        resumervecExecutionLevelType.addElement(new Integer(DeadlockResumer.EXECUTION_LEVEL_TYPE_NEITHER));
//        resumervecExecutionLevel.addElement(new Integer(DeadlockResumer.EXECUTION_LEVEL_INSTRUCTIONS));

        int instructionIndex2=executeInstructions(classObj, strInstructions, intAbsoluteLineNumber, instructionIndex, vecLocalFields);
        intAbsoluteLineNumber+=(instructionIndex2-instructionIndex);
        instructionIndex=instructionIndex2;

//System.out.println("after:"+instructionIndex);

        vecLocalFields.removeElementAt(vecLocalFields.size()-1);
        vecCurrentBraceFields=(Vector)vecLocalFields.elementAt(vecLocalFields.size()-1);
      }
      else if(strInstructions[instructionIndex].startsWith("do ")) {
        instructionIndex++;
        intAbsoluteLineNumber++;

        vecCurrentBraceFields=new Vector();
        vecLocalFields.addElement(vecCurrentBraceFields);

        int instructionIndex2=executeInstructions(classObj, strInstructions, intAbsoluteLineNumber, instructionIndex, vecLocalFields);
        intAbsoluteLineNumber+=(instructionIndex2-instructionIndex);
        instructionIndex=instructionIndex2;

        vecLocalFields.removeElementAt(vecLocalFields.size()-1);
        vecCurrentBraceFields=(Vector)vecLocalFields.elementAt(vecLocalFields.size()-1);
      }
      else if(strInstructions[instructionIndex].startsWith("if(")) {
        String strNextLine=strInstructions[instructionIndex];

        String strNextLineCopy=strNextLine.toString();

        strNextLineCopy=strNextLineCopy.substring(3);

        while(true) {
          if(strNextLineCopy.charAt(strNextLineCopy.length()-1)==')') {
            break;
          }

          strNextLineCopy=strNextLineCopy.substring(0, strNextLineCopy.length()-1);
        }

        strNextLineCopy=strNextLineCopy.substring(0, strNextLineCopy.length()-1);

        Vector vecOperands=parseOperands(strNextLineCopy);

        for(int iz=0;iz<vecOperands.size();iz++) {
          String strNextOperand=(String)vecOperands.elementAt(iz);

          executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
        }


        vecCurrentBraceFields=new Vector();
        vecLocalFields.addElement(vecCurrentBraceFields);

        instructionIndex++;
        intAbsoluteLineNumber++;
        if(strNextLine.indexOf('{')!=-1) {

//System.out.println("before:"+instructionIndex);

          int instructionIndex2=executeInstructions(classObj, strInstructions, intAbsoluteLineNumber, instructionIndex, vecLocalFields);
          intAbsoluteLineNumber+=(instructionIndex2-instructionIndex);
          instructionIndex=instructionIndex2;

//System.out.println("after:"+instructionIndex);

        }
        else {
          executeInstruction(classObj, strInstructions, intAbsoluteLineNumber, instructionIndex, vecLocalFields);
          ++intAbsoluteLineNumber;
          ++instructionIndex;
        }
        vecLocalFields.removeElementAt(vecLocalFields.size()-1);
        vecCurrentBraceFields=(Vector)vecLocalFields.elementAt(vecLocalFields.size()-1);
      }
      else if(strInstructions[instructionIndex].startsWith("else if(")) {
        String strNextLine=strInstructions[instructionIndex];

        String strNextLineCopy=strNextLine.toString();

        strNextLineCopy=strNextLineCopy.substring(8);

        while(true) {
          if(strNextLineCopy.charAt(strNextLineCopy.length()-1)==')') {
            break;
          }

          strNextLineCopy=strNextLineCopy.substring(0, strNextLineCopy.length()-1);
        }

        strNextLineCopy=strNextLineCopy.substring(0, strNextLineCopy.length()-1);

        Vector vecOperands=parseOperands(strNextLineCopy);

        for(int iz=0;iz<vecOperands.size();iz++) {
          String strNextOperand=(String)vecOperands.elementAt(iz);

          executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
        }


        vecCurrentBraceFields=new Vector();
        vecLocalFields.addElement(vecCurrentBraceFields);

        instructionIndex++;
        intAbsoluteLineNumber++;
        if(strNextLine.indexOf('{')!=-1) {

//System.out.println("before:"+instructionIndex);

          int instructionIndex2=executeInstructions(classObj, strInstructions, intAbsoluteLineNumber, instructionIndex, vecLocalFields);
          intAbsoluteLineNumber+=(instructionIndex2-instructionIndex);
          instructionIndex=instructionIndex2;

//System.out.println("after:"+instructionIndex);

        }
        else {
          executeInstruction(classObj, strInstructions, intAbsoluteLineNumber, instructionIndex, vecLocalFields);
          ++intAbsoluteLineNumber;
          ++instructionIndex;
        }
        vecLocalFields.removeElementAt(vecLocalFields.size()-1);
        vecCurrentBraceFields=(Vector)vecLocalFields.elementAt(vecLocalFields.size()-1);
      }
      else if(strInstructions[instructionIndex].startsWith("this")) {
        String strNextLine=strInstructions[instructionIndex];

        if(strNextLine.charAt(4)=='.') {
          int intEqualsIndex=strNextLine.indexOf('=');

          if(intEqualsIndex==-1) {
            int intIndex=0;

            while(true) {
              char chr=strNextLine.charAt(intIndex);

              if(chr==';') {
                break;
              }

              ++intIndex;
            }

            String strOperands=strNextLine.substring(0, intIndex);

            Vector vecOperands=parseOperands(strOperands);
            for(int i=0;i<vecOperands.size();i++) {
              String strNextOperand=(String)vecOperands.elementAt(i);
              executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
            }

//            executeCommand(classObj, intAbsoluteLineNumber, strNextLine.substring(0, intIndex), vecLocalFields);

            instructionIndex++;
            intAbsoluteLineNumber++;
          }
          else {
            ++intEqualsIndex;

            while(true) {
              char chr=strNextLine.charAt(intEqualsIndex);

              if(chr!=' ')
                break;

              ++intEqualsIndex;
            }

            strInstructions[instructionIndex]=strInstructions[instructionIndex].substring(intEqualsIndex);
          }
        }
        else if(strNextLine.charAt(4)==';') {
          instructionIndex++;
          intAbsoluteLineNumber++;
        }
        else {
          strNextLine=strNextLine.substring(5);

          Vector vecParameters=new Vector();
          parseParameters(strNextLine, vecParameters, classObj, vecLocalFields, intAbsoluteLineNumber);
//          strNextLine=strNextLine.substring(intIndexPositionAdd);
//          intIndexPosition+=intIndexPositionAdd;

          ConstructorSignature signature=new ConstructorSignature(classObj.getClassName(), vecParameters);

//          if(!vecExecutedConstructors.contains(signature)) {
//            vecExecutedConstructors.addElement(signature);

          if(!vecExecutingConstructors.contains(signature)) {
            vecExecutingConstructors.addElement(signature);

//printConstructorFunctionStack();

            ConstructorObject constructorObj=(ConstructorObject)classObj.getConstructors().get(signature);

            if(constructorObj==null)
              throw new Exception("Constructor not found for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

            Vector vecLocalFields0=new Vector();
            Vector vecCurrentBraceFields0=new Vector();
            vecLocalFields0.addElement(vecCurrentBraceFields0);

            Vector vecConstructorParameters=constructorObj.getConstructorParameters();
            for(int i=0;i<vecConstructorParameters.size();i++)
              vecCurrentBraceFields0.addElement(vecConstructorParameters.elementAt(i));

            if(hashConstructorCounts.containsKey(signature)) {
              long lngCount0=((Long)hashConstructorCounts.get(signature)).longValue();

              for(int i=0;i<vecCounts.size();i++) {
                long lngCount=((Long)vecCounts.elementAt(i)).longValue();
                lngCount+=lngCount0;
                vecCounts.setElementAt(new Long(lngCount), i);
              }
            }
            else {
              String strInstructionsZ[]=constructorObj.getInstructions();
              for(int i=0;i<vecCounts.size();i++) {
                long lngCount=((Long)vecCounts.elementAt(i)).longValue();
                lngCount+=(long)strInstructionsZ.length;
                vecCounts.setElementAt(new Long(lngCount), i);
              }

              vecCounts.addElement(new Long((long)strInstructionsZ.length));
            }

            executeInstructions(classObj, constructorObj.getInstructions(), constructorObj.getAbsoluteLineNumber(), 0, vecLocalFields0);

            if(!hashConstructorCounts.containsKey(signature)) {
              hashConstructorCounts.put(signature, vecCounts.elementAt(vecCounts.size()-1));

              vecCounts.removeElementAt(vecCounts.size()-1);
            }

            vecExecutingConstructors.removeElementAt(vecExecutingConstructors.size()-1);
          }

          instructionIndex++;
          intAbsoluteLineNumber++;
        }
      }
      else if(strInstructions[instructionIndex].startsWith("break;")) {
        instructionIndex++;
        intAbsoluteLineNumber++;
        continue;
      }
      else if(strInstructions[instructionIndex].startsWith("throw ")) {
        String strNextLine=strInstructions[instructionIndex];

        strNextLine=strNextLine.substring(6);

        if(strNextLine.startsWith("new ")) {
          strInstructions[instructionIndex]=strNextLine;
          continue;
        }

        instructionIndex++;
        intAbsoluteLineNumber++;
        continue;
      }
      else if(strInstructions[instructionIndex].startsWith("else")) {
        String strNextLine=strInstructions[instructionIndex];

        vecCurrentBraceFields=new Vector();
        vecLocalFields.addElement(vecCurrentBraceFields);

        instructionIndex++;
        intAbsoluteLineNumber++;
        if(strNextLine.indexOf('{')!=-1) {
          int instructionIndex2=executeInstructions(classObj, strInstructions, intAbsoluteLineNumber, instructionIndex, vecLocalFields);
          intAbsoluteLineNumber+=(instructionIndex2-instructionIndex);
          instructionIndex=instructionIndex2;
        }
        else {
          executeInstruction(classObj, strInstructions, intAbsoluteLineNumber, instructionIndex, vecLocalFields);
          ++intAbsoluteLineNumber;
          ++instructionIndex;
        }
        vecLocalFields.removeElementAt(vecLocalFields.size()-1);
        vecCurrentBraceFields=(Vector)vecLocalFields.elementAt(vecLocalFields.size()-1);
      }
      else if(strInstructions[instructionIndex].startsWith("case")) {
        String strNextLine=strInstructions[instructionIndex];

        int intIndex=strNextLine.indexOf(':');

        ++intIndex;

        while(true) {
          if(intIndex>=strNextLine.length())
            break;

          char chr=strNextLine.charAt(intIndex);

          if(chr!=' ')
            break;

          ++intIndex;
        }

        if(intIndex==strNextLine.length()) {
          instructionIndex++;
          intAbsoluteLineNumber++;
          continue;
        }

        strInstructions[instructionIndex]=strNextLine.substring(intIndex);

        continue;
      }
      else if(strInstructions[instructionIndex].startsWith("public enum ") || strInstructions[instructionIndex].startsWith("protected enum ") || strInstructions[instructionIndex].startsWith("private enum ") || strInstructions[instructionIndex].startsWith("enum ")) {
        ++instructionIndex;
        ++intAbsoluteLineNumber;
        continue;

/*
        int intCurlyBraceCount=1;

        instructionIndex++;
        intAbsoluteLineNumber++;

        boolean blnMustBreak=false;

        while(instructionIndex<strInstructions.length) {
          String strNextLine=strInstructions[instructionIndex];

          for(int i=0;i<strNextLine.length();i++) {
            char chr=strNextLine.charAt(i);

            if(chr=='{') {
              ++intCurlyBraceCount;
            }
            else if(chr=='}') {
              --intCurlyBraceCount;

              if(intCurlyBraceCount==0) {
                blnMustBreak=true;
                break;
              }
            }
          }

          instructionIndex++;
          intAbsoluteLineNumber++;

          if(blnMustBreak)
            break;
        }
*/
      }
      else if(strInstructions[instructionIndex].startsWith("return")) {
        String strNextLine=strInstructions[instructionIndex];

        if(strNextLine.length()==7) {
          instructionIndex++;
          intAbsoluteLineNumber++;
          continue;
        }

        strNextLine=strNextLine.substring(7);

        strInstructions[instructionIndex]=strNextLine;
        continue;
      }
      else if(strInstructions[instructionIndex].startsWith("catch(")) {
        String strNextLine=strInstructions[instructionIndex];

        int intIndex=strNextLine.lastIndexOf('(')+1;

        int intIndex2=intIndex+1;

        while(true) {
          char chr=strNextLine.charAt(intIndex2);

          if(chr==' ')
            break;

          ++intIndex2;
        }

        String strFieldClass=strNextLine.substring(intIndex, intIndex2);

        ++intIndex2;
        intIndex=intIndex2;
        ++intIndex2;

        while(true) {
          char chr=strNextLine.charAt(intIndex2);

          if(chr==' ')
            break;
          else if(chr==')')
            break;

          ++intIndex2;
        }

        String strFieldName=strNextLine.substring(intIndex, intIndex2);


        vecCurrentBraceFields=new Vector();
        vecLocalFields.addElement(vecCurrentBraceFields);

        vecCurrentBraceFields.addElement(new FieldObject(strFieldName, strFieldClass));

        instructionIndex++;
        intAbsoluteLineNumber++;

        int instructionIndex2=executeInstructions(classObj, strInstructions, intAbsoluteLineNumber, instructionIndex, vecLocalFields);
        intAbsoluteLineNumber+=(instructionIndex2-instructionIndex);
        instructionIndex=instructionIndex2;

        vecLocalFields.removeElementAt(vecLocalFields.size()-1);
        vecCurrentBraceFields=(Vector)vecLocalFields.elementAt(vecLocalFields.size()-1);
      }
      else if(strInstructions[instructionIndex].startsWith("try ")) {
        vecCurrentBraceFields=new Vector();
        vecLocalFields.addElement(vecCurrentBraceFields);

        instructionIndex++;
        intAbsoluteLineNumber++;

        int instructionIndex2=executeInstructions(classObj, strInstructions, intAbsoluteLineNumber, instructionIndex, vecLocalFields);
        intAbsoluteLineNumber+=(instructionIndex2-instructionIndex);
        instructionIndex=instructionIndex2;

        vecLocalFields.removeElementAt(vecLocalFields.size()-1);
        vecCurrentBraceFields=(Vector)vecLocalFields.elementAt(vecLocalFields.size()-1);
      }
      else if(strInstructions[instructionIndex].startsWith("finally ")) {
        vecCurrentBraceFields=new Vector();
        vecLocalFields.addElement(vecCurrentBraceFields);

        instructionIndex++;
        intAbsoluteLineNumber++;

        int instructionIndex2=executeInstructions(classObj, strInstructions, intAbsoluteLineNumber, instructionIndex, vecLocalFields);
        intAbsoluteLineNumber+=(instructionIndex2-instructionIndex);
        instructionIndex=instructionIndex2;

        vecLocalFields.removeElementAt(vecLocalFields.size()-1);
        vecCurrentBraceFields=(Vector)vecLocalFields.elementAt(vecLocalFields.size()-1);
      }
      else if(strInstructions[instructionIndex].startsWith("super")) {
        String strNextLine=strInstructions[instructionIndex];

        if(strNextLine.charAt(5)=='.') {
          int intEqualsIndex=strNextLine.indexOf('=');

          if(intEqualsIndex==-1) {
            int intIndex=0;

            while(true) {
              char chr=strNextLine.charAt(intIndex);

              if(chr==';') {
                break;
              }

              ++intIndex;
            }

            String strOperands=strNextLine.substring(0, intIndex);

            Vector vecOperands=parseOperands(strOperands);
            for(int i=0;i<vecOperands.size();i++) {
              String strNextOperand=(String)vecOperands.elementAt(i);
              executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
            }

//            executeCommand(classObj, intAbsoluteLineNumber, strNextLine.substring(0, intIndex), vecLocalFields);

            instructionIndex++;
            intAbsoluteLineNumber++;
          }
          else {
            ++intEqualsIndex;

            while(true) {
              char chr=strNextLine.charAt(intEqualsIndex);

              if(chr!=' ')
                break;

              ++intEqualsIndex;
            }

            strInstructions[instructionIndex]=strInstructions[instructionIndex].substring(intEqualsIndex);
          }
        }
        else {
          strNextLine=strNextLine.substring(6);

          Vector vecParameters=new Vector();
          parseParameters(strNextLine, vecParameters, classObj, vecLocalFields, intAbsoluteLineNumber);
//          strNextLine=strNextLine.substring(intIndexPositionAdd);
//          intIndexPosition+=intIndexPositionAdd;

          String strSuperclass=classObj.getSuperclass();

          ClassObject classObjSuper=(ClassObject)hashClasses.get(strSuperclass);

          if(classObjSuper!=null) {
            ConstructorSignature signature=new ConstructorSignature(classObjSuper.getClassName(), vecParameters);

//            if(!vecExecutedConstructors.contains(signature)) {
//              vecExecutedConstructors.addElement(signature);

            if(!vecExecutingConstructors.contains(signature)) {
              vecExecutingConstructors.addElement(signature);

//printConstructorFunctionStack();

              ConstructorObject constructorObj=(ConstructorObject)classObjSuper.getConstructors().get(signature);

              if(constructorObj==null)
                throw new Exception("Constructor not found for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

              Vector vecLocalFields0=new Vector();
              Vector vecCurrentBraceFields0=new Vector();
              vecLocalFields0.addElement(vecCurrentBraceFields0);

              Vector vecConstructorParameters=constructorObj.getConstructorParameters();
              for(int i=0;i<vecConstructorParameters.size();i++)
                vecCurrentBraceFields0.addElement(vecConstructorParameters.elementAt(i));

              if(hashConstructorCounts.containsKey(signature)) {
                long lngCount0=((Long)hashConstructorCounts.get(signature)).longValue();

                for(int i=0;i<vecCounts.size();i++) {
                  long lngCount=((Long)vecCounts.elementAt(i)).longValue();
                  lngCount+=lngCount0;
                  vecCounts.setElementAt(new Long(lngCount), i);
                }
              }
              else {
                String strInstructionsZ[]=constructorObj.getInstructions();
                for(int i=0;i<vecCounts.size();i++) {
                  long lngCount=((Long)vecCounts.elementAt(i)).longValue();
                  lngCount+=(long)strInstructionsZ.length;
                  vecCounts.setElementAt(new Long(lngCount), i);
                }

                vecCounts.addElement(new Long((long)strInstructionsZ.length));
              }

              executeInstructions(classObjSuper, constructorObj.getInstructions(), constructorObj.getAbsoluteLineNumber(), 0, vecLocalFields0);

              if(!hashConstructorCounts.containsKey(signature)) {
                hashConstructorCounts.put(signature, vecCounts.elementAt(vecCounts.size()-1));

                vecCounts.removeElementAt(vecCounts.size()-1);
              }

              vecExecutingConstructors.removeElementAt(vecExecutingConstructors.size()-1);
            }
          }

          instructionIndex++;
          intAbsoluteLineNumber++;
        }
      }
      else if(strInstructions[instructionIndex].startsWith("while(")) {
        String strNextLine=strInstructions[instructionIndex];
        String strNextLineCopy=strNextLine.toString();
        strNextLineCopy=strNextLineCopy.substring(6);

        while(true) {
          if(strNextLineCopy.charAt(strNextLineCopy.length()-1)==')') {
            break;
          }

          strNextLineCopy=strNextLineCopy.substring(0, strNextLineCopy.length()-1);
        }

        strNextLineCopy=strNextLineCopy.substring(0, strNextLineCopy.length()-1);

        Vector vecOperands=parseOperands(strNextLineCopy);

        for(int iz=0;iz<vecOperands.size();iz++) {
          String strNextOperand=(String)vecOperands.elementAt(iz);

          executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
        }


        vecCurrentBraceFields=new Vector();
        vecLocalFields.addElement(vecCurrentBraceFields);

        instructionIndex++;
        intAbsoluteLineNumber++;
        if(strNextLine.indexOf('{')!=-1) {
          int instructionIndex2=executeInstructions(classObj, strInstructions, intAbsoluteLineNumber, instructionIndex, vecLocalFields);
          intAbsoluteLineNumber+=(instructionIndex2-instructionIndex);
          instructionIndex=instructionIndex2;
        }
        else {
          executeInstruction(classObj, strInstructions, intAbsoluteLineNumber, instructionIndex, vecLocalFields);
          ++intAbsoluteLineNumber;
          ++instructionIndex;
        }
        vecLocalFields.removeElementAt(vecLocalFields.size()-1);
        vecCurrentBraceFields=(Vector)vecLocalFields.elementAt(vecLocalFields.size()-1);
      }
      else if(strInstructions[instructionIndex].startsWith("} while")) {
        String strNextLine=strInstructions[instructionIndex];

        strNextLine=strNextLine.substring(8);

        while(true) {
          if(strNextLine.charAt(strNextLine.length()-1)==')') {
            break;
          }

          strNextLine=strNextLine.substring(0, strNextLine.length()-1);
        }

        strNextLine=strNextLine.substring(0, strNextLine.length()-1);

        Vector vecOperands=parseOperands(strNextLine);

        for(int iz=0;iz<vecOperands.size();iz++) {
          String strNextOperand=(String)vecOperands.elementAt(iz);

          executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
        }


        ++instructionIndex;
        ++intAbsoluteLineNumber;

        --DeadlockExecutorCounter.intBraceIndex;

        break;
      }
      else if(strInstructions[instructionIndex].startsWith("}")) {
        ++instructionIndex;
        ++intAbsoluteLineNumber;

        --DeadlockExecutorCounter.intBraceIndex;

        hashBraceSynchronized.remove(new Integer(DeadlockExecutorCounter.intBraceIndex));
        hashBraceMarker.remove(new Integer(DeadlockExecutorCounter.intBraceIndex));

        break;
      }
      else if(strInstructions[instructionIndex].startsWith(";")) {
        instructionIndex++;
        intAbsoluteLineNumber++;
        continue;
      }
      else {
        String strNextLine=strInstructions[instructionIndex];
//System.out.println("strNextLine:"+strNextLine);

        int intIndex=0;

        if(strNextLine.startsWith("(")) {
          int intParenthesisCount=1;

          int intIndex2=1;

          while(true) {
            char chr=strNextLine.charAt(intIndex2);

            if(chr=='(') {
              ++intParenthesisCount;
            }
            else if(chr==')') {
              --intParenthesisCount;

              if(intParenthesisCount==0)
                break;
            }

            ++intIndex2;
          }

          ++intIndex2;

          int intEqualsIndex=strNextLine.indexOf("=", intIndex2);

          if(intEqualsIndex==-1) {
            Vector vecOperands=parseOperands(strNextLine.substring(0, strNextLine.lastIndexOf(';')));

            for(int i=0;i<vecOperands.size();i++)
              executeOperand((String)vecOperands.elementAt(i), classObj, intAbsoluteLineNumber, vecLocalFields);
          }
          else {
            Vector vecOperands=parseOperands(strNextLine.substring(intEqualsIndex+1, strNextLine.lastIndexOf(';')));

            for(int i=0;i<vecOperands.size();i++)
              executeOperand((String)vecOperands.elementAt(i), classObj, intAbsoluteLineNumber, vecLocalFields);
          }

          ++instructionIndex;
          ++intAbsoluteLineNumber;
        }
        else {
          int intIndexEquals=strNextLine.indexOf('=');

          if(intIndexEquals==-1) {
            int intIndexParenthesis=strNextLine.indexOf('(');

            if(intIndexParenthesis==-1) {
              intIndex=strNextLine.lastIndexOf(';');

              int intIndexZ=intIndex-1;

              while(true) {
                if(intIndexZ<0)
                  break;

                char chr=strNextLine.charAt(intIndexZ);

                if(chr==' ')
                  break;

                --intIndexZ;
              }

              if(intIndexZ==-1) {
                while(true) {
                  char chr=strNextLine.charAt(intIndex);

                  if(chr==';') {
                    break;
                  }

                  ++intIndex;
                }

                Vector vecOperands=parseOperands(strNextLine.substring(0, intIndex));

                for(int i=0;i<vecOperands.size();i++)
                  executeOperand((String)vecOperands.elementAt(i), classObj, intAbsoluteLineNumber, vecLocalFields);

                ++instructionIndex;
                ++intAbsoluteLineNumber;

                continue;
              }

              String strFieldName=strNextLine.substring(intIndexZ+1, intIndex);

              String strArray="";
              if(strFieldName.endsWith("[]")) {
                while(true) {
                  if(strFieldName.endsWith("[]")) {
                    strArray+="[]";
                    strFieldName=strFieldName.substring(0, strFieldName.length()-2);
                    continue;
                  }

                  break;
                }
              }

              if(strArray.length()==0) {
                if(strFieldName.startsWith("[]")) {
                  while(true) {
                    if(strFieldName.startsWith("[]")) {
                      strArray+="[]";
                      strFieldName=strFieldName.substring(2);
                      continue;
                    }

                    break;
                  }
                }
              }

              String strFieldClass=strNextLine.substring(0, intIndexZ);
              strFieldClass=strFieldClass.replace(".", "$");

              strFieldClass=(String)hashImported.get(strFieldClass);

              if(strFieldClass==null) {
                strFieldClass=strNextLine.substring(0, intIndexZ);
                strFieldClass=strFieldClass.replace(".", "$");

                int intDollarIndex0=strFieldClass.indexOf("$");

                if(intDollarIndex0!=-1) {
                  String strFieldClass0=strFieldClass.substring(0, intDollarIndex0);

                  strFieldClass0=(String)hashImported.get(strFieldClass0);

                  strFieldClass=strFieldClass0+"$"+strFieldClass.substring(intDollarIndex0+1);
                }
                else {
                  String strFieldClass0=classObj.getClassName();

                  int intDollarIndex=strFieldClass0.indexOf("$");

                  if(intDollarIndex==-1) {
                    strFieldClass=strFieldClass0+"$"+strFieldClass;
                  }
                  else {
                    strFieldClass=strFieldClass0.substring(0, intDollarIndex+1)+strFieldClass;
                  }
                }
              }

              if(strArray.length()>0)
                strFieldClass+=strArray;

//if(strFieldClass.equals("null"))
//System.out.println("added field:"+strFieldClass+" "+strFieldName);
              vecCurrentBraceFields.addElement(new FieldObject(strFieldName, strFieldClass));
            }
            else {
              while(true) {
                char chr=strNextLine.charAt(intIndex);

                if(chr==';') {
                  break;
                }

                ++intIndex;
              }

              Vector vecOperands=parseOperands(strNextLine.substring(0, intIndex));

              for(int i=0;i<vecOperands.size();i++)
                executeOperand((String)vecOperands.elementAt(i), classObj, intAbsoluteLineNumber, vecLocalFields);

//              executeCommand(classObj, intAbsoluteLineNumber, strNextLine.substring(0, intIndex), vecLocalFields);
            }

            ++instructionIndex;
            ++intAbsoluteLineNumber;
          }
          else {
            intIndex=intIndexEquals;

            int intIndexZ=intIndex-1;

            while(true) {
              if(intIndexZ<0)
                break;

              char chr=strNextLine.charAt(intIndexZ);

              if(chr==' ')
                break;

              --intIndexZ;
            }

            FieldObject fieldObj=null;

            if(intIndexZ==-1) {
              intIndexZ=strNextLine.indexOf('[');

              if(intIndexZ==-1)
                intIndexZ=Integer.MAX_VALUE;

              if(intIndexZ<intIndexEquals) {
                int intBracketCount=1;

                intIndexZ+=1;
                int intIndexZZ=intIndexZ;

                while(true) {
                  char chr=strNextLine.charAt(intIndexZZ);

                  if(chr=='[') {
                    ++intBracketCount;
                  }
                  else if(chr==']') {
                    --intBracketCount;

                    if(intBracketCount==0)
                      break;
                  }

                  ++intIndexZZ;
                }

                String strOperands=strNextLine.substring(intIndexZ, intIndexZZ);

                Vector vecOperands=parseOperands(strOperands);

                for(int i=0;i<vecOperands.size();i++)
                  executeOperand((String)vecOperands.elementAt(i), classObj, intAbsoluteLineNumber, vecLocalFields);
              }
            }
//end if(intIndexZ==-1) {
            else {
              String strFieldName=strNextLine.substring(intIndexZ+1, intIndex);

              String strArray="";
              if(strFieldName.endsWith("[]")) {
                while(true) {
                  if(strFieldName.endsWith("[]")) {
                    strArray+="[]";
                    strFieldName=strFieldName.substring(0, strFieldName.length()-2);
                    continue;
                  }

                  break;
                }
              }

              if(strArray.length()==0) {
                if(strFieldName.startsWith("[]")) {
                  while(true) {
                    if(strFieldName.startsWith("[]")) {
                      strArray+="[]";
                      strFieldName=strFieldName.substring(2);
                      continue;
                    }

                    break;
                  }
                }
              }

              String strFieldClass=strNextLine.substring(0, intIndexZ);
              strFieldClass=strFieldClass.replace(".", "$");

              strFieldClass=(String)hashImported.get(strFieldClass);

              if(strFieldClass==null) {
                strFieldClass=strNextLine.substring(0, intIndexZ);
                strFieldClass=strFieldClass.replace(".", "$");

                int intDollarIndex0=strFieldClass.indexOf("$");

                if(intDollarIndex0!=-1) {
                  String strFieldClass0=strFieldClass.substring(0, intDollarIndex0);

                  strFieldClass0=(String)hashImported.get(strFieldClass0);

                  strFieldClass=strFieldClass0+"$"+strFieldClass.substring(intDollarIndex0+1);
                }
                else {
                  String strFieldClass0=classObj.getClassName();

                  int intDollarIndex=strFieldClass0.indexOf("$");

                  if(intDollarIndex==-1) {
                    strFieldClass=strFieldClass0+"$"+strFieldClass;
                  }
                  else {
                    strFieldClass=strFieldClass0.substring(0, intDollarIndex+1)+strFieldClass;
                  }
                }
              }

              if(strArray.length()>0)
                strFieldClass+=strArray;

//System.out.println("added field:"+strFieldClass+" "+strFieldName);

              fieldObj=new FieldObject(strFieldName, strFieldClass);

              vecCurrentBraceFields.addElement(fieldObj);
            }

            if(strNextLine.substring(intIndexEquals+1).startsWith("{")) {
              int intIndexA=intIndexEquals+2;
              int intIndexA2=intIndexEquals+2;

              int intBraceCount=1;

              while(true) {
                char chr=strNextLine.charAt(intIndexA2);

                if(chr=='{') {
                  ++intBraceCount;
                }
                else if(chr=='}') {
                  --intBraceCount;

                  if(intBraceCount==0)
                    break;
                }

                ++intIndexA2;
              }


              String strInitializer=strNextLine.substring(intIndexA, intIndexA2);
              parseArrayInitializer(strInitializer, classObj, intAbsoluteLineNumber, vecLocalFields);

              ++instructionIndex;
              ++intAbsoluteLineNumber;
            }
            else if(strNextLine.substring(intIndexEquals+1).startsWith("new ")) {
              strInstructions[instructionIndex]=strInstructions[instructionIndex].substring(intIndexEquals+1);

              continue;
            }
            else {
              intIndex=intIndexEquals;

              ++intIndex;

              char chr='a';

              while(true) {
                chr=strNextLine.charAt(intIndex);

                if(chr!=' ')
                  break;

                ++intIndex;
              }

//System.out.println("before parseOperands:"+strNextLine);
              Vector vecOperands=parseOperands(strNextLine.substring(intIndex));

              for(int i=0;i<vecOperands.size();i++)
                executeOperand((String)vecOperands.elementAt(i), classObj, intAbsoluteLineNumber, vecLocalFields);

              ++instructionIndex;
              ++intAbsoluteLineNumber;
            }
          }
        }
      }
    }

    DeadlockExecutorCounter.strFilePath=strFilePathPrevious.toString();

    DeadlockExecutorCounter.hashImported=hashImportedPrevious;

//    return intAbsoluteLineNumber;
    return instructionIndex;
  }

  public static void executeInstruction(ClassObject classObj, String strInstructions0[], int intAbsoluteLineNumber, int instructionIndex, Vector vecLocalFields) throws Exception {
//    DeadlockExecutorCounter.strFilePath=classObj.getFilePath();

//    ++DeadlockExecutorCounter.intBraceIndex;

//    DeadlockExecutorCounter.hashImported=classObj.getImported();

    Vector vecCurrentBraceFields=(Vector)vecLocalFields.elementAt(vecLocalFields.size()-1);

//    String strOuterClass=classObj.getOuterClass();
//    if(strOuterClass.length()==0)
//      strOuterClass=classObj.getClassName();
    
    String strInstructions[]=new String[strInstructions0.length];
    System.arraycopy(strInstructions0, 0, strInstructions, 0, strInstructions.length);

    String strClassLines=classObj.getClassName();
    int intClassLinesDollarIndex=strClassLines.indexOf("$");
    if(intClassLinesDollarIndex!=-1)
      strClassLines=strClassLines.substring(0, intClassLinesDollarIndex);
    Vector vecClassLines=(Vector)hashClassesLines.get(strClassLines);

    int instructionEndIndex=instructionIndex+1;

    while(instructionIndex<instructionEndIndex) {
      boolean blnClassLine=((Boolean)vecClassLines.elementAt(intAbsoluteLineNumber-1)).booleanValue();
      if(blnClassLine) {
//        ++instructionIndex;
//        ++intAbsoluteLineNumber;
        return;
      }

//System.out.println(strInstructions[instructionIndex]);

      vecClassLines.setElementAt(new Boolean(true), intAbsoluteLineNumber-1);

      strInstructions[instructionIndex]=trimString(strInstructions[instructionIndex]);

//for(int i=0;i<vecExecutedInstructions.size();i++) {
//String strNextInstr=(String)vecExecutedInstructions.elementAt(i);
//if(strNextInstr.equals(strInstructions[instructionIndex]))
//System.out.println(i+":"+strNextInstr);
//}

if(blnDoShowOutput)
System.out.println("instructionSingle: "+strInstructions[instructionIndex]);

      if(strInstructions[instructionIndex].startsWith("continue;")) {
//        instructionIndex++;
//        intAbsoluteLineNumber++;
//        continue;
      }
      else if(strInstructions[instructionIndex].startsWith("for(")) {
        throw new Exception("Encountered \"for\" in a single instruction block for file: "+strFilePath+":"+intAbsoluteLineNumber);
      }
      else if(strInstructions[instructionIndex].startsWith("new ")) {
        String strNextLine=strInstructions[instructionIndex];

        int intIndexZ0=strNextLine.lastIndexOf(')');

        int intIndexZ1=strNextLine.lastIndexOf(']');

        if(intIndexZ1>intIndexZ0) {
          int intBracketCount=1;

          int intIndex0=intIndexZ1-1;

          while(true) {
            char chr=strNextLine.charAt(intIndex0);
 
            if(chr=='[') {
              --intBracketCount;

              if(intBracketCount==0)
                break;
            }
            else if(chr==']') {
              ++intBracketCount;
            }

            --intIndex0;
          }

          ++intIndex0;

          String strOperands=strNextLine.substring(intIndex0, intIndexZ1);

          Vector vecOperands=parseOperands(strOperands);
          for(int i=0;i<vecOperands.size();i++) {
            String strNextOperand=(String)vecOperands.elementAt(i);
            executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
          }

//          instructionIndex++;
//          intAbsoluteLineNumber++;
        }
        else {
          parseNew(classObj, vecLocalFields, strNextLine, intAbsoluteLineNumber, classObj.getClassName());

//          int intParseNewAdd=parseNew(classObj, vecLocalFields, strNextLine, intAbsoluteLineNumber);

//          strNextLine=strNextLine.substring(intParseNewAdd);

/*
          int intIndex=0;

          while(true) {
            char chr=strNextLine.charAt(intIndex);

            if(chr==';') {
              break;
            }

            ++intIndex;
          }

          String strOperands=strNextLine.substring(0, intIndex);

          Vector vecOperands=parseOperands(strOperands);
          for(int i=0;i<vecOperands.size();i++) {
            String strNextOperand=(String)vecOperands.elementAt(i);
            executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
          }

//System.out.println("before new: "+strNextLine.substring(0, intIndex));
//          executeCommand(classObj, intAbsoluteLineNumber, strNextLine.substring(0, intIndex), vecLocalFields);

*/

//          instructionIndex++;
//          intAbsoluteLineNumber++;

          int intCurlyBraceIndex=strNextLine.indexOf('{');
          if(intCurlyBraceIndex!=-1) {
            throw new Exception("Encountered \"{\" in a single instruction block for file: "+strFilePath+":"+intAbsoluteLineNumber);
          }
        }
      }
      else if(strInstructions[instructionIndex].startsWith("switch(")) {
        throw new Exception("Encountered \"switch\" in a single instruction block for file: "+strFilePath+":"+intAbsoluteLineNumber);
      }
      else if(strInstructions[instructionIndex].startsWith("assert ")) {
        String strNextLine=strInstructions[instructionIndex];
        strNextLine=strNextLine.substring(7);
        int intColonIndex=strNextLine.indexOf(':');

        while(true) {
           if(strNextLine.charAt(0)==' ') {
             strNextLine=strNextLine.substring(1);
             continue;
           }

           break;
        }

        if(intColonIndex==-1) {
          int intEndIndex=1;
          while(true) {
            if(strNextLine.charAt(intEndIndex)==' ' || strNextLine.charAt(intEndIndex)==';')
              break;

            ++intEndIndex;
          }

          String strOperands=strNextLine.substring(0, intEndIndex);

          Vector vecOperands=parseOperands(strOperands);
          for(int i=0;i<vecOperands.size();i++) {
            String strNextOperand=(String)vecOperands.elementAt(i);
            executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
          }

//          executeCommand(classObj, intAbsoluteLineNumber, strNextLine.substring(0, intEndIndex), vecLocalFields);
        }
        else {
          int intEndIndex=1;
          while(true) {
            if(strNextLine.charAt(intEndIndex)==' ' || strNextLine.charAt(intEndIndex)==':')
              break;

            ++intEndIndex;
          }

          String strOperands=strNextLine.substring(0, intEndIndex);

          Vector vecOperands=parseOperands(strOperands);
          for(int i=0;i<vecOperands.size();i++) {
            String strNextOperand=(String)vecOperands.elementAt(i);
            executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
          }

//          executeCommand(classObj, intAbsoluteLineNumber, strNextLine.substring(0, intEndIndex), vecLocalFields);

          strNextLine=strNextLine.substring(intColonIndex+1);

          while(true) {
             if(strNextLine.charAt(0)==' ') {
               strNextLine=strNextLine.substring(1);
               continue;
             }

             break;
          }

          intEndIndex=1;
          while(true) {
            if(strNextLine.charAt(intEndIndex)==' ' || strNextLine.charAt(intEndIndex)==';')
              break;

            ++intEndIndex;
          }

          strOperands=strNextLine.substring(0, intEndIndex);

          vecOperands=parseOperands(strOperands);
          for(int i=0;i<vecOperands.size();i++) {
            String strNextOperand=(String)vecOperands.elementAt(i);
            executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
          }

//          executeCommand(classObj, intAbsoluteLineNumber, strNextLine.substring(0, intEndIndex), vecLocalFields);
        }

//        instructionIndex++;
//        intAbsoluteLineNumber++;
      }
      else if(strInstructions[instructionIndex].startsWith("default:")) {
//        instructionIndex++;
//        intAbsoluteLineNumber++;
//        continue;
      }
      else if(strInstructions[instructionIndex].startsWith("goto")) {
//not used
//        instructionIndex++;
//        intAbsoluteLineNumber++;
      }
      else if(strInstructions[instructionIndex].startsWith("synchronized(")) {
        throw new Exception("Encountered \"synchronized\" in a single instruction block for file: "+strFilePath+":"+intAbsoluteLineNumber);
      }
      else if(strInstructions[instructionIndex].startsWith("do ")) {
        throw new Exception("Encountered \"do\" in a single instruction block for file: "+strFilePath+":"+intAbsoluteLineNumber);
      }
      else if(strInstructions[instructionIndex].startsWith("if(")) {
        throw new Exception("Encountered \"if\" in a single instruction block for file: "+strFilePath+":"+intAbsoluteLineNumber);
      }
      else if(strInstructions[instructionIndex].startsWith("else if(")) {
        throw new Exception("Encountered \"else if\" in a single instruction block for file: "+strFilePath+":"+intAbsoluteLineNumber);
      }
      else if(strInstructions[instructionIndex].startsWith("this")) {
        String strNextLine=strInstructions[instructionIndex];

        if(strNextLine.charAt(4)=='.') {
          int intEqualsIndex=strNextLine.indexOf('=');

          if(intEqualsIndex==-1) {
            int intIndex=0;

            while(true) {
              char chr=strNextLine.charAt(intIndex);

              if(chr==';') {
                break;
              }

              ++intIndex;
            }

            String strOperands=strNextLine.substring(0, intIndex);

            Vector vecOperands=parseOperands(strOperands);
            for(int i=0;i<vecOperands.size();i++) {
              String strNextOperand=(String)vecOperands.elementAt(i);
              executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
            }

//            executeCommand(classObj, intAbsoluteLineNumber, strNextLine.substring(0, intIndex), vecLocalFields);

//            instructionIndex++;
//            intAbsoluteLineNumber++;
          }
          else {
            ++intEqualsIndex;

            while(true) {
              char chr=strNextLine.charAt(intEqualsIndex);

              if(chr!=' ')
                break;

              ++intEqualsIndex;
            }

            strInstructions[instructionIndex]=strInstructions[instructionIndex].substring(intEqualsIndex);
            continue;
          }
        }
        else if(strNextLine.charAt(4)==';') {
//          instructionIndex++;
//          intAbsoluteLineNumber++;
        }
        else {
          strNextLine=strNextLine.substring(5);

          Vector vecParameters=new Vector();
          parseParameters(strNextLine, vecParameters, classObj, vecLocalFields, intAbsoluteLineNumber);
//          strNextLine=strNextLine.substring(intIndexPositionAdd);
//          intIndexPosition+=intIndexPositionAdd;

          ConstructorSignature signature=new ConstructorSignature(classObj.getClassName(), vecParameters);

//          if(!vecExecutedConstructors.contains(signature)) {
//            vecExecutedConstructors.addElement(signature);

          if(!vecExecutingConstructors.contains(signature)) {
            vecExecutingConstructors.addElement(signature);

//printConstructorFunctionStack();

            ConstructorObject constructorObj=(ConstructorObject)classObj.getConstructors().get(signature);

            if(constructorObj==null)
              throw new Exception("Constructor not found for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

            Vector vecLocalFields0=new Vector();
            Vector vecCurrentBraceFields0=new Vector();
            vecLocalFields0.addElement(vecCurrentBraceFields0);

            Vector vecConstructorParameters=constructorObj.getConstructorParameters();
            for(int i=0;i<vecConstructorParameters.size();i++)
              vecCurrentBraceFields0.addElement(vecConstructorParameters.elementAt(i));

            if(hashConstructorCounts.containsKey(signature)) {
              long lngCount0=((Long)hashConstructorCounts.get(signature)).longValue();

              for(int i=0;i<vecCounts.size();i++) {
                long lngCount=((Long)vecCounts.elementAt(i)).longValue();
                lngCount+=lngCount0;
                vecCounts.setElementAt(new Long(lngCount), i);
              }
            }
            else {
              String strInstructionsZ[]=constructorObj.getInstructions();
              for(int i=0;i<vecCounts.size();i++) {
                long lngCount=((Long)vecCounts.elementAt(i)).longValue();
                lngCount+=(long)strInstructionsZ.length;
                vecCounts.setElementAt(new Long(lngCount), i);
              }

              vecCounts.addElement(new Long((long)strInstructionsZ.length));
            }

            executeInstructions(classObj, constructorObj.getInstructions(), constructorObj.getAbsoluteLineNumber(), 0, vecLocalFields0);

            if(!hashConstructorCounts.containsKey(signature)) {
              hashConstructorCounts.put(signature, vecCounts.elementAt(vecCounts.size()-1));

              vecCounts.removeElementAt(vecCounts.size()-1);
            }

            vecExecutingConstructors.removeElementAt(vecExecutingConstructors.size()-1);
          }

//          instructionIndex++;
//          intAbsoluteLineNumber++;
        }
      }
      else if(strInstructions[instructionIndex].startsWith("break;")) {
//        instructionIndex++;
//        intAbsoluteLineNumber++;
//        continue;
      }
      else if(strInstructions[instructionIndex].startsWith("throw ")) {
//        instructionIndex++;
//        intAbsoluteLineNumber++;
//        continue;
      }
      else if(strInstructions[instructionIndex].startsWith("else")) {
        throw new Exception("Encountered \"else\" in a single instruction block for file: "+strFilePath+":"+intAbsoluteLineNumber);
      }
      else if(strInstructions[instructionIndex].startsWith("case")) {
        throw new Exception("Encountered \"case\" in a single instruction block for file: "+strFilePath+":"+intAbsoluteLineNumber);
      }
      else if(strInstructions[instructionIndex].startsWith("public enum ") || strInstructions[instructionIndex].startsWith("protected enum ") || strInstructions[instructionIndex].startsWith("private enum ") || strInstructions[instructionIndex].startsWith("enum ")) {
        throw new Exception("Encountered \"enum\" in a single instruction block for file: "+strFilePath+":"+intAbsoluteLineNumber);
      }
      else if(strInstructions[instructionIndex].startsWith("return")) {
        String strNextLine=strInstructions[instructionIndex];

        if(strNextLine.length()==7) {
//          instructionIndex++;
//          intAbsoluteLineNumber++;
        }
        else {
          strNextLine=strNextLine.substring(7);

          strInstructions[instructionIndex]=strNextLine;
          continue;
        }

//        instructionIndex++;
//        intAbsoluteLineNumber++;
//        continue;
      }
      else if(strInstructions[instructionIndex].startsWith("catch(")) {
        throw new Exception("Encountered \"catch\" in a single instruction block for file: "+strFilePath+":"+intAbsoluteLineNumber);
      }
      else if(strInstructions[instructionIndex].startsWith("try ")) {
        throw new Exception("Encountered \"try\" in a single instruction block for file: "+strFilePath+":"+intAbsoluteLineNumber);
      }
      else if(strInstructions[instructionIndex].startsWith("finally ")) {
        throw new Exception("Encountered \"finally\" in a single instruction block for file: "+strFilePath+":"+intAbsoluteLineNumber);
      }
      else if(strInstructions[instructionIndex].startsWith("super")) {
        String strNextLine=strInstructions[instructionIndex];

        if(strNextLine.charAt(5)=='.') {
          int intEqualsIndex=strNextLine.indexOf('=');

          if(intEqualsIndex==-1) {
            int intIndex=0;

            while(true) {
              char chr=strNextLine.charAt(intIndex);

              if(chr==';') {
                break;
              }

              ++intIndex;
            }

            String strOperands=strNextLine.substring(0, intIndex);

            Vector vecOperands=parseOperands(strOperands);
            for(int i=0;i<vecOperands.size();i++) {
              String strNextOperand=(String)vecOperands.elementAt(i);
              executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
            }

//            executeCommand(classObj, intAbsoluteLineNumber, strNextLine.substring(0, intIndex), vecLocalFields);

//            instructionIndex++;
//            intAbsoluteLineNumber++;
          }
          else {
            ++intEqualsIndex;

            while(true) {
              char chr=strNextLine.charAt(intEqualsIndex);

              if(chr!=' ')
                break;

              ++intEqualsIndex;
            }

            strInstructions[instructionIndex]=strInstructions[instructionIndex].substring(intEqualsIndex);
            continue;
          }
        }
        else {
          strNextLine=strNextLine.substring(6);

          Vector vecParameters=new Vector();
          parseParameters(strNextLine, vecParameters, classObj, vecLocalFields, intAbsoluteLineNumber);
//          strNextLine=strNextLine.substring(intIndexPositionAdd);
//          intIndexPosition+=intIndexPositionAdd;

          String strSuperclass=classObj.getSuperclass();

          ClassObject classObjSuper=(ClassObject)hashClasses.get(strSuperclass);

          if(classObjSuper!=null) {
            ConstructorSignature signature=new ConstructorSignature(classObjSuper.getClassName(), vecParameters);

//            if(!vecExecutedConstructors.contains(signature)) {
//              vecExecutedConstructors.addElement(signature);

            if(!vecExecutingConstructors.contains(signature)) {
              vecExecutingConstructors.addElement(signature);

//printConstructorFunctionStack();

              ConstructorObject constructorObj=(ConstructorObject)classObjSuper.getConstructors().get(signature);

              if(constructorObj==null)
                throw new Exception("Constructor not found for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

              Vector vecLocalFields0=new Vector();
              Vector vecCurrentBraceFields0=new Vector();
              vecLocalFields0.addElement(vecCurrentBraceFields0);

              Vector vecConstructorParameters=constructorObj.getConstructorParameters();
              for(int i=0;i<vecConstructorParameters.size();i++)
                vecCurrentBraceFields0.addElement(vecConstructorParameters.elementAt(i));

              if(hashConstructorCounts.containsKey(signature)) {
                long lngCount0=((Long)hashConstructorCounts.get(signature)).longValue();

                for(int i=0;i<vecCounts.size();i++) {
                  long lngCount=((Long)vecCounts.elementAt(i)).longValue();
                  lngCount+=lngCount0;
                  vecCounts.setElementAt(new Long(lngCount), i);
                }
              }
              else {
                String strInstructionsZ[]=constructorObj.getInstructions();
                for(int i=0;i<vecCounts.size();i++) {
                  long lngCount=((Long)vecCounts.elementAt(i)).longValue();
                  lngCount+=(long)strInstructionsZ.length;
                  vecCounts.setElementAt(new Long(lngCount), i);
                }

                vecCounts.addElement(new Long((long)strInstructionsZ.length));
              }

              executeInstructions(classObjSuper, constructorObj.getInstructions(), constructorObj.getAbsoluteLineNumber(), 0, vecLocalFields0);

              if(!hashConstructorCounts.containsKey(signature)) {
                hashConstructorCounts.put(signature, vecCounts.elementAt(vecCounts.size()-1));

                vecCounts.removeElementAt(vecCounts.size()-1);
              }

              vecExecutingConstructors.removeElementAt(vecExecutingConstructors.size()-1);
            }
          }

//          instructionIndex++;
//          intAbsoluteLineNumber++;
        }
      }
      else if(strInstructions[instructionIndex].startsWith("while(")) {
        throw new Exception("Encountered \"while\" in a single instruction block for file: "+strFilePath+":"+intAbsoluteLineNumber);
      }
      else if(strInstructions[instructionIndex].startsWith("} while")) {
        throw new Exception("Encountered \"do while end\" in a single instruction block for file: "+strFilePath+":"+intAbsoluteLineNumber);
      }
      else if(strInstructions[instructionIndex].startsWith("}")) {
        throw new Exception("Encountered \"}\" in a single instruction block for file: "+strFilePath+":"+intAbsoluteLineNumber);
      }
      else if(strInstructions[instructionIndex].startsWith(";")) {
//        instructionIndex++;
//        intAbsoluteLineNumber++;
//        continue;
      }
      else {
        String strNextLine=strInstructions[instructionIndex];
//System.out.println("strNextLine:"+strNextLine);

        int intIndex=0;

        if(strNextLine.startsWith("(")) {
          int intParenthesisCount=1;

          int intIndex2=1;

          while(true) {
            char chr=strNextLine.charAt(intIndex2);

            if(chr=='(') {
              ++intParenthesisCount;
            }
            else if(chr==')') {
              --intParenthesisCount;

              if(intParenthesisCount==0)
                break;
            }

            ++intIndex2;
          }

          ++intIndex2;

          int intEqualsIndex=strNextLine.indexOf("=", intIndex2);

          if(intEqualsIndex==-1) {
            Vector vecOperands=parseOperands(strNextLine.substring(0, strNextLine.lastIndexOf(';')));

            for(int i=0;i<vecOperands.size();i++)
              executeOperand((String)vecOperands.elementAt(i), classObj, intAbsoluteLineNumber, vecLocalFields);
          }
          else {
            Vector vecOperands=parseOperands(strNextLine.substring(intEqualsIndex+1, strNextLine.lastIndexOf(';')));

            for(int i=0;i<vecOperands.size();i++)
              executeOperand((String)vecOperands.elementAt(i), classObj, intAbsoluteLineNumber, vecLocalFields);
          }

//          ++instructionIndex;
//          ++intAbsoluteLineNumber;
        }
        else {
          int intIndexEquals=strNextLine.indexOf('=');

          if(intIndexEquals==-1) {
            int intIndexParenthesis=strNextLine.indexOf('(');

            if(intIndexParenthesis==-1) {
              intIndex=strNextLine.lastIndexOf(';');

              int intIndexZ=intIndex-1;

              while(true) {
                if(intIndexZ<0)
                  break;

                char chr=strNextLine.charAt(intIndexZ);

                if(chr==' ')
                  break;

                --intIndexZ;
              }

              if(intIndexZ==-1) {
                while(true) {
                  char chr=strNextLine.charAt(intIndex);

                  if(chr==';') {
                    break;
                  }

                  ++intIndex;
                }

                Vector vecOperands=parseOperands(strNextLine.substring(0, intIndex));

                for(int i=0;i<vecOperands.size();i++)
                  executeOperand((String)vecOperands.elementAt(i), classObj, intAbsoluteLineNumber, vecLocalFields);

                break;
              }

              String strFieldName=strNextLine.substring(intIndexZ+1, intIndex);

              String strArray="";
              if(strFieldName.endsWith("[]")) {
                while(true) {
                  if(strFieldName.endsWith("[]")) {
                    strArray+="[]";
                    strFieldName=strFieldName.substring(0, strFieldName.length()-2);
                    continue;
                  }

                  break;
                }
              }

              if(strArray.length()==0) {
                if(strFieldName.startsWith("[]")) {
                  while(true) {
                    if(strFieldName.startsWith("[]")) {
                      strArray+="[]";
                      strFieldName=strFieldName.substring(2);
                      continue;
                    }

                    break;
                  }
                }
              }

              String strFieldClass=strNextLine.substring(0, intIndexZ);
              strFieldClass=strFieldClass.replace(".", "$");

              strFieldClass=(String)hashImported.get(strFieldClass);

              if(strFieldClass==null) {
                strFieldClass=strNextLine.substring(0, intIndexZ);
                strFieldClass=strFieldClass.replace(".", "$");

                int intDollarIndex0=strFieldClass.indexOf("$");

                if(intDollarIndex0!=-1) {
                  String strFieldClass0=strFieldClass.substring(0, intDollarIndex0);

                  strFieldClass0=(String)hashImported.get(strFieldClass0);

                  strFieldClass=strFieldClass0+"$"+strFieldClass.substring(intDollarIndex0+1);
                }
                else {
                  String strFieldClass0=classObj.getClassName();

                  int intDollarIndex=strFieldClass0.indexOf("$");

                  if(intDollarIndex==-1) {
                    strFieldClass=strFieldClass0+"$"+strFieldClass;
                  }
                  else {
                    strFieldClass=strFieldClass0.substring(0, intDollarIndex+1)+strFieldClass;
                  }
                }
              }

              if(strArray.length()>0)
                strFieldClass+=strArray;

//System.out.println("added field:"+strFieldClass+" "+strFieldName);
              vecCurrentBraceFields.addElement(new FieldObject(strFieldName, strFieldClass));
            }
            else {
              while(true) {
                char chr=strNextLine.charAt(intIndex);

                if(chr==';') {
                  break;
                }

                ++intIndex;
              }

              Vector vecOperands=parseOperands(strNextLine.substring(0, intIndex));

              for(int i=0;i<vecOperands.size();i++)
                executeOperand((String)vecOperands.elementAt(i), classObj, intAbsoluteLineNumber, vecLocalFields);

//              executeCommand(classObj, intAbsoluteLineNumber, strNextLine.substring(0, intIndex), vecLocalFields);
            }

//            ++instructionIndex;
//            ++intAbsoluteLineNumber;
          }
          else {
            intIndex=intIndexEquals;

            int intIndexZ=intIndex-1;

            while(true) {
              if(intIndexZ<0)
                break;

              char chr=strNextLine.charAt(intIndexZ);

              if(chr==' ')
                break;

              --intIndexZ;
            }


            if(intIndexZ==-1) {
              intIndexZ=strNextLine.indexOf('[');

              if(intIndexZ!=-1 && intIndexZ<intIndexEquals) {
                int intBracketCount=1;

                intIndexZ+=1;
                int intIndexZZ=intIndexZ;

                while(true) {
                  char chr=strNextLine.charAt(intIndexZZ);

                  if(chr=='[') {
                    ++intBracketCount;
                  }
                  else if(chr==']') {
                    --intBracketCount;

                    if(intBracketCount==0)
                      break;
                  }

                  ++intIndexZZ;
                }

                String strOperands=strNextLine.substring(intIndexZ, intIndexZZ);

                Vector vecOperands=parseOperands(strOperands);

                for(int i=0;i<vecOperands.size();i++)
                  executeOperand((String)vecOperands.elementAt(i), classObj, intAbsoluteLineNumber, vecLocalFields);
              }
            }
            else {
              String strFieldName=strNextLine.substring(intIndexZ+1, intIndex);

              String strArray="";
              if(strFieldName.endsWith("[]")) {
                while(true) {
                  if(strFieldName.endsWith("[]")) {
                    strArray+="[]";
                    strFieldName=strFieldName.substring(0, strFieldName.length()-2);
                    continue;
                  }

                  break;
                }
              }

              if(strArray.length()==0) {
                if(strFieldName.startsWith("[]")) {
                  while(true) {
                    if(strFieldName.startsWith("[]")) {
                      strArray+="[]";
                      strFieldName=strFieldName.substring(2);
                      continue;
                    }

                    break;
                  }
                }
              }

              String strFieldClass=strNextLine.substring(0, intIndexZ);
              strFieldClass=strFieldClass.replace(".", "$");

              strFieldClass=(String)hashImported.get(strFieldClass);

              if(strFieldClass==null) {
                strFieldClass=strNextLine.substring(0, intIndexZ);
                strFieldClass=strFieldClass.replace(".", "$");

                int intDollarIndex0=strFieldClass.indexOf("$");

                if(intDollarIndex0!=-1) {
                  String strFieldClass0=strFieldClass.substring(0, intDollarIndex0);

                  strFieldClass0=(String)hashImported.get(strFieldClass0);

                  strFieldClass=strFieldClass0+"$"+strFieldClass.substring(intDollarIndex0+1);
                }
                else {
                  String strFieldClass0=classObj.getClassName();

                  int intDollarIndex=strFieldClass0.indexOf("$");

                  if(intDollarIndex==-1) {
                    strFieldClass=strFieldClass0+"$"+strFieldClass;
                  }
                  else {
                    strFieldClass=strFieldClass0.substring(0, intDollarIndex+1)+strFieldClass;
                  }
                }
              }

              if(strArray.length()>0)
                strFieldClass+=strArray;

//System.out.println("added field:"+strFieldClass+" "+strFieldName);
              vecCurrentBraceFields.addElement(new FieldObject(strFieldName, strFieldClass));
            }

            if(strNextLine.substring(intIndexEquals+1).startsWith("{")) {
              int intIndexA=intIndexEquals+2;
              int intIndexA2=intIndexEquals+2;

              int intBraceCount=1;

              while(true) {
                char chr=strNextLine.charAt(intIndexA2);

                if(chr=='{') {
                  ++intBraceCount;
                }
                else if(chr=='}') {
                  --intBraceCount;

                  if(intBraceCount==0)
                    break;
                }

                ++intIndexA2;
              }


              String strInitializer=strNextLine.substring(intIndexA, intIndexA2);
              parseArrayInitializer(strInitializer, classObj, intAbsoluteLineNumber, vecLocalFields);

              ++instructionIndex;
              ++intAbsoluteLineNumber;
            }
            else if(strNextLine.substring(intIndexEquals+1).startsWith("new ")) {
              strInstructions[instructionIndex]=strInstructions[instructionIndex].substring(intIndexEquals+1);
              continue;

/*
              strNextLine=strInstructions[instructionIndex];

              int intIndexZ0=strNextLine.lastIndexOf(')');

              int intIndexZ1=strNextLine.lastIndexOf(']');

              if(intIndexZ1>intIndexZ0) {
                int intBracketCount=1;

                int intIndex0=intIndexZ1-1;

                while(true) {
                  char chr=strNextLine.charAt(intIndex0);
 
                  if(chr=='[') {
                    --intBracketCount;

                    if(intBracketCount==0)
                      break;
                  }
                  else if(chr==']') {
                    ++intBracketCount;
                  }

                  --intIndex0;
                }

                ++intIndex0;

                String strOperands=strNextLine.substring(intIndex0, intIndexZ1);

                Vector vecOperands=parseOperands(strOperands);
                for(int i=0;i<vecOperands.size();i++) {
                  String strNextOperand=(String)vecOperands.elementAt(i);
                  executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
                }

//                instructionIndex++;
//                intAbsoluteLineNumber++;
              }
              else {
                parseNew(classObj, vecLocalFields, strNextLine, intAbsoluteLineNumber, classObj.getClassName());

//                int intParseNewAdd=parseNew(classObj, vecLocalFields, strNextLine, intAbsoluteLineNumber);

//                strNextLine=strNextLine.substring(intParseNewAdd);



//                int intIndexZZ=0;

//                while(true) {
//                  char chr=strNextLine.charAt(intIndexZZ);

//                  if(chr==';') {
//                    break;
//                  }

//                  ++intIndexZZ;
//                }

//                String strOperands=strNextLine.substring(0, intIndexZZ);

//                Vector vecOperands=parseOperands(strOperands);
//                for(int i=0;i<vecOperands.size();i++) {
//                  String strNextOperand=(String)vecOperands.elementAt(i);
//                  executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
//                }

//System.out.println("before new: "+strNextLine.substring(0, intIndex));
//                executeCommand(classObj, intAbsoluteLineNumber, strNextLine.substring(0, intIndexZZ), vecLocalFields);


//                instructionIndex++;
//                intAbsoluteLineNumber++;

                int intCurlyBraceIndex=strNextLine.indexOf('{');
                if(intCurlyBraceIndex!=-1) {
                  throw new Exception("Encountered \"{\" in a single instruction block for file: "+strFilePath+":"+intAbsoluteLineNumber);
                }
              }

*/

            }
            else {
              intIndex=intIndexEquals;

              ++intIndex;

              char chr='a';

              while(true) {
                chr=strNextLine.charAt(intIndex);

                if(chr!=' ')
                  break;

                ++intIndex;
              }

//System.out.println("before parseOperands:"+strNextLine);
              Vector vecOperands=parseOperands(strNextLine.substring(intIndex));

              for(int i=0;i<vecOperands.size();i++)
                executeOperand((String)vecOperands.elementAt(i), classObj, intAbsoluteLineNumber, vecLocalFields);

//              ++instructionIndex;
//              ++intAbsoluteLineNumber;
            }
          }
        }

//        ++instructionIndex;
//        ++intAbsoluteLineNumber;
      }

      break;
    }
  }

  public static String executeCommand(ClassObject classObj, int intAbsoluteLineNumber, String strCommand, Vector vecLocalFields) throws Exception {
    if(strCommand.startsWith("!"))
      strCommand=strCommand.substring(1);
    else if(strCommand.startsWith("-"))
      strCommand=strCommand.substring(1);

if(blnDoShowOutput) {
System.out.println("executeCommand:"+strCommand);
System.out.println("executeCommand:"+classObj.getClassName());
}

//System.out.println("strFilePath:"+strFilePath);
    if(strCommand.equals("null"))
      return "null";

    if(strCommand.equals("this"))
      return classObj.getClassName();

    String strRetReturnClass="";

    int intIndex0=-1;
    int intIndex1=-1;
    while(true) {
      intIndex1=strCommand.indexOf(" ", intIndex0);

      if(intIndex1==-1)
        break;

      if(intIndex1>=3) {
        if(!strCommand.substring(intIndex1-3, intIndex1).equals("new"))
          strCommand=strCommand.substring(0, intIndex1)+strCommand.substring(intIndex1+1);
        else
          intIndex0=intIndex1+1;
      }
      else
        strCommand=strCommand.substring(0, intIndex1)+strCommand.substring(intIndex1+1);
    }

    if(strCommand.length()==0)
      return "";

    try {
      Integer.valueOf(strCommand);

      return "int";
    }
    catch(Exception ex) {
    }

    if(strCommand.charAt(strCommand.length()-1)=='l') {
      try {
        Long.valueOf(strCommand.substring(0, strCommand.length()-1));

        return "long";
      }
      catch(Exception ex) {
      }
    }

    try {
      Double.valueOf(strCommand);

      return "double";
    }
    catch(Exception ex) {
    }

    if(strCommand.charAt(strCommand.length()-1)=='f') {
      try {
        Float.valueOf(strCommand.substring(0, strCommand.length()-1));

        return "float";
      }
      catch(Exception ex) {
      }
    }

    if(strCommand.charAt(strCommand.length()-1)=='d') {
      try {
        Double.valueOf(strCommand.substring(0, strCommand.length()-1));

        return "double";
      }
      catch(Exception ex) {
      }
    }

    if(strCommand.equals("true"))
      return "boolean";
    else if(strCommand.equals("false"))
      return "boolean";

    if(strCommand.startsWith("'"))
      return "char";

    if(strCommand.startsWith("\""))
      return "java.lang.String";

    while(true) {
      int intEqualsIndex=strCommand.indexOf('=');
      if(intEqualsIndex==-1)
        break;

      int intIndex=intEqualsIndex-1;

      while(true) {
        if(intIndex==-1)
          break;

        char chr=strCommand.charAt(intIndex);

        if(chr=='(') {
          break;
        }

        --intIndex;
      }

      ++intIndex;

      strCommand=strCommand.substring(0, intIndex)+trimString(strCommand.substring(intEqualsIndex+1));
    }


    while(true) {
      if(strCommand.length()==0)
        return "";

      if(strCommand.startsWith("(")) {
        int intParenthesisCount=1;

        int intIndex5=1;

        while(true) {
          char chr=strCommand.charAt(intIndex5);

          if(chr=='(') {
            ++intParenthesisCount;
          }
          else if(chr==')') {
            --intParenthesisCount;

            if(intParenthesisCount==0)
              break;
          }

          ++intIndex5;
        }

        ++intIndex5;

        if(intIndex5==strCommand.length()) {
          strCommand=strCommand.substring(1, strCommand.length()-1);
          continue;
        }
        else
          break;
      }
      else
        break;
    }


    if(!strCommand.startsWith("((")) {
      String strOverrideReturnClass="";
      if(strCommand.startsWith("(")) {
        int intIndex=1;

        while(true) {
          char chr=strCommand.charAt(intIndex);

          if(chr==')')
            break;

          ++intIndex;
        }

        strOverrideReturnClass=strCommand.substring(1, intIndex);
        strOverrideReturnClass=strOverrideReturnClass.replace(".", "$");
        String strArrays="";
        int intArrayIndex=strOverrideReturnClass.indexOf("[]");
        if(intArrayIndex!=-1) {
          strArrays=strOverrideReturnClass.substring(intArrayIndex);
          strOverrideReturnClass=strOverrideReturnClass.substring(0, intArrayIndex);
        }
        strOverrideReturnClass=(String)hashImported.get(strOverrideReturnClass);
        strOverrideReturnClass+=strArrays;

/*
        strOverrideReturnClass=strCommand.substring(1, intIndex);
        strOverrideReturnClass=strOverrideReturnClass.replace(".", "$");
//System.out.println("strOverrideReturnClass: \""+strOverrideReturnClass+"\"");
//System.out.println(hashImported.get(strOverrideReturnClass));
        strOverrideReturnClass=(String)hashImported.get(strOverrideReturnClass);
*/

        ++intIndex;

        strCommand=strCommand.substring(intIndex);

        if(strCommand.startsWith("((")) {
          executeCommand(classObj, intAbsoluteLineNumber, strCommand, vecLocalFields);

          return strOverrideReturnClass;
        }
        else if(strCommand.startsWith("(")) {
          Vector vecOperands=parseOperands(strCommand);
          for(int i=0;i<vecOperands.size();i++) {
            String strNextOperand=(String)vecOperands.elementAt(i);
            executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
          }

          return strOverrideReturnClass;
        }
      }

      int intIndex=0;

      boolean blnIsField=false;
      boolean blnIsFunction=false;

      int intBracketCountZ=0;

      while(true) {
        if(intIndex>=strCommand.length())
          break;

        char chr=strCommand.charAt(intIndex);

        if(chr=='.') {
          if(intBracketCountZ==0) {
            blnIsField=true;
            break;
          }
        }
        else if(chr=='[') {
          ++intBracketCountZ;
        }
        else if(chr==']') {
          --intBracketCountZ;
        }
        else if(chr=='(') {
          if(intBracketCountZ==0) {
            blnIsFunction=true;
            break;
          }
        }
//        else if(chr==';') {
//          return;
//        }

        ++intIndex;
      }

      if(intIndex>=strCommand.length()) {
        if(strCommand.equals("this"))
          return classObj.getClassName();

        String strOperand=strCommand.toString();
        strCommand=FieldObject.getFieldName(strCommand);

        for(int i=vecLocalFields.size()-1;i>=0;i--) {
          Vector vecCurrentBrace=(Vector)vecLocalFields.elementAt(i);
          for(int ia=0;ia<vecCurrentBrace.size();ia++) {
            FieldObject nextField=(FieldObject)vecCurrentBrace.elementAt(ia);
            if(nextField.getFieldName().equals(strCommand)) {
              if(strOverrideReturnClass.length()>0)
                return strOverrideReturnClass;
              else
                return FieldObject.getClassName(strOperand, nextField);
            }
          }
        }

        BooleanContainer blnContainer=new BooleanContainer();

//System.out.println("classObj: "+classObj.getClassName());
//System.out.println("strOperand: \""+strOperand+"\"");
//System.out.println("strCommand: \""+strCommand+"\"");
        String strClassNameZ=getFieldObjectByName(classObj, strOperand, strCommand);
//System.out.println("strClassNameZ: "+strClassNameZ);

        if(strOverrideReturnClass.length()>0)
          return strOverrideReturnClass;
        else
          return strClassNameZ;

/*
        Hashtable hashInstanceFields=classObj.getInstanceFields();
        FieldObject fObj=(FieldObject)hashInstanceFields.get(strCommand);
        if(fObj!=null) {
          if(strOverrideReturnClass.length()>0)
            return strOverrideReturnClass;
          else
            return FieldObject.getClassName(strOperand, fObj);
        }
        else {
          Hashtable hashStaticFields=classObj.getStaticFields();
          fObj=(FieldObject)hashStaticFields.get(strCommand);
          if(fObj!=null) {
            if(strOverrideReturnClass.length()>0)
              return strOverrideReturnClass;
            else
              return FieldObject.getClassName(strOperand, fObj);
          }
          else {
            throw new Exception("Unidentified field \""+strCommand+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
          }
        }
*/

      }

      String strClassRootClass="";
      String strCommandTrail="";

      boolean blnIsStatic=false;

      if(blnIsField) {

        String strClassRootName=strCommand.substring(0, intIndex);
//System.out.println("strClassRootName: "+strClassRootName);

        String strClassCheck=(String)hashImported.get(strClassRootName);
        if(strClassCheck!=null) {
          String strClassCheck0=strCommand.substring(intIndex+1);
          if(strClassCheck0.equals("class")) {
            if(strOverrideReturnClass.length()>0)
              return strOverrideReturnClass;
            else
              return "java.lang.Class";
          }
        }

        String strOperand=strClassRootName.toString();
        strClassRootName=FieldObject.getFieldName(strClassRootName);

        Hashtable hashEnums=classObj.getEnums();
        EnumObject enumObj=(EnumObject)hashEnums.get(strClassRootName);
        if(enumObj!=null) {
/*
if(strClassRootName.equals("Day")) {
try {
throw new Exception("");
}
catch(Exception ex) {
ex.printStackTrace();
}
}
*/

          if(strOverrideReturnClass.length()>0)
            return strOverrideReturnClass;
          else
            return strClassRootName;
        }


        if(strClassRootName.equals("this")) {
          strCommandTrail=strCommand.substring(intIndex+1);

          int intLeastIndex=isPeriodParenthesisEndLeast(strCommandTrail);

          if(intLeastIndex==strCommandTrail.length()) {
//            if(strCommandTrail.equals("class"))
//              return "java.lang.Class";

            Hashtable hashInstanceFields=classObj.getInstanceFields();

            strClassRootName=strCommandTrail;
            String strOperand2=strClassRootName.toString();
            strClassRootName=FieldObject.getFieldName(strClassRootName);

            FieldObject nextField=(FieldObject)hashInstanceFields.get(strClassRootName);
            if(nextField==null)
              throw new Exception("Unidentified field \""+strCommandTrail+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

            strClassRootClass=FieldObject.getClassName(strOperand2, nextField);

//            if(strClassRootClass.indexOf('[')!=-1)
//              return "int";

            if(strOverrideReturnClass.length()>0)
              return strOverrideReturnClass;
            else
              return strClassRootClass;
//            return fObj.getClassName();
          }
          else {
//            blnFoundField=true;

            if(strCommandTrail.charAt(intLeastIndex)=='.') {
              blnIsField=true;
              blnIsFunction=false;
            }
            else if(strCommandTrail.charAt(intLeastIndex)=='(') {
              blnIsField=false;
              blnIsFunction=true;
            }
          }

          strRetReturnClass=doExecuteCommand(classObj, strCommandTrail, blnIsField, blnIsFunction, blnIsStatic, classObj, intAbsoluteLineNumber, vecLocalFields);

          if(strOverrideReturnClass.length()>0)
            return strOverrideReturnClass;
          else
            return strRetReturnClass;
/*
          ClassObject classObjRoot=(ClassObject)hashClasses.get(strClassRootClass);
          if(classObjRoot!=null)
            strRetReturnClass=doExecuteCommand(classObjRoot, strCommandTrail, blnIsField, blnIsFunction, blnIsStatic, classObj, intAbsoluteLineNumber, vecLocalFields);
          else
            return getClassNameFromCommandTrail(strClassRootClass, strCommandTrail, classObj, vecLocalFields, intAbsoluteLineNumber);
*/
        }
        else if(strClassRootName.equals("super")) {
          strCommandTrail=strCommand.substring(intIndex+1);

          String strSuperclass=classObj.getSuperclass();

          ClassObject classObjRoot=(ClassObject)hashClasses.get(strSuperclass);
          if(classObjRoot==null) {
            String strNameFromCommandTrail=getClassNameFromCommandTrail(strSuperclass, strCommandTrail, classObj, vecLocalFields, intAbsoluteLineNumber);

            if(strOverrideReturnClass.length()>0)
              return strOverrideReturnClass;
            else
              return strNameFromCommandTrail;
          }

          int intLeastIndex=isPeriodParenthesisEndLeast(strCommandTrail);

          if(intLeastIndex==strCommandTrail.length()) {
//            if(strCommandTrail.equals("class"))
//              return "java.lang.Class";

            Hashtable hashInstanceFields=classObjRoot.getInstanceFields();

            strClassRootName=strCommandTrail;
            String strOperand2=strClassRootName.toString();
            strClassRootName=FieldObject.getFieldName(strClassRootName);

            FieldObject nextField=(FieldObject)hashInstanceFields.get(strClassRootName);
            if(nextField==null)
              throw new Exception("Unidentified field \""+strCommandTrail+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

            strClassRootClass=FieldObject.getClassName(strOperand2, nextField);

//            if(strClassRootClass.indexOf('[')!=-1)
//              return "int";

            if(strOverrideReturnClass.length()>0)
              return strOverrideReturnClass;
            else
              return strClassRootClass;
//            return fObj.getClassName();
          }
          else {
//            blnFoundField=true;

            if(strCommandTrail.charAt(intLeastIndex)=='.') {
              blnIsField=true;
              blnIsFunction=false;
            }
            else if(strCommandTrail.charAt(intLeastIndex)=='(') {
              blnIsField=false;
              blnIsFunction=true;
            }
          }

          strRetReturnClass=doExecuteCommand(classObjRoot, strCommandTrail, blnIsField, blnIsFunction, blnIsStatic, classObj, intAbsoluteLineNumber, vecLocalFields);

          if(strOverrideReturnClass.length()>0)
            return strOverrideReturnClass;
          else
            return strRetReturnClass;

/*
          ClassObject classObjRoot=(ClassObject)hashClasses.get(strClassRootClass);
          if(classObjRoot!=null)
            strRetReturnClass=doExecuteCommand(classObjRoot, strCommandTrail, blnIsField, blnIsFunction, blnIsStatic, classObj, intAbsoluteLineNumber, vecLocalFields);
          else
            return getClassNameFromCommandTrail(strClassRootClass, strCommandTrail, classObj, vecLocalFields, intAbsoluteLineNumber);
*/
        }

        boolean blnFoundField=false;

        if(!blnIsStatic) {
          for(int i=vecLocalFields.size()-1;i>=0;i--) {
            Vector vecCurrentBrace=(Vector)vecLocalFields.elementAt(i);
            for(int ia=0;ia<vecCurrentBrace.size();ia++) {
              FieldObject nextField=(FieldObject)vecCurrentBrace.elementAt(ia);
              if(nextField.getFieldName().equals(strClassRootName)) {
//System.out.println("nextFieldClass:"+nextField.getClassName());
//System.out.println(strOperand);
//System.out.println(nextField.getClassName());
                strClassRootClass=FieldObject.getClassName(strOperand, nextField);

                if(strClassRootClass.indexOf('[')!=-1) {
                  if(strOverrideReturnClass.length()>0)
                    return strOverrideReturnClass;
                  else
                    return "int";
                }

                strCommandTrail=strCommand.substring(intIndex+1);

                ClassObject classObj2=(ClassObject)hashClasses.get(strClassRootClass);
                if(classObj2==null) {
                  String strNameFromCommandTrail=getClassNameFromCommandTrail(strClassRootClass, strCommandTrail, classObj, vecLocalFields, intAbsoluteLineNumber);

                  if(strOverrideReturnClass.length()>0)
                    return strOverrideReturnClass;
                  else
                    return strNameFromCommandTrail;
                }

                int intLeastIndex=isPeriodParenthesisEndLeast(strCommandTrail);

                if(intLeastIndex==strCommandTrail.length()) {
                  if(strCommandTrail.equals("class")) {
                    if(strOverrideReturnClass.length()>0)
                      return strOverrideReturnClass;
                    else
                      return "java.lang.Class";
                  }

//                  Hashtable hashInstanceFields=classObj2.getInstanceFields();

                  strClassRootName=strCommandTrail;
                  String strOperand2=strClassRootName.toString();
                  strClassRootName=FieldObject.getFieldName(strClassRootName);

                  strClassRootClass=getFieldObjectByName(classObj2, strOperand2, strClassRootName);

/*
                  nextField=(FieldObject)hashInstanceFields.get(strClassRootName);
                  if(nextField==null)
                    throw new Exception("Unidentified field \""+strCommandTrail+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

                  strClassRootClass=FieldObject.getClassName(strOperand2, nextField);
*/

//                  if(strClassRootClass.indexOf('[')!=-1)
//                    return "int";

                  if(strOverrideReturnClass.length()>0)
                    return strOverrideReturnClass;
                  else
                    return strClassRootClass;
//                  return fObj.getClassName();
                }
                else {
                  blnFoundField=true;

                  if(strCommandTrail.charAt(intLeastIndex)=='.') {
                    blnIsField=true;
                    blnIsFunction=false;
                  }
                  else if(strCommandTrail.charAt(intLeastIndex)=='(') {
                    blnIsField=false;
                    blnIsFunction=true;
                  }
                }


                break;
              }
            }

            if(strClassRootClass.length()>0)
              break;
          }

          if(strClassRootClass.length()==0) {
            String strClassNameZ[]=getFieldObjectByName2(classObj, strOperand, strClassRootName); 

            if(strClassNameZ[0].equals("true") && strClassNameZ[1].length()>0) {
              if(strOverrideReturnClass.length()>0)
                return strOverrideReturnClass;
              else
                return strClassNameZ[1];
            }

            strClassRootClass=strClassNameZ[1];

            if(strClassRootClass.length()>0) {

              strCommandTrail=strCommand.substring(intIndex+1);

              ClassObject classObj2=(ClassObject)hashClasses.get(strClassRootClass);
              if(classObj2==null) {
                String strNameFromCommandTrail=getClassNameFromCommandTrail(strClassRootClass, strCommandTrail, classObj, vecLocalFields, intAbsoluteLineNumber);

                if(strOverrideReturnClass.length()>0)
                  return strOverrideReturnClass;
                else
                  return strNameFromCommandTrail;
              }

              int intLeastIndex=isPeriodParenthesisEndLeast(strCommandTrail);

              if(intLeastIndex==strCommandTrail.length()) {
                if(strCommandTrail.equals("class")) {
                  if(strOverrideReturnClass.length()>0)
                    return strOverrideReturnClass;
                  else
                    return "java.lang.Class";
                }

                Hashtable hashInstanceFields=classObj2.getInstanceFields();

                strClassRootName=strCommandTrail;
                String strOperand2=strClassRootName.toString();
                strClassRootName=FieldObject.getFieldName(strClassRootName);

                strClassRootClass=getFieldObjectByName(classObj2, strOperand2, strClassRootName); 

/*
                FieldObject fObj=(FieldObject)hashInstanceFields.get(strClassRootName);
                if(fObj==null)
                  throw new Exception("Unidentified field \""+strCommandTrail+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

                strClassRootClass=FieldObject.getClassName(strOperand2, fObj);
*/

//                if(strClassRootClass.indexOf('[')!=-1)
//                  return "int";

                if(strOverrideReturnClass.length()>0)
                  return strOverrideReturnClass;
                else
                  return strClassRootClass;
//                return fObj.getClassName();
              }
              else {
                blnFoundField=true;

                if(strCommandTrail.charAt(intLeastIndex)=='.') {
                  blnIsField=true;
                  blnIsFunction=false;
                }
                else if(strCommandTrail.charAt(intLeastIndex)=='(') {
                  blnIsField=false;
                  blnIsFunction=true;
                }
              }
            }

/*
            Hashtable hashInstanceFields=classObj.getInstanceFields();
            FieldObject fObj=(FieldObject)hashInstanceFields.get(strClassRootName);
            if(fObj!=null) {
              strClassRootClass=FieldObject.getClassName(strOperand, fObj);

              if(strClassRootClass.indexOf('[')!=-1) {
                if(strOverrideReturnClass.length()>0)
                  return strOverrideReturnClass;
                else
                  return "int";
              }

              strCommandTrail=strCommand.substring(intIndex+1);

              ClassObject classObj2=(ClassObject)hashClasses.get(strClassRootClass);
              if(classObj2==null) {
                String strNameFromCommandTrail=getClassNameFromCommandTrail(strClassRootClass, strCommandTrail, classObj, vecLocalFields, intAbsoluteLineNumber);

                if(strOverrideReturnClass.length()>0)
                  return strOverrideReturnClass;
                else
                  return strNameFromCommandTrail;
              }

              int intLeastIndex=isPeriodParenthesisEndLeast(strCommandTrail);

              if(intLeastIndex==strCommandTrail.length()) {
                if(strCommandTrail.equals("class")) {
                  if(strOverrideReturnClass.length()>0)
                    return strOverrideReturnClass;
                  else
                    return "java.lang.Class";
                }

                hashInstanceFields=classObj2.getInstanceFields();

                strClassRootName=strCommandTrail;
                String strOperand2=strClassRootName.toString();
                strClassRootName=FieldObject.getFieldName(strClassRootName);

                fObj=(FieldObject)hashInstanceFields.get(strClassRootName);
                if(fObj==null)
                  throw new Exception("Unidentified field \""+strCommandTrail+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

                strClassRootClass=FieldObject.getClassName(strOperand2, fObj);

//                if(strClassRootClass.indexOf('[')!=-1)
//                  return "int";

                if(strOverrideReturnClass.length()>0)
                  return strOverrideReturnClass;
                else
                  return strClassRootClass;
//                return fObj.getClassName();
              }
              else {
                blnFoundField=true;

                if(strCommandTrail.charAt(intLeastIndex)=='.') {
                  blnIsField=true;
                  blnIsFunction=false;
                }
                else if(strCommandTrail.charAt(intLeastIndex)=='(') {
                  blnIsField=false;
                  blnIsFunction=true;
                }
              }



            }
            else {
              Hashtable hashStaticFields=classObj.getStaticFields();
              fObj=(FieldObject)hashStaticFields.get(strClassRootName);
              if(fObj!=null) {
                blnIsStatic=true;

                strClassRootClass=FieldObject.getClassName(strOperand, fObj);

                if(strClassRootClass.indexOf('[')!=-1) {
                  if(strOverrideReturnClass.length()>0)
                    return strOverrideReturnClass;
                  else
                    return "int";
                }

                strCommandTrail=strCommand.substring(intIndex+1);

                ClassObject classObj2=(ClassObject)hashClasses.get(strClassRootClass);
                if(classObj2==null) {
                  String strNameFromCommandTrail=getClassNameFromCommandTrail(strClassRootClass, strCommandTrail, classObj, vecLocalFields, intAbsoluteLineNumber);

                  if(strOverrideReturnClass.length()>0)
                    return strOverrideReturnClass;
                  else
                    return strNameFromCommandTrail;
                }

                int intLeastIndex=isPeriodParenthesisEndLeast(strCommandTrail);

                if(intLeastIndex==strCommandTrail.length()) {
                  if(strCommandTrail.equals("class")) {
                    if(strOverrideReturnClass.length()>0)
                      return strOverrideReturnClass;
                    else
                      return "java.lang.Class";
                  }

                  hashInstanceFields=classObj2.getInstanceFields();

                  strClassRootName=strCommandTrail;
                  String strOperand2=strClassRootName.toString();
                  strClassRootName=FieldObject.getFieldName(strClassRootName);

                  fObj=(FieldObject)hashInstanceFields.get(strClassRootName);
                  if(fObj==null)
                    throw new Exception("Unidentified field \""+strCommandTrail+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

                  strClassRootClass=FieldObject.getClassName(strOperand2, fObj);

//                  if(strClassRootClass.indexOf('[')!=-1)
//                    return "int";

                  if(strOverrideReturnClass.length()>0)
                    return strOverrideReturnClass;
                  else
                    return strClassRootClass;
//                  return fObj.getClassName();
                }
                else {
                  blnFoundField=true;

                  if(strCommandTrail.charAt(intLeastIndex)=='.') {
                    blnIsField=true;
                    blnIsFunction=false;
                  }
                  else if(strCommandTrail.charAt(intLeastIndex)=='(') {
                    blnIsField=false;
                    blnIsFunction=true;
                  }
                }





//                blnFoundField=true;

//                strClassRootClass=classObj.getClassName();
//                strCommandTrail=strCommand;

//                blnIsField=true;
//                blnIsFunction=false;

//                blnIsStatic=true;


              }
//              else
//                throw new Exception("Unidentified field \""+strClassRootName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
            }
*/

          }
        }


        if(!blnFoundField) {
          hashEnums=classObj.getEnums();
          if(hashEnums.containsKey(strClassRootName)) {
            throw new Exception("Attempted class cast to enum \""+strClassRootName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
          }

          String strClassRootName0=strClassRootName;
          strClassRootName0=(String)hashImported.get(strClassRootName0);

          if(strClassRootName0==null) {
            throw new Exception("Unidentified field \""+strClassRootName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
          }
          else {
            blnIsStatic=true;
            strClassRootClass=strClassRootName0;

            strCommandTrail=strCommand.substring(intIndex+1);

//System.out.println("getClassNameFromCommandTrail");
//System.out.println(strClassRootClass);
//System.out.println(strCommandTrail);
            ClassObject classObj2=(ClassObject)hashClasses.get(strClassRootClass);
            if(classObj2==null) {
              String strNameFromCommandTrail=getClassNameFromCommandTrail(strClassRootClass, strCommandTrail, classObj, vecLocalFields, intAbsoluteLineNumber);

              if(strOverrideReturnClass.length()>0)
                return strOverrideReturnClass;
              else
                return strNameFromCommandTrail;
            }

            int intLeastIndex=isPeriodParenthesisEndLeast(strCommandTrail);

            if(intLeastIndex==strCommandTrail.length()) {
              if(strCommandTrail.equals("class")) {
                if(strOverrideReturnClass.length()>0)
                  return strOverrideReturnClass;
                else
                  return "java.lang.Class";
              }

              Hashtable hashStaticFields=classObj2.getStaticFields();

              String strOperand2=strCommandTrail.toString();
              strCommandTrail=FieldObject.getFieldName(strCommandTrail);

              FieldObject fObj=(FieldObject)hashStaticFields.get(strCommandTrail);
              if(fObj==null)
                throw new Exception("Unidentified field \""+strCommandTrail+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

              String strClass=FieldObject.getClassName(strOperand2, fObj);

              if(strOverrideReturnClass.length()>0)
                return strOverrideReturnClass;
              else
                return strClass;
            }
            else {
              if(strCommandTrail.charAt(intLeastIndex)=='.') {
                blnIsField=true;
                blnIsFunction=false;
              }
              else if(strCommandTrail.charAt(intLeastIndex)=='(') {
                blnIsField=false;
                blnIsFunction=true;
              }
            }
          }
        }


      }
      else if(blnIsFunction) {

        if(strCommand.startsWith("new ")) {
          StringContainer strContainer=new StringContainer();
          StringContainer strContainer2=new StringContainer();
//System.out.println("executeCommand: "+strCommand);
          parseNew(classObj, vecLocalFields, strCommand, intAbsoluteLineNumber, strContainer, classObj.getClassName(), strContainer2);

          if(strOverrideReturnClass.length()>0)
            return strOverrideReturnClass;
          else
            return strContainer2.getStr();

/*
          strClassRootClass=strCommand.substring(4, intIndex);

          strCommand=strCommand.substring(intIndex+1);

          intIndex=0;

          int intIndex2=0;

          while(true) {
            char chr=strCommand.charAt(intIndex2);


//            if(chr==',') {
//              String strCommand2=strCommand.substring(intIndex, intIndex2);

//              executeCommand(classObj, intAbsoluteLineNumber, strCommand2, vecLocalFields);

//              intIndex=intIndex2+2;
//              intIndex2+=3;

//              continue;
//            }
//            else if(chr=='(') {

            if(chr=='(') {
              int intParenthesisCount=1;

              ++intIndex2;

              while(true) {
                char chr2=strCommand.charAt(intIndex2);

                if(chr2=='(') {
                  ++intParenthesisCount;
                }
                else if(chr2==')') {
                  --intParenthesisCount;

                  if(intParenthesisCount==0)
                    break;
                }

                ++intIndex2;
              }
            }
            else if(chr==')') {
              break;
            }

            ++intIndex2;
          }

          ++intIndex2;

//System.out.println("classRootClass:"+strClassRootClass);
          String strClassRootClass0=strClassRootClass.toString();

          strClassRootClass=(String)hashImported.get(strClassRootClass);

//          if(strClassRootClass==null)
//            strClassRootClass=strDoExecuteCommandNewOuterClass+"$"+strClassRootClass0;

//System.out.println(strClassRootClass);

          ClassObject newClassObj=(ClassObject)hashClasses.get(strClassRootClass);

//if(newClassObj==null)
//System.out.println("is null");

          if(newClassObj!=null) {
//System.out.println("parameters:"+strCommand);
            Vector vecParameters=new Vector();
            int intParseParameterEnd=parseParameters(strCommand, vecParameters, classObj, vecLocalFields, intAbsoluteLineNumber);
//            strNextLine=strNextLine.substring(intIndexPositionAdd);
//            intIndexPosition+=intIndexPositionAdd;


            ConstructorSignature signature=new ConstructorSignature(newClassObj.getClassName(), vecParameters);

//            if(!vecExecutedConstructors.contains(signature)) {
//              vecExecutedConstructors.addElement(signature);

            if(!vecExecutingConstructors.contains(signature)) {
              vecExecutingConstructors.addElement(signature);

//printConstructorFunctionStack();

              ConstructorObject constructorObj=(ConstructorObject)newClassObj.getConstructors().get(signature);

              if(constructorObj==null)
                throw new Exception("Constructor not found for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

              Vector vecLocalFields0=new Vector();
              Vector vecCurrentBraceFields0=new Vector();
              vecLocalFields0.addElement(vecCurrentBraceFields0);

              Vector vecConstructorParameters=constructorObj.getConstructorParameters();
              for(int i=0;i<vecConstructorParameters.size();i++)
                vecCurrentBraceFields0.addElement(vecConstructorParameters.elementAt(i));

              if(hashConstructorCounts.containsKey(signature)) {
                long lngCount0=((Long)hashConstructorCounts.get(signature)).longValue();

                for(int i=0;i<vecCounts.size();i++) {
                  long lngCount=((Long)vecCounts.elementAt(i)).longValue();
                  lngCount+=lngCount0;
                  vecCounts.setElementAt(new Long(lngCount), i);
                }
              }
              else {
                String strInstructionsZ[]=constructorObj.getInstructions();
                for(int i=0;i<vecCounts.size();i++) {
                  long lngCount=((Long)vecCounts.elementAt(i)).longValue();
                  lngCount+=(long)strInstructionsZ.length;
                  vecCounts.setElementAt(new Long(lngCount), i);
                }

                vecCounts.addElement(new Long((long)strInstructionsZ.length));
              }

              executeInstructions(newClassObj, constructorObj.getInstructions(), constructorObj.getAbsoluteLineNumber(), 0, vecLocalFields0);

              if(!hashConstructorCounts.containsKey(signature)) {
                hashConstructorCounts.put(signature, vecCounts.elementAt(vecCounts.size()-1));

                vecCounts.removeElementAt(vecCounts.size()-1);
              }

              vecExecutingConstructors.removeElementAt(vecExecutingConstructors.size()-1);
            }
          }


          if(intIndex2==strCommand.length()) {
//System.out.println("executeCommandTrail:0:"+strCommandTrail);
            if(strOverrideReturnClass.length()>0)
              return strOverrideReturnClass;
            else
              return strClassRootClass;
          }
          else {
            strCommandTrail=strCommand.substring(intIndex2+1);
//System.out.println("executeCommandTrail:1:"+strCommandTrail);

            ClassObject classObj2=(ClassObject)hashClasses.get(strClassRootClass);
            if(classObj2==null) {
              String strNameFromCommandTrail=getClassNameFromCommandTrail(strClassRootClass, strCommandTrail, classObj, vecLocalFields, intAbsoluteLineNumber);

              if(strOverrideReturnClass.length()>0)
                return strOverrideReturnClass;
              else
                return strNameFromCommandTrail;
            }

            int intLeastIndex=isPeriodParenthesisEndLeast(strCommandTrail);

            if(intLeastIndex==strCommandTrail.length()) {
              Hashtable hashInstanceFields=classObj2.getInstanceFields();

              FieldObject fObj=(FieldObject)hashInstanceFields.get(strCommandTrail);
              if(fObj==null)
                throw new Exception("Unidentified field \""+strCommandTrail+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

              if(strOverrideReturnClass.length()>0)
                return strOverrideReturnClass;
              else
                return fObj.getClassName();
            }
            else {
              blnIsStatic=false;

              if(strCommandTrail.charAt(intLeastIndex)=='.') {
                blnIsField=true;
                blnIsFunction=false;
              }
              else if(strCommandTrail.charAt(intLeastIndex)=='(') {
                blnIsField=false;
                blnIsFunction=true;
              }
            }
            
          }
*/

        }
        else {
          String strFunctionName=strCommand.substring(0, intIndex);

          ++intIndex;

          String strParameters=strCommand.substring(intIndex);

          Vector vecParameters=new Vector();
          int intParseParametersEnd=parseParameters(strParameters, vecParameters, classObj, vecLocalFields, intAbsoluteLineNumber);


          BooleanContainer blnContainer=new BooleanContainer();

          String strClassNameZ[]=getFunctionObjectBySignature(classObj, classObj, strFunctionName, strCommand, vecParameters, blnContainer, vecLocalFields, intAbsoluteLineNumber);

          if(strClassNameZ[0].equals("true"))
            return strClassNameZ[1];

          blnIsStatic=blnContainer.getBln();


          blnIsField=false;
          blnIsFunction=true;

          strClassRootClass=strClassNameZ[1];
//System.out.println("strClassRootClass: "+strClassRootClass);
//          strClassRootClass=classObj.getClassName();
          strCommandTrail=strCommand;

/*
          Hashtable hashInstanceFunctions=classObj.getInstanceFunctions();
          FunctionObject fObj=(FunctionObject)hashInstanceFunctions.get(new FunctionSignature(classObj.getClassName(), strFunctionName, vecParameters));
          if(fObj!=null) {
            strClassRootClass=classObj.getClassName();
            strCommandTrail=strCommand;
          }
          else {
            Hashtable hashStaticFunctions=classObj.getStaticFunctions();
            fObj=(FunctionObject)hashStaticFunctions.get(new FunctionSignature(classObj.getClassName(), strFunctionName, vecParameters));
            if(fObj!=null) {
              strClassRootClass=classObj.getClassName();
              strCommandTrail=strCommand;
              blnIsStatic=true;
            }
            else {
//System.out.println("strCommand:"+strCommand);
              String strNameFromCommandTrail=getClassNameFromCommandTrail(classObj.getSuperclass(), strCommand, classObj, vecLocalFields, intAbsoluteLineNumber);

              if(strOverrideReturnClass.length()>0)
                return strOverrideReturnClass;
              else
                return strNameFromCommandTrail;

//              throw new Exception("Unidentified function \""+strFunctionName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
            }
          }
*/

        }
      }


      ClassObject classObjRoot=(ClassObject)hashClasses.get(strClassRootClass);
      if(classObjRoot!=null) {
        strRetReturnClass=doExecuteCommand(classObjRoot, strCommandTrail, blnIsField, blnIsFunction, blnIsStatic, classObj, intAbsoluteLineNumber, vecLocalFields);

        if(strOverrideReturnClass.length()>0)
          strRetReturnClass=strOverrideReturnClass;
      }
      else {
        String strNameFromCommandTrail=getClassNameFromCommandTrail(strClassRootClass, strCommandTrail, classObj, vecLocalFields, intAbsoluteLineNumber);

        if(strOverrideReturnClass.length()>0)
          return strOverrideReturnClass;
        else
          return strNameFromCommandTrail;
      }
    }
    else {
      if(!strCommand.startsWith("("))
        return executeCommand(classObj, intAbsoluteLineNumber, strCommand, vecLocalFields);

      int intIndex=2;

      while(true) {
        char chr=strCommand.charAt(intIndex);

        if(chr==')')
          break;

        ++intIndex;
      }

      String strCheckClassCast=strCommand.substring(2, intIndex);

      Hashtable hashEnums=classObj.getEnums();
      if(hashEnums.containsKey(strCheckClassCast)) {
        throw new Exception("Attempted class cast to enum \""+strCheckClassCast+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
      }

//      if(hashImported.containsKey(strCheckClassCast))
//        strCommand=strCommand.substring(intIndex+1);

//      if(!strCommand.startsWith("("))
//        return executeCommand(classObj, intAbsoluteLineNumber, strCommand, vecLocalFields);


      intIndex0=-1;
      intIndex1=-1;
      int intIndex2=-1;
      while(true) {
        intIndex1=strCommand.indexOf("(((", intIndex0);

        if(intIndex1==-1)
          break;

        intIndex2=intIndex1+3;

        int intParenthesisCount=3;

        while(true) {
          char chr=strCommand.charAt(intIndex2);

          if(chr=='(') {
            ++intParenthesisCount;
          }
          else if(chr==')') {
            --intParenthesisCount;

            if(intParenthesisCount==0)
              break;
          }

          ++intIndex2;
        }

        strCommand=strCommand.substring(0, intIndex2)+strCommand.substring(intIndex2+1);
        strCommand=strCommand.substring(0, intIndex1)+strCommand.substring(intIndex1+1);

        intIndex0=intIndex1;
      }

      Vector vecExecuteLevelsIndices=new Vector();
      Vector vecExecuteLevelsClassCasts=new Vector();

/*
((SomeClass)classObj.function()).otherFunction()
((SomeClass)((SomeClass2)classObj.function()).otherOtherFunction()).otherFunction()
*/

//System.out.println("string executeCommand:0:"+strCommand);

      intIndex=0;
      int intIndexZ=-1;
      while(true) {
        char chr=strCommand.charAt(intIndex);

        if(chr=='(') {
          intIndexZ=intIndex;

          int intIndexZ2=strCommand.indexOf('(', intIndexZ+1);

          if(intIndexZ2==-1)
            intIndexZ2=Integer.MAX_VALUE;

          if(intIndexZ!=(intIndexZ2-1)) {
            throw new Exception("Didn't find \"(\" where one was expected for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
          }
          else {
            int intIndexZ4=intIndexZ2+2;

            while(true) {
              char chr2=strCommand.charAt(intIndexZ4);

              if(chr2==')')
                break;

              ++intIndexZ4;
            }

            strCheckClassCast=strCommand.substring(intIndexZ2+1, intIndexZ4);

            hashEnums=classObj.getEnums();
            if(hashEnums.containsKey(strCheckClassCast)) {
              throw new Exception("Attempted class cast to enum \""+strCheckClassCast+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
            }

            if(!hashImported.containsKey(strCheckClassCast)) {
              throw new Exception("Attempted class cast as non-existant \""+strCheckClassCast+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
            }
            vecExecuteLevelsClassCasts.addElement(strCheckClassCast);

            intIndexZ4+=1;
            int intIndexZ6=intIndexZ4;

            int intParenthesisCount=1;

            while(true) {
              char chr2=strCommand.charAt(intIndexZ4);

              if(chr2=='(') {
                ++intParenthesisCount;
              }
              else if(chr2==')') {
                --intParenthesisCount;

                if(intParenthesisCount==0)
                  break;
              }

              ++intIndexZ4;
            }

            ++intIndexZ4;

            int intIndices[]=new int[2];
//System.out.println("string executeComand:0:"+strCommand);
            if(strCommand.charAt(intIndexZ4)=='.') {
//System.out.println("string executeComand:1");
              int intIndexZ5=intIndexZ4+1;

              while(true) {
                if(intIndexZ5>=strCommand.length())
                  break;

                char chr2=strCommand.charAt(intIndexZ5);

                if(chr2==')') {
                  ++intIndexZ5;

                  break;
                }
                else if(chr2=='(') {
                  int intParenthesisCount2=1;

                  ++intIndexZ5;

                  while(true) {
                    char chr3=strCommand.charAt(intIndexZ5);

                    if(chr3=='(') {
                      ++intParenthesisCount2;
                    }
                    else if(chr3==')') {
                      --intParenthesisCount2;

                      if(intParenthesisCount2==0)
                        break;
                    }

                    ++intIndexZ5;
                  }

                  ++intIndexZ5;
                  continue;
                }

                ++intIndexZ5;
              }

              intIndices[0]=intIndexZ4+1;
              intIndices[1]=intIndexZ5;

//System.out.println("string executeCommand:2:"+intIndices[0]+", "+intIndices[1]);
            }
            else {
              intIndices[0]=intIndexZ4;
              intIndices[1]=intIndexZ4;
            }

            vecExecuteLevelsIndices.addElement(intIndices);

            intIndex=intIndexZ6;
          }

//end if(chr=='(') {
        }
        else {
//System.out.println("string executeCommand:3");

          intIndex2=intIndex+1;
          while(true) {
            char chr2=strCommand.charAt(intIndex2);

            if(chr2==')') {
              break;
            }
            else if(chr2=='(') {
              int intParenthesisCount=1;

              ++intIndex2;

              while(true) {
                char chr3=strCommand.charAt(intIndex2);

                if(chr3=='(') {
                  ++intParenthesisCount;
                }
                else if(chr3==')') {
                  --intParenthesisCount;

                  if(intParenthesisCount==0)
                    break;
                }

                ++intIndex2;
              }

              ++intIndex2;
              continue;
            }

            ++intIndex2;
          }

          String strCommand2=strCommand.substring(intIndex, intIndex2);

//System.out.println("strCommand2: "+strCommand2);
          String strReturnClass=executeCommand(classObj, intAbsoluteLineNumber, strCommand2, vecLocalFields);

          for(int i=vecExecuteLevelsIndices.size()-1;i>=0;i--) {
            int intIndices[]=(int[])vecExecuteLevelsIndices.elementAt(i);
            String strClassCast=(String)vecExecuteLevelsClassCasts.elementAt(i);

            if(intIndices[0]==intIndices[1])
              continue;

            String strCommandTrail=strCommand.substring(intIndices[0], intIndices[1]);

            strClassCast=(String)hashImported.get(strClassCast);

            ClassObject classObjRoot=(ClassObject)hashClasses.get(strClassCast);

            if(classObjRoot==null) {
              strReturnClass=getClassNameFromCommandTrail(strClassCast, strCommandTrail, classObj, vecLocalFields, intAbsoluteLineNumber);

              if(i==0)
                return strReturnClass;
            }
            else {
              boolean blnIsField=false;
              boolean blnIsFunction=false;

              int intLeastIndex=isPeriodParenthesisEndLeast(strCommandTrail);

              if(intLeastIndex==strCommandTrail.length()) {
                if(i==0) {
                  if(strCommandTrail.equals("class"))
                    return "java.lang.Class";

                  Hashtable hashInstanceFields=classObjRoot.getInstanceFields();

                  String strClassRootNameZ=strCommandTrail;
                  String strOperand2=strClassRootNameZ.toString();
                  strClassRootNameZ=FieldObject.getFieldName(strClassRootNameZ);

//                  strClassRootName=strCommandTrail;
//                  String strOperand2=strClassRootName.toString();
//                  strClassRootName=FieldObject.getFieldName(strClassRootName);

                  FieldObject fObj=(FieldObject)hashInstanceFields.get(strClassRootNameZ);
                  if(fObj==null)
                    throw new Exception("Unidentified field \""+strCommandTrail+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

                  String strClassRootClassZ=FieldObject.getClassName(strOperand2, fObj);
//                  strClassRootClass=FieldObject.getClassName(strOperand2, fObj);

//                  if(strClassRootClass.indexOf('[')!=-1)
//                    return "int";

                  return strClassRootClassZ;
//                  return fObj.getClassName();
                }

                continue;

/*
                Hashtable hashInstanceFields=classObjRoot.getInstanceFields();

                FieldObject fObj=(FieldObject)hashInstanceFields.get(strCommandTrail);
                if(fObj==null)
                  throw new Exception("Unidentified field \""+strCommandTrail+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

                return fObj.getClassName();
*/
              }
              else {
                if(strCommandTrail.charAt(intLeastIndex)=='.') {
                  blnIsField=true;
                  blnIsFunction=false;
                }
                else if(strCommandTrail.charAt(intLeastIndex)=='(') {
                  blnIsField=false;
                  blnIsFunction=true;
                }
              }
              
//System.out.println("strReturnClass: "+strCommandTrail);
              strReturnClass=doExecuteCommandNonStatic(classObjRoot, strCommandTrail, blnIsField, blnIsFunction, classObj, intAbsoluteLineNumber, vecLocalFields);
//System.out.println("strReturnClass: "+strReturnClass);

              if(i==0) {
//System.out.println("strReturnClass: "+strReturnClass);
                return strReturnClass;
              }
            }
          }

          strRetReturnClass=strReturnClass;
          
          break;
        }
      }

      
    }

    return strRetReturnClass;
  }

  public static String doExecuteCommand(ClassObject classObjRoot, String strCommandTrail, boolean blnIsField, boolean blnIsFunction, boolean blnIsStatic, ClassObject classObj, int intAbsoluteLineNumber, Vector vecLocalFields) throws Exception {
if(blnDoShowOutputExtended) {
System.out.println("doExecuteCommand");
System.out.println(classObjRoot.getClassName());
System.out.println(classObj.getClassName());
System.out.println(strCommandTrail);
System.out.println(blnIsField);
System.out.println(blnIsFunction);
System.out.println(blnIsStatic);
}

    String strRetReturnClass="";

    String strClassName="";

    if(blnIsField) {
      if(blnIsStatic) {
        int intIndex=0;

        int intBracketCountZ=0;

        while(true) {
          if(intIndex>=strCommandTrail.length())
            break;

          char chr=strCommandTrail.charAt(intIndex);

          if(chr=='.') {
            if(intBracketCountZ==0) {
              break;
            }
          }
          else if(chr=='[') {
            ++intBracketCountZ;
          }
          else if(chr==']') {
            --intBracketCountZ;
          }

          ++intIndex;
        }

        String strFieldName=strCommandTrail.substring(0, intIndex);

        if(strFieldName.equals("class"))
          strClassName="java.lang.Class";
        else {
//          Hashtable hashStaticFields=classObjRoot.getStaticFields();

          String strOperand=strFieldName.toString();
          strFieldName=FieldObject.getFieldName(strFieldName);

          String strClassNameZ[]=getFieldObjectByName2(classObjRoot, strOperand, strFieldName); 

          if(strClassNameZ[0].equals("true") && strClassNameZ[1].length()>0) {
            return strClassNameZ[1];
          }

          strClassName=strClassNameZ[1];

/*
          FieldObject fObj=(FieldObject)hashStaticFields.get(strFieldName);
          if(fObj==null) {
            String strClassNameSuper=classObjRoot.getSuperclass();

            ClassObject classObjSuper=(ClassObject)hashClasses.get(strClassNameSuper);

            if(classObjSuper==null) {
              String strClassNameReturn=getClassNameFromCommandTrail(strClassNameSuper, strCommandTrail, classObj, vecLocalFields, intAbsoluteLineNumber);

              return strClassNameReturn;
            }
            else {
              String strClassNameReturn=doExecuteCommand(classObjSuper, strCommandTrail, blnIsField, blnIsFunction, blnIsStatic, classObj, intAbsoluteLineNumber, vecLocalFields);

              return strClassNameReturn;
            }
          }


          strClassName=FieldObject.getClassName(strOperand, fObj);
*/

        }

        if(strCommandTrail.length()==intIndex)
          strCommandTrail="";
        else
          strCommandTrail=strCommandTrail.substring(intIndex+1);
      }
      else {
        int intIndex=0;

        int intBracketCountZ=0;

        while(true) {
          if(intIndex>=strCommandTrail.length())
            break;

          char chr=strCommandTrail.charAt(intIndex);

          if(chr=='.') {
            if(intBracketCountZ==0) {
              break;
            }
          }
          else if(chr=='[') {
            ++intBracketCountZ;
          }
          else if(chr==']') {
            --intBracketCountZ;
          }

          ++intIndex;
        }

        String strFieldName=strCommandTrail.substring(0, intIndex);

        if(strFieldName.equals("class"))
          strClassName="java.lang.Class";
        else {
//          Hashtable hashInstanceFields=classObjRoot.getInstanceFields();

          String strOperand=strFieldName.toString();
          strFieldName=FieldObject.getFieldName(strFieldName);

//System.out.println("strOperand: "+strOperand);
//System.out.println("strFieldName: "+strFieldName);
          String strClassNameZ[]=getFieldObjectByName2(classObjRoot, strOperand, strFieldName); 

          if(strClassNameZ[0].equals("true") && strClassNameZ[1].length()>0) {
            return strClassNameZ[1];
          }

          strClassName=strClassNameZ[1];
//System.out.println("strClassName: "+strClassName);

/*
          FieldObject fObj=(FieldObject)hashInstanceFields.get(strFieldName);
          if(fObj==null) {
            String strClassNameSuper=classObjRoot.getSuperclass();

            ClassObject classObjSuper=(ClassObject)hashClasses.get(strClassNameSuper);

            if(classObjSuper==null) {
              String strClassNameReturn=getClassNameFromCommandTrail(strClassNameSuper, strCommandTrail, classObj, vecLocalFields, intAbsoluteLineNumber);

              return strClassNameReturn;
            }
            else {
              String strClassNameReturn=doExecuteCommand(classObjSuper, strCommandTrail, blnIsField, blnIsFunction, blnIsStatic, classObj, intAbsoluteLineNumber, vecLocalFields);

              return strClassNameReturn;
            }
          }

          strClassName=FieldObject.getClassName(strOperand, fObj);
*/
        }

        if(strCommandTrail.length()==intIndex)
          strCommandTrail="";
        else
          strCommandTrail=strCommandTrail.substring(intIndex+1);
      }
    }
    else if(blnIsFunction) {
      if(blnIsStatic) {
//System.out.println("blnIsStatic: "+classObjRoot.getClassName());
//        Hashtable hashStaticFunctions=classObjRoot.getStaticFunctions();

        String strFunctionName=strCommandTrail.substring(0, strCommandTrail.indexOf('('));

        String strCommandTrail0=strCommandTrail.toString();
        strCommandTrail=strCommandTrail.substring(strCommandTrail.indexOf('(')+1);

        Vector vecParameters=new Vector();
        int intParseParametersEnd=parseParameters(strCommandTrail, vecParameters, classObj, vecLocalFields, intAbsoluteLineNumber);


        FunctionObjectContainer fObjContainer=new FunctionObjectContainer();

        ClassObjectContainer classContainer=new ClassObjectContainer();

        String strClassNameZ[]=getFunctionObjectBySignature2(classObjRoot, classObj, strFunctionName, strCommandTrail0, vecParameters, fObjContainer, vecLocalFields, intAbsoluteLineNumber, classContainer);

        if(strClassNameZ[0].equals("true")) {
          return strClassNameZ[1];
        }

        strClassName=strClassNameZ[1];

        classObjRoot=classContainer.getClassObject();

        FunctionObject fObj=fObjContainer.getFunctionObject();

        FunctionSignature signature=fObj.getSignature();


/*
        FunctionSignature signature=new FunctionSignature(classObjRoot.getClassName(), strFunctionName, vecParameters);

//System.out.println("blnIsStaticSignature: "+signature.toString());

//Hashtable hashInstanceFunctions=classObjRoot.getInstanceFunctions();
//System.out.println(hashInstanceFunctions.size());
//Iterator iter0=hashInstanceFunctions.entrySet().iterator();
//while(iter0.hasNext()) {
//Map.Entry mEntry=(Map.Entry)iter0.next();
//System.out.println(mEntry.getKey());
//}

//System.out.println(hashStaticFunctions.size());
//iter0=hashStaticFunctions.entrySet().iterator();
//while(iter0.hasNext()) {
//Map.Entry mEntry=(Map.Entry)iter0.next();
//System.out.println(mEntry.getKey());
//}

        FunctionObject fObj=(FunctionObject)hashStaticFunctions.get(signature);
        if(fObj==null) {
          String strClassNameSuper=classObjRoot.getSuperclass();

          ClassObject classObjSuper=(ClassObject)hashClasses.get(strClassNameSuper);

          if(classObjSuper==null) {
            String strClassNameReturn=getClassNameFromCommandTrail(strClassNameSuper, strCommandTrail0, classObj, vecLocalFields, intAbsoluteLineNumber);

            return strClassNameReturn;
          }
          else {
            String strClassNameReturn=doExecuteCommand(classObjSuper, strCommandTrail0, blnIsField, blnIsFunction, blnIsStatic, classObj, intAbsoluteLineNumber, vecLocalFields);

            return strClassNameReturn;
          }
        }
*/


//        if(!vecExecutedFunctions.contains(signature)) {
//          vecExecutedFunctions.addElement(signature);

        if(!vecExecutingFunctions.contains(signature)) {
          vecExecutingFunctions.addElement(signature);

//printConstructorFunctionStack();

          String strInstructions[]=fObj.getInstructions();

          int intAbsoluteLineNumber0=fObj.getAbsoluteLineNumber();

          Vector vecLocalFields0=new Vector();
          Vector vecCurrentBraceFields0=new Vector();
          vecLocalFields0.addElement(vecCurrentBraceFields0);

          Vector vecFunctionParameters=fObj.getFunctionParameters();
          for(int i=0;i<vecFunctionParameters.size();i++)
            vecCurrentBraceFields0.addElement(vecFunctionParameters.elementAt(i));

          if(hashFunctionCounts.containsKey(signature)) {
            long lngCount0=((Long)hashFunctionCounts.get(signature)).longValue();

            for(int i=0;i<vecCounts.size();i++) {
              long lngCount=((Long)vecCounts.elementAt(i)).longValue();
              lngCount+=lngCount0;
              vecCounts.setElementAt(new Long(lngCount), i);
            }
          }
          else {
            String strInstructionsZ[]=fObj.getInstructions();
            for(int i=0;i<vecCounts.size();i++) {
              long lngCount=((Long)vecCounts.elementAt(i)).longValue();
              lngCount+=(long)strInstructionsZ.length;
              vecCounts.setElementAt(new Long(lngCount), i);
            }

            vecCounts.addElement(new Long((long)strInstructionsZ.length));
          }

          executeInstructions(classObjRoot, strInstructions, intAbsoluteLineNumber0, 0, vecLocalFields0);

          if(!hashFunctionCounts.containsKey(signature)) {
            hashFunctionCounts.put(signature, vecCounts.elementAt(vecCounts.size()-1));

            vecCounts.removeElementAt(vecCounts.size()-1);
          }

          vecExecutingFunctions.removeElementAt(vecExecutingFunctions.size()-1);
        }

//        strClassName=fObj.getReturnClassName();

        strCommandTrail=strCommandTrail.substring(intParseParametersEnd);

        if(strCommandTrail.length()==0)
          return strClassName;

        if(!strCommandTrail.startsWith("."))
          throw new Exception("Encountered \""+strCommandTrail.charAt(0)+"\" when \".\" was expected for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

        strCommandTrail=strCommandTrail.substring(1);
      }
      else {
//System.out.println("doExecuteNew:0:"+strCommandTrail);
        if(strCommandTrail.startsWith("new ")) {
//System.out.println("doExecuteNew:1:"+strCommandTrail);

          StringContainer strContainer=new StringContainer();
          StringContainer strContainer2=new StringContainer();
          parseNew(classObj, vecLocalFields, strCommandTrail, intAbsoluteLineNumber, strContainer, classObjRoot.getClassName(), strContainer2);

          return strContainer2.getStr();

/*

//          strDoExecuteCommandNewOuterClass=classObjRoot.getClassName();

          int intIndex=4;
          int intIndex2=strCommandTrail.indexOf('(', intIndex);
//          int intIndexZ=intIndex2+1;

          strClassName=strCommandTrail.substring(intIndex, intIndex2);

          int intParenthesisCount=1;

          intIndex2+=1;

          while(true) {
            char chr=strCommandTrail.charAt(intIndex2);

            if(chr=='(') {
              ++intParenthesisCount;
            }
            else if(chr==')') {
              --intParenthesisCount;

              if(intParenthesisCount==0)
                break;
            }

            ++intIndex2;
          }

          ++intIndex2;

          executeCommand(classObj, intAbsoluteLineNumber, strCommandTrail.substring(0, intIndex2), vecLocalFields);

          if(intIndex2==strCommandTrail.length()) {
            return strClassName;
          }
          else {
            strCommandTrail=strCommandTrail.substring(intIndex2+1);
          }
*/

        }
        else {
//          Hashtable hashInstanceFunctions=classObjRoot.getInstanceFunctions();

          String strFunctionName=strCommandTrail.substring(0, strCommandTrail.indexOf('('));

          if(strFunctionName.equals("start"))
            strFunctionName="run";

          String strCommandTrail0=strCommandTrail.toString();
          strCommandTrail=strCommandTrail.substring(strCommandTrail.indexOf('(')+1);

          Vector vecParameters=new Vector();
          int intParseParametersEnd=parseParameters(strCommandTrail, vecParameters, classObj, vecLocalFields, intAbsoluteLineNumber);


          FunctionObjectContainer fObjContainer=new FunctionObjectContainer();

          ClassObjectContainer classContainer=new ClassObjectContainer();

          String strClassNameZ[]=getFunctionObjectBySignature2(classObjRoot, classObj, strFunctionName, strCommandTrail0, vecParameters, fObjContainer, vecLocalFields, intAbsoluteLineNumber, classContainer);

          if(strClassNameZ[0].equals("true")) {
            return strClassNameZ[1];
          }

          strClassName=strClassNameZ[1];

          classObjRoot=classContainer.getClassObject();

          FunctionObject fObj=fObjContainer.getFunctionObject();

          FunctionSignature signature=fObj.getSignature();


/*
          FunctionSignature signature=new FunctionSignature(classObjRoot.getClassName(), strFunctionName, vecParameters);
          FunctionObject fObj=(FunctionObject)hashInstanceFunctions.get(signature);
          if(fObj==null) {
            String strClassNameSuper=classObjRoot.getSuperclass();

            ClassObject classObjSuper=(ClassObject)hashClasses.get(strClassNameSuper);

            if(classObjSuper==null) {
              String strClassNameReturn=getClassNameFromCommandTrail(strClassNameSuper, strCommandTrail0, classObj, vecLocalFields, intAbsoluteLineNumber);

              return strClassNameReturn;
            }
            else {
              String strClassNameReturn=doExecuteCommand(classObjSuper, strCommandTrail0, blnIsField, blnIsFunction, blnIsStatic, classObj, intAbsoluteLineNumber, vecLocalFields);

              return strClassNameReturn;
            }
          }
*/


//          if(!vecExecutedFunctions.contains(signature)) {
//            vecExecutedFunctions.addElement(signature);

          if(!vecExecutingFunctions.contains(signature)) {
            vecExecutingFunctions.addElement(signature);

//printConstructorFunctionStack();

            String strInstructions[]=fObj.getInstructions();

            int intAbsoluteLineNumber0=fObj.getAbsoluteLineNumber();

            Vector vecLocalFields0=new Vector();
            Vector vecCurrentBraceFields0=new Vector();
            vecLocalFields0.addElement(vecCurrentBraceFields0);

            Vector vecFunctionParameters=fObj.getFunctionParameters();
            for(int i=0;i<vecFunctionParameters.size();i++)
              vecCurrentBraceFields0.addElement(vecFunctionParameters.elementAt(i));

            if(hashFunctionCounts.containsKey(signature)) {
              long lngCount0=((Long)hashFunctionCounts.get(signature)).longValue();

              for(int i=0;i<vecCounts.size();i++) {
                long lngCount=((Long)vecCounts.elementAt(i)).longValue();
                lngCount+=lngCount0;
                vecCounts.setElementAt(new Long(lngCount), i);
              }
            }
            else {
              String strInstructionsZ[]=fObj.getInstructions();
              for(int i=0;i<vecCounts.size();i++) {
                long lngCount=((Long)vecCounts.elementAt(i)).longValue();
                lngCount+=(long)strInstructionsZ.length;
                vecCounts.setElementAt(new Long(lngCount), i);
              }

              vecCounts.addElement(new Long((long)strInstructionsZ.length));
            }

            executeInstructions(classObjRoot, strInstructions, intAbsoluteLineNumber0, 0, vecLocalFields0);

            if(!hashFunctionCounts.containsKey(signature)) {
              hashFunctionCounts.put(signature, vecCounts.elementAt(vecCounts.size()-1));

              vecCounts.removeElementAt(vecCounts.size()-1);
            }

            vecExecutingFunctions.removeElementAt(vecExecutingFunctions.size()-1);
          }

          Vector vecSubclasses=classObjRoot.getSubclasses();
          for(int i=0;i<vecSubclasses.size();i++) {
            String strSubclass=(String)vecSubclasses.elementAt(i);

            ClassObject classObjZ=(ClassObject)hashClasses.get(strSubclass);

            signature=new FunctionSignature(classObjZ.getClassName(), strFunctionName, vecParameters);
            FunctionObject fObjZ=(FunctionObject)classObjZ.getInstanceFunctions().get(signature);
            if(fObjZ!=null) {
//              if(!vecExecutedFunctions.contains(signature)) {
//                vecExecutedFunctions.addElement(signature);

              if(!vecExecutingFunctions.contains(signature)) {
                vecExecutingFunctions.addElement(signature);

//printConstructorFunctionStack();

                String strInstructionsZ[]=fObjZ.getInstructions();

                int intAbsoluteLineNumber0Z=fObjZ.getAbsoluteLineNumber();

                Vector vecLocalFields0Z=new Vector();
                Vector vecCurrentBraceFields0Z=new Vector();
                vecLocalFields0Z.addElement(vecCurrentBraceFields0Z);

                Vector vecFunctionParametersZ=fObjZ.getFunctionParameters();
                for(int ia=0;ia<vecFunctionParametersZ.size();ia++)
                  vecCurrentBraceFields0Z.addElement(vecFunctionParametersZ.elementAt(ia));

                if(hashFunctionCounts.containsKey(signature)) {
                  long lngCount0=((Long)hashFunctionCounts.get(signature)).longValue();

                  for(int izz=0;izz<vecCounts.size();izz++) {
                    long lngCount=((Long)vecCounts.elementAt(izz)).longValue();
                    lngCount+=lngCount0;
                    vecCounts.setElementAt(new Long(lngCount), izz);
                  }
                }
                else {
                  String strInstructionsZ2[]=fObjZ.getInstructions();
                  for(int izz=0;izz<vecCounts.size();izz++) {
                    long lngCount=((Long)vecCounts.elementAt(izz)).longValue();
                    lngCount+=(long)strInstructionsZ2.length;
                    vecCounts.setElementAt(new Long(lngCount), izz);
                  }

                  vecCounts.addElement(new Long((long)strInstructionsZ2.length));
                }

                executeInstructions(classObjZ, strInstructionsZ, intAbsoluteLineNumber0Z, 0, vecLocalFields0Z);

                if(!hashFunctionCounts.containsKey(signature)) {
                  hashFunctionCounts.put(signature, vecCounts.elementAt(vecCounts.size()-1));

                  vecCounts.removeElementAt(vecCounts.size()-1);
                }

                vecExecutingFunctions.removeElementAt(vecExecutingFunctions.size()-1);
              }
            }
          }


//          strClassName=fObj.getReturnClassName();

          strCommandTrail=strCommandTrail.substring(intParseParametersEnd);

          if(strCommandTrail.length()==0)
            return strClassName;

          if(!strCommandTrail.startsWith("."))
            throw new Exception("Encountered \""+strCommandTrail.charAt(0)+"\" when \".\" was expected for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

          strCommandTrail=strCommandTrail.substring(1);
        }
      }
    }

    if(strCommandTrail.length()==0)
      return strClassName;

    if(strClassName.indexOf('[')!=-1)
      return "int";

    ClassObject classObjRoot2=(ClassObject)hashClasses.get(strClassName);
    if(classObjRoot2==null)
      return getClassNameFromCommandTrail(strClassName, strCommandTrail, classObj, vecLocalFields, intAbsoluteLineNumber);

    int intLeastIndex=isPeriodParenthesisEndLeast(strCommandTrail);

    if(intLeastIndex==strCommandTrail.length()) {
//      Hashtable hashInstanceFields=classObjRoot2.getInstanceFields();

      String strFieldName=strCommandTrail;

      if(strFieldName.equals("class"))
        return "java.lang.Class";

      String strOperand2=strFieldName.toString();
      strFieldName=FieldObject.getFieldName(strFieldName);

      String strClassRootClass=getFieldObjectByName(classObjRoot2, strOperand2, strFieldName); 

      return strClassRootClass;


/*
      FieldObject fObj=(FieldObject)hashInstanceFields.get(strFieldName);
      if(fObj==null)
        throw new Exception("Unidentified field \""+strFieldName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

      String strClassRootClass=FieldObject.getClassName(strOperand2, fObj);

//      if(strClassRootClass.indexOf('[')!=-1)
//        return "int";

      return strClassRootClass;
*/

/*
      Hashtable hashInstanceFields=classObjRoot2.getInstanceFields();

      String strFieldName=strCommandTrail;

      FieldObject fObj=(FieldObject)hashInstanceFields.get(strFieldName);

      return fObj.getClassName();
*/
    }
    else {
      if(strCommandTrail.charAt(intLeastIndex)=='.') {
        blnIsField=true;
        blnIsFunction=false;
      }
      else if(strCommandTrail.charAt(intLeastIndex)=='(') {
        blnIsField=false;
        blnIsFunction=true;
      }
    }

    return doExecuteCommandNonStatic(classObjRoot2, strCommandTrail, blnIsField, blnIsFunction, classObj, intAbsoluteLineNumber, vecLocalFields);
  }

  public static String doExecuteCommandNonStatic(ClassObject classObjRoot, String strCommandTrail, boolean blnIsField, boolean blnIsFunction, ClassObject classObj, int intAbsoluteLineNumber, Vector vecLocalFields) throws Exception {
if(blnDoShowOutputExtended) {
System.out.println("doExecuteCommandNonStatic");
System.out.println(classObjRoot.getClassName());
System.out.println(classObj.getClassName());
System.out.println(strCommandTrail);
System.out.println(blnIsField);
System.out.println(blnIsFunction);
}

    String strClassName="";

    if(blnIsField) {
      int intIndex=0;

      int intBracketCountZ=0;

      while(true) {
        if(intIndex>=strCommandTrail.length())
          break;

        char chr=strCommandTrail.charAt(intIndex);

        if(chr=='.') {
          if(intBracketCountZ==0) {
            break;
          }
        }
        else if(chr=='[') {
          ++intBracketCountZ;
        }
        else if(chr==']') {
          --intBracketCountZ;
        }

        ++intIndex;
      }

      String strFieldName=strCommandTrail.substring(0, intIndex);

      if(strFieldName.equals("class"))
        strClassName="java.lang.Class";
      else {
//        Hashtable hashInstanceFields=classObjRoot.getInstanceFields();

        String strOperand=strFieldName.toString();
        strFieldName=FieldObject.getFieldName(strFieldName);

        String strClassNameZ[]=getFieldObjectByName2(classObjRoot, strOperand, strFieldName); 

        if(strClassNameZ[0].equals("true") && strClassNameZ[1].length()>0) {
          return strClassNameZ[1];
        }

        strClassName=strClassNameZ[1];

/*
        FieldObject fObj=(FieldObject)hashInstanceFields.get(strFieldName);
        if(fObj==null) {
          String strClassNameSuper=classObjRoot.getSuperclass();

          ClassObject classObjSuper=(ClassObject)hashClasses.get(strClassNameSuper);

          if(classObjSuper==null) {
            String strClassNameReturn=getClassNameFromCommandTrail(strClassNameSuper, strCommandTrail, classObj, vecLocalFields, intAbsoluteLineNumber);

            return strClassNameReturn;
          }
          else {
            String strClassNameReturn=doExecuteCommandNonStatic(classObjSuper, strCommandTrail, blnIsField, blnIsFunction, classObj, intAbsoluteLineNumber, vecLocalFields);

            return strClassNameReturn;
          }
        }

        strClassName=FieldObject.getClassName(strOperand, fObj);
*/

      }

      if(strCommandTrail.length()==intIndex)
        strCommandTrail="";
      else
        strCommandTrail=strCommandTrail.substring(intIndex+1);
    }
    else if(blnIsFunction) {
      if(strCommandTrail.startsWith("new ")) {

        StringContainer strContainer=new StringContainer();
        StringContainer strContainer2=new StringContainer();
        parseNew(classObj, vecLocalFields, strCommandTrail, intAbsoluteLineNumber, strContainer, classObjRoot.getClassName(), strContainer2);

        return strContainer2.getStr();

/*
//        strDoExecuteCommandNewOuterClass=classObjRoot.getClassName();

        int intIndex=4;
        int intIndex2=strCommandTrail.indexOf('(', intIndex);
//        int intIndexZ=intIndex2+1;

        strClassName=strCommandTrail.substring(intIndex, intIndex2);

        int intParenthesisCount=1;

        intIndex2+=1;

        while(true) {
          char chr=strCommandTrail.charAt(intIndex2);

          if(chr=='(') {
            ++intParenthesisCount;
          }
          else if(chr==')') {
            --intParenthesisCount;

            if(intParenthesisCount==0)
              break;
          }

          ++intIndex2;
        }

        ++intIndex2;

        executeCommand(classObj, intAbsoluteLineNumber, strCommandTrail.substring(0, intIndex2), vecLocalFields);

        if(intIndex2==strCommandTrail.length()) {
          return strClassName;
        }
        else {
          strCommandTrail=strCommandTrail.substring(intIndex2+1);
        }
*/

      }
      else {
//        Hashtable hashInstanceFunctions=classObjRoot.getInstanceFunctions();

        String strFunctionName=strCommandTrail.substring(0, strCommandTrail.indexOf('('));

        if(strFunctionName.equals("start"))
          strFunctionName="run";

        String strCommandTrail0=strCommandTrail.toString();
        strCommandTrail=strCommandTrail.substring(strCommandTrail.indexOf('(')+1);

        Vector vecParameters=new Vector();
        int intParseParametersEnd=parseParameters(strCommandTrail, vecParameters, classObj, vecLocalFields, intAbsoluteLineNumber);


        FunctionObjectContainer fObjContainer=new FunctionObjectContainer();

        ClassObjectContainer classContainer=new ClassObjectContainer();

        String strClassNameZ[]=getFunctionObjectBySignature2(classObjRoot, classObj, strFunctionName, strCommandTrail0, vecParameters, fObjContainer, vecLocalFields, intAbsoluteLineNumber, classContainer);

        if(strClassNameZ[0].equals("true")) {
          return strClassNameZ[1];
        }

        strClassName=strClassNameZ[1];

        classObjRoot=classContainer.getClassObject();

        FunctionObject fObj=fObjContainer.getFunctionObject();

        FunctionSignature signature=fObj.getSignature();


/*
        FunctionSignature signature=new FunctionSignature(classObjRoot.getClassName(), strFunctionName, vecParameters);
//System.out.println("functionSignature: "+signature.toString());
        FunctionObject fObj=(FunctionObject)hashInstanceFunctions.get(signature);
        if(fObj==null) {
          String strClassNameSuper=classObjRoot.getSuperclass();

          ClassObject classObjSuper=(ClassObject)hashClasses.get(strClassNameSuper);

          if(classObjSuper==null) {
            String strClassNameReturn=getClassNameFromCommandTrail(strClassNameSuper, strCommandTrail0, classObj, vecLocalFields, intAbsoluteLineNumber);

            return strClassNameReturn;
          }
          else {
            String strClassNameReturn=doExecuteCommandNonStatic(classObjSuper, strCommandTrail0, blnIsField, blnIsFunction, classObj, intAbsoluteLineNumber, vecLocalFields);

            return strClassNameReturn;
          }
        }
*/


//        if(!vecExecutedFunctions.contains(signature)) {
//          vecExecutedFunctions.addElement(signature);

        if(!vecExecutingFunctions.contains(signature)) {
          vecExecutingFunctions.addElement(signature);

//printConstructorFunctionStack();

          String strInstructions[]=fObj.getInstructions();

          int intAbsoluteLineNumber0=fObj.getAbsoluteLineNumber();

          Vector vecLocalFields0=new Vector();
          Vector vecCurrentBraceFields0=new Vector();
          vecLocalFields0.addElement(vecCurrentBraceFields0);

          Vector vecFunctionParameters=fObj.getFunctionParameters();
          for(int i=0;i<vecFunctionParameters.size();i++)
            vecCurrentBraceFields0.addElement(vecFunctionParameters.elementAt(i));

          if(hashFunctionCounts.containsKey(signature)) {
            long lngCount0=((Long)hashFunctionCounts.get(signature)).longValue();

            for(int i=0;i<vecCounts.size();i++) {
              long lngCount=((Long)vecCounts.elementAt(i)).longValue();
              lngCount+=lngCount0;
              vecCounts.setElementAt(new Long(lngCount), i);
            }
          }
          else {
            String strInstructionsZ[]=fObj.getInstructions();
            for(int i=0;i<vecCounts.size();i++) {
              long lngCount=((Long)vecCounts.elementAt(i)).longValue();
              lngCount+=(long)strInstructionsZ.length;
              vecCounts.setElementAt(new Long(lngCount), i);
            }

            vecCounts.addElement(new Long((long)strInstructionsZ.length));
          }

          executeInstructions(classObjRoot, strInstructions, intAbsoluteLineNumber0, 0, vecLocalFields0);

          if(!hashFunctionCounts.containsKey(signature)) {
            hashFunctionCounts.put(signature, vecCounts.elementAt(vecCounts.size()-1));

            vecCounts.removeElementAt(vecCounts.size()-1);
          }

          vecExecutingFunctions.removeElementAt(vecExecutingFunctions.size()-1);
        }

        Vector vecSubclasses=classObjRoot.getSubclasses();
        for(int i=0;i<vecSubclasses.size();i++) {
          String strSubclass=(String)vecSubclasses.elementAt(i);

          ClassObject classObjZ=(ClassObject)hashClasses.get(strSubclass);

          signature=new FunctionSignature(classObjZ.getClassName(), strFunctionName, vecParameters);
          FunctionObject fObjZ=(FunctionObject)classObjZ.getInstanceFunctions().get(signature);
          if(fObjZ!=null) {
//            if(!vecExecutedFunctions.contains(signature)) {
//              vecExecutedFunctions.addElement(signature);

            if(!vecExecutingFunctions.contains(signature)) {
              vecExecutingFunctions.addElement(signature);

//printConstructorFunctionStack();

              String strInstructionsZ[]=fObjZ.getInstructions();

              int intAbsoluteLineNumber0Z=fObjZ.getAbsoluteLineNumber();

              Vector vecLocalFields0Z=new Vector();
              Vector vecCurrentBraceFields0Z=new Vector();
              vecLocalFields0Z.addElement(vecCurrentBraceFields0Z);

              Vector vecFunctionParametersZ=fObjZ.getFunctionParameters();
              for(int ia=0;ia<vecFunctionParametersZ.size();ia++)
                vecCurrentBraceFields0Z.addElement(vecFunctionParametersZ.elementAt(ia));

              if(hashFunctionCounts.containsKey(signature)) {
                long lngCount0=((Long)hashFunctionCounts.get(signature)).longValue();

                for(int izz=0;izz<vecCounts.size();izz++) {
                  long lngCount=((Long)vecCounts.elementAt(izz)).longValue();
                  lngCount+=lngCount0;
                  vecCounts.setElementAt(new Long(lngCount), izz);
                }
              }
              else {
                String strInstructionsZ2[]=fObjZ.getInstructions();
                for(int izz=0;izz<vecCounts.size();izz++) {
                  long lngCount=((Long)vecCounts.elementAt(izz)).longValue();
                  lngCount+=(long)strInstructionsZ2.length;
                  vecCounts.setElementAt(new Long(lngCount), izz);
                }

                vecCounts.addElement(new Long((long)strInstructionsZ2.length));
              }

              executeInstructions(classObjZ, strInstructionsZ, intAbsoluteLineNumber0Z, 0, vecLocalFields0Z);

              if(!hashFunctionCounts.containsKey(signature)) {
                hashFunctionCounts.put(signature, vecCounts.elementAt(vecCounts.size()-1));

                vecCounts.removeElementAt(vecCounts.size()-1);
              }

              vecExecutingFunctions.removeElementAt(vecExecutingFunctions.size()-1);
            }
          }
        }


//        strClassName=fObj.getReturnClassName();

        strCommandTrail=strCommandTrail.substring(intParseParametersEnd);

        if(strCommandTrail.length()==0)
          return strClassName;

        if(!strCommandTrail.startsWith("."))
          throw new Exception("Encountered \""+strCommandTrail.charAt(0)+"\" when \".\" was expected for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

        strCommandTrail=strCommandTrail.substring(1);
      }

    }

    if(strCommandTrail.length()==0)
      return strClassName;

    if(strClassName.indexOf('[')!=-1)
      return "int";

    ClassObject classObjRoot2=(ClassObject)hashClasses.get(strClassName);
    if(classObjRoot2==null)
      return getClassNameFromCommandTrail(strClassName, strCommandTrail, classObj, vecLocalFields, intAbsoluteLineNumber);

    int intLeastIndex=isPeriodParenthesisEndLeast(strCommandTrail);

    if(intLeastIndex==strCommandTrail.length()) {
//      Hashtable hashInstanceFields=classObjRoot2.getInstanceFields();

      String strFieldName=strCommandTrail;

      if(strFieldName.equals("class"))
        return "java.lang.Class";

      String strOperand2=strFieldName.toString();
      strFieldName=FieldObject.getFieldName(strFieldName);

      String strClassRootClass=getFieldObjectByName(classObjRoot2, strOperand2, strFieldName); 

      return strClassRootClass;


/*
      FieldObject fObj=(FieldObject)hashInstanceFields.get(strFieldName);
      if(fObj==null)
        throw new Exception("Unidentified field \""+strFieldName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

      String strClassRootClass=FieldObject.getClassName(strOperand2, fObj);

//      if(strClassRootClass.indexOf('[')!=-1)
//        return "int";

      return strClassRootClass;
*/

/*
      Hashtable hashInstanceFields=classObjRoot2.getInstanceFields();

      String strFieldName=strCommandTrail;

      FieldObject fObj=(FieldObject)hashInstanceFields.get(strFieldName);

      return fObj.getClassName();
*/
    }
    else {
      if(strCommandTrail.charAt(intLeastIndex)=='.') {
        blnIsField=true;
        blnIsFunction=false;
      }
      else if(strCommandTrail.charAt(intLeastIndex)=='(') {
        blnIsField=false;
        blnIsFunction=true;
      }
    }

    return doExecuteCommandNonStatic(classObjRoot2, strCommandTrail, blnIsField, blnIsFunction, classObj, intAbsoluteLineNumber, vecLocalFields);
  }

  public static String parseFieldParameterClass(String strClassName, String strNextLine, String strNextFieldClass, char chrArr[]) throws Exception {
    String strArrays="";
    while(true) {
      if(strNextFieldClass.endsWith("[]")) {
        strArrays+="[]";
        strNextFieldClass=strNextFieldClass.substring(0, strNextFieldClass.length()-2);
        continue;
      }

      break;
    }

    if(strArrays.length()==0) {

      int intLeastIndex=Integer.MAX_VALUE;

      for(int i=0;i<chrArr.length;i++) {
        int intNextIndex=strNextLine.indexOf(chrArr[i]);
        if(intNextIndex!=-1) {
          if(intNextIndex<intLeastIndex) {
            intLeastIndex=intNextIndex;
          }
        }
      }
/*
      int intEqualsIndex=strNextLine.indexOf('=');

      if(intEqualsIndex==-1)
        intEqualsIndex=Integer.MAX_VALUE;

      int intSemiColonIndex=strNextLine.indexOf(';');

      if(intSemiColonIndex==-1)
        intSemiColonIndex=Integer.MAX_VALUE;

      int intLeastIndex=-1;
      if(intEqualsIndex<intSemiColonIndex)
        intLeastIndex=intEqualsIndex;
      else
        intLeastIndex=intSemiColonIndex;
*/

      int intArrayIndex=0;
      while(true) {
        intArrayIndex=strNextLine.indexOf("[]", intArrayIndex);
        if(intArrayIndex!=-1) {
          if(intLeastIndex<intArrayIndex)
            break;

          strArrays+="[]";
          intArrayIndex+=1;
          continue;
        }

        break;
      }
    }

    strNextFieldClass=strNextFieldClass.replace(".", "$");

    int intDollarIndex0=strNextFieldClass.indexOf("$");

    if(intDollarIndex0!=-1) {
      String strNextFieldClass0=strNextFieldClass.substring(0, intDollarIndex0);

      strNextFieldClass0=(String)hashImported.get(strNextFieldClass0);

      strNextFieldClass=strNextFieldClass0+"$"+strNextFieldClass.substring(intDollarIndex0+1);
    }
    else {
      int intDollarIndex=strClassName.indexOf("$");
      if(intDollarIndex!=-1)
        strClassName=strClassName.substring(0, intDollarIndex);

      try {
        Class.forName(strClassName+"$"+strNextFieldClass);

        strNextFieldClass=strClassName+"$"+strNextFieldClass;
      }
      catch(Exception ex) {
        strNextFieldClass=(String)hashImported.get(strNextFieldClass);
      }
    }

    return strNextFieldClass+strArrays;
  }

  public static String parseFieldParameterName(String strNextLine) throws Exception {
    while(true) {
      if(strNextLine.charAt(0)==' ' || strNextLine.charAt(0)=='[' || strNextLine.charAt(0)==']') {
        strNextLine=strNextLine.substring(1);
        continue;
      }

      break;
    }

    StringBuffer sBuf=new StringBuffer();
    while(true) {
      if(Character.isLetter(strNextLine.charAt(0)) || Character.isDigit(strNextLine.charAt(0)) || strNextLine.charAt(0)=='_') {
        sBuf.append(strNextLine.charAt(0));
        strNextLine=strNextLine.substring(1);
        continue;
      }

      break;
    }

    return sBuf.toString();
  }

  public static Vector parseConstructorFunctionInstructions(BufferedReaderArray br) throws Exception {
    Vector vecInstructions=new Vector();

    int intCurlyBraceCount=1;
    boolean blnMustBreak=false;

    String strNextLine="";
    while((strNextLine=br.readLine())!=null) {
//      intAbsoluteLineNumber+=1;

      String strNextLineCopy=strNextLine.toString();

      while(true) {
        if(strNextLineCopy.length()==0)
          break;

        if(strNextLineCopy.charAt(0)==' ') {
          strNextLineCopy=strNextLineCopy.substring(1);
          continue;
        }

        break;
      }

      if(strNextLineCopy.length()>0) {
        while(true) {
          int intCurlyBraceOpenIndex=strNextLine.indexOf('{');

          int intCurlyBraceCloseIndex=strNextLine.indexOf('}');

          if(intCurlyBraceOpenIndex==-1 && intCurlyBraceCloseIndex==-1)
            break;

          if(intCurlyBraceOpenIndex!=-1) {
            if(intCurlyBraceCloseIndex!=-1) {
              if(intCurlyBraceOpenIndex<intCurlyBraceCloseIndex) {
                strNextLine=strNextLine.substring(intCurlyBraceOpenIndex+1);
                ++intCurlyBraceCount;
              }
              else {
                strNextLine=strNextLine.substring(intCurlyBraceCloseIndex+1);
                --intCurlyBraceCount;
              }
            }
            else {
              strNextLine=strNextLine.substring(intCurlyBraceOpenIndex+1);
              ++intCurlyBraceCount;
            }
          }
          else {
            if(intCurlyBraceCloseIndex!=-1) {
              strNextLine=strNextLine.substring(intCurlyBraceCloseIndex+1);
              --intCurlyBraceCount;
            }
            else {
            }
          }

          if(intCurlyBraceCount==0) {
            blnMustBreak=true;
            break;
          }
        }

        if(blnMustBreak)
          break;

      }

      vecInstructions.addElement(strNextLineCopy);
    }

    return vecInstructions;
  }

  public static int parseConstructorFunctionInstructions(String strInstructions[], int instructionIndex) throws Exception {
    int intCurlyBraceCount=1;
    boolean blnMustBreak=false;

    String strNextLine="";
    while(instructionIndex<strInstructions.length) {
//      intAbsoluteLineNumber+=1;

      strNextLine=strInstructions[instructionIndex];
      instructionIndex++;

      String strNextLineCopy=strNextLine.toString();

      while(true) {
        if(strNextLineCopy.length()==0)
          break;

        if(strNextLineCopy.charAt(0)==' ') {
          strNextLineCopy=strNextLineCopy.substring(1);
          continue;
        }

        break;
      }

      if(strNextLineCopy.length()>0) {
        while(true) {
          int intCurlyBraceOpenIndex=strNextLine.indexOf('{');

          int intCurlyBraceCloseIndex=strNextLine.indexOf('}');

          if(intCurlyBraceOpenIndex==-1 && intCurlyBraceCloseIndex==-1)
            break;

          if(intCurlyBraceOpenIndex!=-1) {
            if(intCurlyBraceCloseIndex!=-1) {
              if(intCurlyBraceOpenIndex<intCurlyBraceCloseIndex) {
                strNextLineCopy=strNextLineCopy.substring(intCurlyBraceOpenIndex+1);
                ++intCurlyBraceCount;
              }
              else {
                strNextLineCopy=strNextLineCopy.substring(intCurlyBraceCloseIndex+1);
                --intCurlyBraceCount;
              }
            }
            else {
              strNextLineCopy=strNextLineCopy.substring(intCurlyBraceOpenIndex+1);
              ++intCurlyBraceCount;
            }
          }
          else {
            if(intCurlyBraceCloseIndex!=-1) {
              strNextLineCopy=strNextLineCopy.substring(intCurlyBraceCloseIndex+1);
              --intCurlyBraceCount;
            }
            else {
            }
          }

          if(intCurlyBraceCount==0) {
            blnMustBreak=true;
            break;
          }
        }

        if(blnMustBreak)
          break;

      }

    }

    return instructionIndex;
  }

  public static void parseNew0(ClassObject classObj, Vector vecLocalFields, String strNextLine, int intAbsoluteLineNumber, String strOuterClassName, StringContainer strContainer) throws Exception {
    int intIndex=strNextLine.indexOf('(');

    String strNewClass0=strNextLine.substring(4, intIndex);
    String strNewClass=(String)hashImported.get(strNewClass0);

    if(strNewClass==null) {
      strNewClass=strOuterClassName;

      strNewClass+="$"+strNewClass0;
    }

    int intIndexPosition=-1;

    if(hashClasses.containsKey(strNewClass)) {
      intIndexPosition=intIndex+1;

//System.out.println("herez:0"+strNextLine);

      Vector vecParameters=new Vector();
      int intParseParametersEnd=parseParameters(strNextLine.substring(intIndexPosition), vecParameters, classObj, vecLocalFields, intAbsoluteLineNumber);

//System.out.println("herez:1"+strNextLine);

      ClassObject classObj2=(ClassObject)hashClasses.get(strNewClass);

      if((intParseParametersEnd+intIndexPosition)<strNextLine.length() && strNextLine.charAt(intParseParametersEnd+intIndexPosition)=='.') {
        int intIndex2=intParseParametersEnd+intIndexPosition+2;

        while(true) {
          if(intIndex2>=strNextLine.length())
            break;

          char chr=strNextLine.charAt(intIndex2);

          if(chr==';') {
            break;
          }

          ++intIndex2;
        }

        String strCommandTrail=strNextLine.substring(intParseParametersEnd+intIndexPosition+1, intIndex2);

        int intLeastIndex=isPeriodParenthesisEndLeast(strCommandTrail);

        if(intLeastIndex==strCommandTrail.length()) {
          Hashtable hashInstanceFields=classObj2.getInstanceFields();

          String strClassRootName=strCommandTrail;
          String strOperand2=strClassRootName.toString();
          strClassRootName=FieldObject.getFieldName(strClassRootName);

          FieldObject nextField=(FieldObject)hashInstanceFields.get(strClassRootName);
          if(nextField==null)
            throw new Exception("Unidentified field \""+strCommandTrail+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

          String strClassRootClass=FieldObject.getClassName(strOperand2, nextField);

          strNewClass=strClassRootClass;
        }
        else {
          boolean blnIsField=false;
          boolean blnIsFunction=false;

          if(strCommandTrail.charAt(intLeastIndex)=='.') {
            blnIsField=true;
            blnIsFunction=false;
          }
          else if(strCommandTrail.charAt(intLeastIndex)=='(') {
            blnIsField=false;
            blnIsFunction=true;
          }

          strNewClass=doExecuteCommandNonStatic(classObj2, strCommandTrail, blnIsField, blnIsFunction, classObj, intAbsoluteLineNumber, vecLocalFields);
        }
      }

//System.out.println("constructorSignature");
//System.out.println(classObj2.getClassName()+":"+vecParameters.size());
//for(int i=0;i<vecParameters.size();i++)
//System.out.println(vecParameters.elementAt(i));

      ConstructorSignature signature=new ConstructorSignature(classObj2.getClassName(), vecParameters);

//      if(!vecExecutedConstructors.contains(signature)) {
//        vecExecutedConstructors.addElement(signature);

      if(!vecExecutingConstructors.contains(signature)) {
        vecExecutingConstructors.addElement(signature);

//printConstructorFunctionStack();

        ConstructorObject constructorObj=(ConstructorObject)classObj2.getConstructors().get(signature);

        if(constructorObj==null)
          throw new Exception("Constructor not found for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

        Vector vecLocalFields0=new Vector();
        Vector vecCurrentBraceFields0=new Vector();
        vecLocalFields0.addElement(vecCurrentBraceFields0);

        Vector vecConstructorParameters=constructorObj.getConstructorParameters();
        for(int i=0;i<vecConstructorParameters.size();i++)
          vecCurrentBraceFields0.addElement(vecConstructorParameters.elementAt(i));

        if(hashConstructorCounts.containsKey(signature)) {
          long lngCount0=((Long)hashConstructorCounts.get(signature)).longValue();

          for(int i=0;i<vecCounts.size();i++) {
            long lngCount=((Long)vecCounts.elementAt(i)).longValue();
            lngCount+=lngCount0;
            vecCounts.setElementAt(new Long(lngCount), i);
          }
        }
        else {
          String strInstructionsZ[]=constructorObj.getInstructions();
          for(int i=0;i<vecCounts.size();i++) {
            long lngCount=((Long)vecCounts.elementAt(i)).longValue();
            lngCount+=(long)strInstructionsZ.length;
            vecCounts.setElementAt(new Long(lngCount), i);
          }

          vecCounts.addElement(new Long((long)strInstructionsZ.length));
        }

        executeInstructions(classObj2, constructorObj.getInstructions(), constructorObj.getAbsoluteLineNumber(), 0, vecLocalFields0);

        if(!hashConstructorCounts.containsKey(signature)) {
          hashConstructorCounts.put(signature, vecCounts.elementAt(vecCounts.size()-1));

          vecCounts.removeElementAt(vecCounts.size()-1);
        }

        vecExecutingConstructors.removeElementAt(vecExecutingConstructors.size()-1);
      }
    }
    else {
      intIndexPosition=intIndex+1;

      Vector vecParameters=new Vector();
      int intParseParametersEnd=parseParameters(strNextLine.substring(intIndexPosition), vecParameters, classObj, vecLocalFields, intAbsoluteLineNumber);
//      intParseParametersEnd-=2;

//if(intParseParametersEnd<strNextLine.length())
//System.out.println("parseNew:0a:"+strNextLine.substring(intParseParametersEnd+intIndexPosition));
//else
//System.out.println("parseNew:0b:"+strNextLine);
      if((intParseParametersEnd+intIndexPosition)<strNextLine.length() && strNextLine.charAt(intParseParametersEnd+intIndexPosition)=='.') {
//System.out.println("parseNew:1:"+strNextLine);
        int intIndex2=intParseParametersEnd+intIndexPosition+2;

        while(true) {
          if(intIndex2>=strNextLine.length())
            break;

          char chr=strNextLine.charAt(intIndex2);

          if(chr==';') {
            break;
          }

          ++intIndex2;
        }

        String strCommandTrail=strNextLine.substring(intParseParametersEnd+intIndexPosition+1, intIndex2);

        strNewClass=getClassNameFromCommandTrail(strNewClass, strCommandTrail, classObj, vecLocalFields, intAbsoluteLineNumber);
      }
    }

    strContainer.setStr(strNewClass);
  }

  public static int parseNew(ClassObject classObj, Vector vecLocalFields, String strNextLine, int intAbsoluteLineNumber, String strOuterClassName) throws Exception {
    return parseNew(classObj, vecLocalFields, strNextLine, intAbsoluteLineNumber, new StringContainer(), strOuterClassName);
  }

  public static int parseNew(ClassObject classObj, Vector vecLocalFields, String strNextLine, int intAbsoluteLineNumber, StringContainer strContainer, String strOuterClassName) throws Exception {
    return parseNew(classObj, vecLocalFields, strNextLine, intAbsoluteLineNumber, strContainer, strOuterClassName, new StringContainer());
  }

  public static int parseNew(ClassObject classObj, Vector vecLocalFields, String strNextLine, int intAbsoluteLineNumber, StringContainer strContainer, String strOuterClassName, StringContainer strContainer2) throws Exception {
    String strReturnClass="";

    int intRet=strNextLine.lastIndexOf(';');

    int intIndex=strNextLine.indexOf('(');

    String strNewClass0=strNextLine.substring(4, intIndex);
    String strNewClass=(String)hashImported.get(strNewClass0);

    if(strNewClass==null) {
      strNewClass=strOuterClassName;

      strNewClass+="$"+strNewClass0;
    }

    Vector vecOperands=parseOperands(strNextLine);

    String strNextOperand=(String)vecOperands.elementAt(0);

    StringContainer strContainerZ=new StringContainer();
    parseNew0(classObj, vecLocalFields, strNextOperand, intAbsoluteLineNumber, strOuterClassName, strContainerZ);
    strReturnClass=strContainerZ.getStr();
    strContainer2.setStr(strReturnClass);

    for(int i=1;i<vecOperands.size();i++) {
      strNextOperand=(String)vecOperands.elementAt(i);

      if(strNextOperand.startsWith("new ")) {
        parseNew0(classObj, vecLocalFields, strNextOperand, intAbsoluteLineNumber, strOuterClassName, new StringContainer());
      }
      else
        executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
    }

    strContainer.setStr(strNewClass);

    return intRet;

/*
    int intRet=strNextLine.lastIndexOf(';');

    int intIndex=strNextLine.indexOf('(');

    String strNewClass0=strNextLine.substring(4, intIndex);
    String strNewClass=(String)hashImported.get(strNewClass0);

    if(strNewClass==null) {
      strNewClass=strOuterClassName;

      strNewClass+="$"+strNewClass0;
    }

    int intIndexPosition=-1;

    if(hashClasses.containsKey(strNewClass)) {
      intIndexPosition=intIndex+1;

//System.out.println("herez:0"+strNextLine);

      Vector vecParameters=new Vector();
      int intParseParametersEnd=parseParameters(strNextLine.substring(intIndexPosition), vecParameters, classObj, vecLocalFields, intAbsoluteLineNumber);

//System.out.println("herez:1"+strNextLine);

      ClassObject classObj2=(ClassObject)hashClasses.get(strNewClass);

      if((intParseParametersEnd+intIndexPosition)<strNextLine.length() && strNextLine.charAt(intParseParametersEnd+intIndexPosition)=='.') {
        int intIndex2=intParseParametersEnd+intIndexPosition+2;

        while(true) {
          if(intIndex2>=strNextLine.length())
            break;

          char chr=strNextLine.charAt(intIndex2);

          if(chr==';') {
            break;
          }

          ++intIndex2;
        }

        String strCommandTrail=strNextLine.substring(intParseParametersEnd+intIndexPosition+1, intIndex2);

        int intLeastIndex=isPeriodParenthesisEndLeast(strCommandTrail);

        if(intLeastIndex==strCommandTrail.length()) {
          Hashtable hashInstanceFields=classObj2.getInstanceFields();

          String strClassRootName=strCommandTrail;
          String strOperand2=strClassRootName.toString();
          strClassRootName=FieldObject.getFieldName(strClassRootName);

          FieldObject nextField=(FieldObject)hashInstanceFields.get(strClassRootName);
          if(nextField==null)
            throw new Exception("Unidentified field \""+strCommandTrail+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

          String strClassRootClass=FieldObject.getClassName(strOperand2, nextField);

          strNewClass=strClassRootClass;
        }
        else {
          boolean blnIsField=false;
          boolean blnIsFunction=false;

          if(strCommandTrail.charAt(intLeastIndex)=='.') {
            blnIsField=true;
            blnIsFunction=false;
          }
          else if(strCommandTrail.charAt(intLeastIndex)=='(') {
            blnIsField=false;
            blnIsFunction=true;
          }

          strNewClass=doExecuteCommandNonStatic(classObj2, strCommandTrail, blnIsField, blnIsFunction, classObj, intAbsoluteLineNumber, vecLocalFields);
        }
      }

//System.out.println("constructorSignature");
//System.out.println(classObj2.getClassName()+":"+vecParameters.size());
//for(int i=0;i<vecParameters.size();i++)
//System.out.println(vecParameters.elementAt(i));

      ConstructorSignature signature=new ConstructorSignature(classObj2.getClassName(), vecParameters);

//      if(!vecExecutedConstructors.contains(signature)) {
//        vecExecutedConstructors.addElement(signature);

      if(!vecExecutingConstructors.contains(signature)) {
        vecExecutingConstructors.addElement(signature);

//printConstructorFunctionStack();

        ConstructorObject constructorObj=(ConstructorObject)classObj2.getConstructors().get(signature);

        if(constructorObj==null)
          throw new Exception("Constructor not found for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

        Vector vecLocalFields0=new Vector();
        Vector vecCurrentBraceFields0=new Vector();
        vecLocalFields0.addElement(vecCurrentBraceFields0);

        Vector vecConstructorParameters=constructorObj.getConstructorParameters();
        for(int i=0;i<vecConstructorParameters.size();i++)
          vecCurrentBraceFields0.addElement(vecConstructorParameters.elementAt(i));

        if(hashConstructorCounts.containsKey(signature)) {
          long lngCount0=((Long)hashConstructorCounts.get(signature)).longValue();

          for(int i=0;i<vecCounts.size();i++) {
            long lngCount=((Long)vecCounts.elementAt(i)).longValue();
            lngCount+=lngCount0;
            vecCounts.setElementAt(new Long(lngCount), i);
          }
        }
        else {
          String strInstructionsZ[]=constructorObj.getInstructions();
          for(int i=0;i<vecCounts.size();i++) {
            long lngCount=((Long)vecCounts.elementAt(i)).longValue();
            lngCount+=(long)strInstructionsZ.length;
            vecCounts.setElementAt(new Long(lngCount), i);
          }

          vecCounts.addElement(new Long((long)strInstructionsZ.length));
        }

        executeInstructions(classObj2, constructorObj.getInstructions(), constructorObj.getAbsoluteLineNumber(), 0, vecLocalFields0);

        if(!hashConstructorCounts.containsKey(signature)) {
          hashConstructorCounts.put(signature, vecCounts.elementAt(vecCounts.size()-1));

          vecCounts.removeElementAt(vecCounts.size()-1);
        }

        vecExecutingConstructors.removeElementAt(vecExecutingConstructors.size()-1);
      }
    }
    else {
      intIndexPosition=intIndex+1;

      Vector vecParameters=new Vector();
      int intParseParametersEnd=parseParameters(strNextLine.substring(intIndexPosition), vecParameters, classObj, vecLocalFields, intAbsoluteLineNumber);
//      intParseParametersEnd-=2;

//if(intParseParametersEnd<strNextLine.length())
//System.out.println("parseNew:0a:"+strNextLine.substring(intParseParametersEnd+intIndexPosition));
//else
//System.out.println("parseNew:0b:"+strNextLine);
      if((intParseParametersEnd+intIndexPosition)<strNextLine.length() && strNextLine.charAt(intParseParametersEnd+intIndexPosition)=='.') {
//System.out.println("parseNew:1:"+strNextLine);
        int intIndex2=intParseParametersEnd+intIndexPosition+2;

        while(true) {
          if(intIndex2>=strNextLine.length())
            break;

          char chr=strNextLine.charAt(intIndex2);

          if(chr==';') {
            break;
          }

          ++intIndex2;
        }

        String strCommandTrail=strNextLine.substring(intParseParametersEnd+intIndexPosition+1, intIndex2);

        strNewClass=getClassNameFromCommandTrail(strNewClass, strCommandTrail, classObj, vecLocalFields, intAbsoluteLineNumber);
      }
    }

    strContainer.setStr(strNewClass);

    return intRet;
*/

/*
    String strNextLineCopy=strNextLine.toString();

    int intIndexPosition=0;

    strNextLine=strNextLine.substring(4);
    intIndexPosition+=4;

    int intIndex=strNextLine.indexOf('(');

    String strNewClass=strNextLine.substring(0, intIndex);
    strNewClass=(String)hashImported.get(strNewClass);

    if(hashClasses.containsKey(strNewClass)) {
      strNextLine=strNextLine.substring(intIndex+1);
      intIndexPosition+=(intIndex+1);

//System.out.println("herez:0"+strNextLine);

      Vector vecParameters=new Vector();
      int intIndexPositionAdd=parseParameters(strNextLine, vecParameters, classObj, vecLocalFields, intAbsoluteLineNumber);
      strNextLine=strNextLine.substring(intIndexPositionAdd);
      intIndexPosition+=intIndexPositionAdd;

//System.out.println("herez:1"+strNextLine);

      int intIndex2=0;

//      int intIndex2=intIndexPosition;

      if(strNextLineCopy.charAt(intIndex2)=='.') {
        while(true) {
          char chr=strNextLineCopy.charAt(intIndex2);

          if(chr==';') {
            break;
          }
          else if(chr==',') {
            break;
          }
          else if(chr==' ') {
            break;
          }
          else if(chr==')') {
            break;
          }

          ++intIndex2;
        }

        if(strNextLineCopy.charAt(intIndex2)==')')
          ++intIndex2;

        String strOperands=strNextLineCopy.substring(0, intIndex2);

        Vector vecOperands=parseOperands(strOperands);
        for(int i=0;i<vecOperands.size();i++) {
          String strNextOperand=(String)vecOperands.elementAt(i);
          executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
        }

//        executeCommand(classObj, intAbsoluteLineNumber, strNextLineCopy.substring(0, intIndex2), vecLocalFields);
      }

      ClassObject classObj2=(ClassObject)hashClasses.get(strNewClass);

      ConstructorSignature signature=new ConstructorSignature(classObj2.getClassName(), vecParameters);

//      if(!vecExecutedConstructors.contains(signature)) {
//        vecExecutedConstructors.addElement(signature);

      if(!vecExecutingConstructors.contains(signature)) {
        vecExecutingConstructors.addElement(signature);

//printConstructorFunctionStack();

        ConstructorObject constructorObj=(ConstructorObject)classObj2.getConstructors().get(signature);

        if(constructorObj==null)
          throw new Exception("Constructor not found for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

        Vector vecLocalFields0=new Vector();
        Vector vecCurrentBraceFields0=new Vector();
        vecLocalFields0.addElement(vecCurrentBraceFields0);

        Vector vecConstructorParameters=constructorObj.getConstructorParameters();
        for(int i=0;i<vecConstructorParameters.size();i++)
          vecCurrentBraceFields0.addElement(vecConstructorParameters.elementAt(i));

        if(hashConstructorCounts.containsKey(signature)) {
          long lngCount0=((Long)hashConstructorCounts.get(signature)).longValue();

          for(int i=0;i<vecCounts.size();i++) {
            long lngCount=((Long)vecCounts.elementAt(i)).longValue();
            lngCount+=lngCount0;
            vecCounts.setElementAt(new Long(lngCount), i);
          }
        }
        else {
          String strInstructionsZ[]=constructorObj.getInstructions();
          for(int i=0;i<vecCounts.size();i++) {
            long lngCount=((Long)vecCounts.elementAt(i)).longValue();
            lngCount+=(long)strInstructionsZ.length;
            vecCounts.setElementAt(new Long(lngCount), i);
          }

          vecCounts.addElement(new Long((long)strInstructionsZ.length));
        }

        executeInstructions(classObj2, constructorObj.getInstructions(), constructorObj.getAbsoluteLineNumber(), 0, vecLocalFields0);

        if(!hashConstructorCounts.containsKey(signature)) {
          hashConstructorCounts.put(signature, vecCounts.elementAt(vecCounts.size()-1));

          vecCounts.removeElementAt(vecCounts.size()-1);
        }

        vecExecutingConstructors.removeElementAt(vecExecutingConstructors.size()-1);
      }
    }
    else {
      strNextLine=strNextLine.substring(intIndex+1);
      intIndexPosition+=(intIndex+1);

      int intParenthesisCount=1;
      while(true) {
        ++intIndexPosition;

        if(strNextLine.charAt(0)=='(')
          intParenthesisCount++;
        else if(strNextLine.charAt(0)==')') {
          intParenthesisCount--;
          if(intParenthesisCount==0)
            break;
        }

        strNextLine=strNextLine.substring(1);
      }
    }

    return intIndexPosition;
*/

  }

  public static Vector parseOperands(String strNextLine) throws Exception {
    if(strNextLine.endsWith(";"))
      strNextLine=strNextLine.substring(0, strNextLine.length()-1);

    strNextLine=trimString(strNextLine);

    if(strNextLine.length()==0)
      return new Vector();


    String strInstanceOf="instanceof";

    int intIndexZ0=-1;
    int intIndexZ1=-1;
    while(true) {
      intIndexZ1=strNextLine.indexOf(" ", intIndexZ0);

      if(intIndexZ1==-1)
        break;

      if(intIndexZ1>=3) {
        if(!strNextLine.substring(intIndexZ1-3, intIndexZ1).equals("new")) {
          if(strNextLine.length()>(intIndexZ1+strInstanceOf.length())) {
            if((intIndexZ1-strInstanceOf.length())>=0) {
              if(!strNextLine.substring(intIndexZ1+1, intIndexZ1+1+strInstanceOf.length()).equals("instanceof") && !strNextLine.substring(intIndexZ1-strInstanceOf.length(), intIndexZ1).equals("instanceof")) {
                strNextLine=strNextLine.substring(0, intIndexZ1)+strNextLine.substring(intIndexZ1+1);
              }
              else
                intIndexZ0=intIndexZ1+1;
            }
            else {
              if(!strNextLine.substring(intIndexZ1+1, intIndexZ1+1+strInstanceOf.length()).equals("instanceof")) {
                strNextLine=strNextLine.substring(0, intIndexZ1)+strNextLine.substring(intIndexZ1+1);
              }
              else
                intIndexZ0=intIndexZ1+1;
            }
          }
          else {
            if((intIndexZ1-strInstanceOf.length())>=0) {
              if(!strNextLine.substring(intIndexZ1-strInstanceOf.length(), intIndexZ1).equals("instanceof")) {
                strNextLine=strNextLine.substring(0, intIndexZ1)+strNextLine.substring(intIndexZ1+1);
              }
              else
                intIndexZ0=intIndexZ1+1;
            }
            else {
              strNextLine=strNextLine.substring(0, intIndexZ1)+strNextLine.substring(intIndexZ1+1);
            }
          }
        }
        else
          intIndexZ0=intIndexZ1+1;
      }
      else {
        if(strNextLine.length()>(intIndexZ1+strInstanceOf.length())) {
          if(!strNextLine.substring(intIndexZ1+1, intIndexZ1+1+strInstanceOf.length()).equals("instanceof")) {
            strNextLine=strNextLine.substring(0, intIndexZ1)+strNextLine.substring(intIndexZ1+1);
          }
          else
            intIndexZ0=intIndexZ1+1;
        }
        else
          strNextLine=strNextLine.substring(0, intIndexZ1)+strNextLine.substring(intIndexZ1+1);
      }
    }


//    String strOperators[]={"<=", ">=", "==", "!=", "<", ">", " instanceof ", "||", "|", "&&", "&"};

    intIndexZ0=-1;
    intIndexZ1=-1;
    int intIndexZ2=-1;

    while(true) {
      intIndexZ1=strNextLine.indexOf('=', intIndexZ0);

      if(intIndexZ1==-1)
        break;

      char chrBefore=strNextLine.charAt(intIndexZ1-1);
      if(chrBefore=='<') {
        intIndexZ0=intIndexZ1+1;
        continue;
      }
      else if(chrBefore=='>') {
        intIndexZ0=intIndexZ1+1;
        continue;
      }
      else if(chrBefore=='!') {
        intIndexZ0=intIndexZ1+1;
        continue;
      }

      char chrAfter=strNextLine.charAt(intIndexZ1+1);
      if(chrAfter=='=') {
        intIndexZ0=intIndexZ1+2;
        continue;
      }

      intIndexZ2=intIndexZ1-1;

      while(true) {
        char chr=strNextLine.charAt(intIndexZ2);

        if(chr=='(') {
          break;
        }
 
        --intIndexZ2;
      }

      ++intIndexZ2;

      strNextLine=strNextLine.substring(0, intIndexZ2)+strNextLine.substring(intIndexZ1+1);

      intIndexZ0=intIndexZ2;
    }

/*
    int intIndexZ0=-1;
    int intIndexZ1=-1;
    while(true) {
      intIndexZ1=strNextLine.indexOf(" ", intIndexZ0);

      if(intIndexZ1==-1)
        break;

      if(intIndexZ1>=3) {
        if(!strNextLine.substring(intIndexZ1-3, intIndexZ1).equals("new"))
          strNextLine=strNextLine.substring(0, intIndexZ1)+strNextLine.substring(intIndexZ1+1);
        else
          intIndexZ0=intIndexZ1+1;
      }
      else
        strNextLine=strNextLine.substring(0, intIndexZ1)+strNextLine.substring(intIndexZ1+1);
    }
*/

if(blnDoShowOutput)
System.out.println("parseOperands:"+strNextLine);

    if(strNextLine.startsWith("!"))
      strNextLine=strNextLine.substring(1);

    Vector vecOperands=parseOperandsParenthesis(strNextLine);

    return vecOperands;
  }

  public static Vector parseOperandsParenthesis(String strNextParenthesis) throws Exception {
    Vector vecOperands=new Vector();

    int intIndex=0;

    int intLastFind=-1;

    int intIndexSkip=-1;

    while(true) {
      StringContainer strContainer=new StringContainer();
      int intRet[]=intOperatorNext(strNextParenthesis, intIndex, strContainer);
//System.out.println("parseOperands");
//System.out.println(intRet[0]);
//System.out.println(strContainer.getStr());

      if(intRet[0]==-1) {
//System.out.println("after:1:a");
        break;
      }
      else {
//System.out.println("after:1:b");
        intLastFind=intRet[0];

        int intIndex0=intRet[0]-1;

        char chr=strNextParenthesis.charAt(intIndex0);

        if(chr==')') {
          int intIsFunctionOrNew=isParseOperandsParenthesisFunctionOrNew(strNextParenthesis, intIndex0);
          if(intIsFunctionOrNew==-1) {
//System.out.println("vecOperands:0: "+strNextParenthesis);
            int intParenthesisCount=1;

            int intIndex1=intIndex0-1;

            while(true) {
              char chr2=strNextParenthesis.charAt(intIndex1);

              if(chr2=='(') {
                --intParenthesisCount;

                if(intParenthesisCount==0)
                  break;
              }
              else if(chr2==')') {
                ++intParenthesisCount;
              }

              --intIndex1;
            }

//System.out.println("before:"+strNextParenthesis.substring(intIndex1+1, intIndex0));
            Vector vecOperands0=parseOperandsParenthesis(strNextParenthesis.substring(intIndex1+1, intIndex0));
            for(int i=0;i<vecOperands0.size();i++)
              vecOperands.addElement(vecOperands0.elementAt(i));
          }
          else {
//System.out.println("vecOperands:1: "+strNextParenthesis.substring(intIsFunctionOrNew, intRet[0]));
            vecOperands.addElement(strNextParenthesis.substring(intIsFunctionOrNew, intRet[0]));
          }
        }
        else {
          int intRet2[]=intOperatorPrevious(strNextParenthesis, intIndex0);

          if(intRet2[0]==-1) {
            vecOperands.addElement(strNextParenthesis.substring(0, intRet[0]));
          }
          else {
            if(intIndexSkip!=(intRet2[0]+intRet2[1]))
              vecOperands.addElement(strNextParenthesis.substring(intRet2[0]+intRet2[1], intRet[0]));
          }
        }

        String strStr=strContainer.getStr();

        if(strStr.equals(" instanceof ")) {
          intIndexSkip=intRet[0]+intRet[1];
        }

        intIndex=intRet[0]+intRet[1];
      }
    }

    if(intLastFind==-1) {
      if(strNextParenthesis.startsWith("-")) {
        if(strNextParenthesis.charAt(1)=='(') {
          strNextParenthesis=strNextParenthesis.substring(1);

          int intParenthesisCount=1;

          int intIndex5=1;

          while(true) {
            char chr=strNextParenthesis.charAt(intIndex5);

            if(chr=='(') {
              ++intParenthesisCount;
            }
            else if(chr==')') {
              --intParenthesisCount;

              if(intParenthesisCount==0)
                break;
            }

            ++intIndex5;
          }

          ++intIndex5;

          if(intIndex5==strNextParenthesis.length())
            vecOperands=parseOperandsParenthesis(strNextParenthesis.substring(1, strNextParenthesis.length()-1));
          else
            vecOperands.addElement(strNextParenthesis);
        }
        else {
          vecOperands.addElement(strNextParenthesis);
        }
      }
      else {
        if(strNextParenthesis.startsWith("(")) {
          int intParenthesisCount=1;

          int intIndex5=1;

          while(true) {
            char chr=strNextParenthesis.charAt(intIndex5);

            if(chr=='(') {
              ++intParenthesisCount;
            }
            else if(chr==')') {
              --intParenthesisCount;

              if(intParenthesisCount==0)
                break;
            }

            ++intIndex5;
          }

          ++intIndex5;

          if(intIndex5==strNextParenthesis.length())
            vecOperands=parseOperandsParenthesis(strNextParenthesis.substring(1, strNextParenthesis.length()-1));
          else
            vecOperands.addElement(strNextParenthesis);
        }
        else
          vecOperands.addElement(strNextParenthesis);
      }
    }
    else {
      StringContainer strContainer=new StringContainer();
      int intRet[]=intOperatorNext(strNextParenthesis, intLastFind, strContainer);

//System.out.println("parseOperands: "+intRet[0]+", "+intRet[1]+":"+strContainer.getStr());

      if(strNextParenthesis.charAt(intRet[0]+intRet[1])=='(') {
        int intParenthesisCount=1;

        int intIndex5=intRet[0]+intRet[1]+1;

        while(true) {
          char chr=strNextParenthesis.charAt(intIndex5);

          if(chr=='(') {
            ++intParenthesisCount;
          }
          else if(chr==')') {
            --intParenthesisCount;

            if(intParenthesisCount==0)
              break;
          }

          ++intIndex5;
        }

        ++intIndex5;

        if(intIndex5==strNextParenthesis.length()) {
//System.out.println("after:"+strNextParenthesis.substring(intRet[0]+intRet[1]+1, strNextParenthesis.length()-1));
          Vector vecOperands0=parseOperandsParenthesis(strNextParenthesis.substring(intRet[0]+intRet[1]+1, strNextParenthesis.length()-1));
          for(int i=0;i<vecOperands0.size();i++)
            vecOperands.addElement(vecOperands0.elementAt(i));
        }
        else
          vecOperands.addElement(strNextParenthesis.substring(intRet[0]+intRet[1]));
      }
      else {
        if(!strContainer.getStr().equals(" instanceof "))
          vecOperands.addElement(strNextParenthesis.substring(intRet[0]+intRet[1]));
      }
    }

    return vecOperands;
  }

  public static int[] intOperatorNext(String strNextLine, int intIndex, StringContainer strContainer) throws Exception {
    int intRet[]=new int[2];
    intRet[0]=-1;

    String strOperators[]={"<<", ">>", "<=", ">=", "==", "!=", "<", ">", " instanceof ", "||", "|", "&&", "&", "+", "-", "*", "/", "%"};
//    String strOperators[]={"<=", ">=", "==", "!=", "<", ">", " instanceof ", "||", "|", "&&", "&"};
    int intOperators[]={intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex};

    if(intIndex>=strNextLine.length())
      return intRet;

    if(strNextLine.indexOf("++")!=-1)
      return intRet;
    else if(strNextLine.indexOf("--")!=-1)
      return intRet;

    int intCloseIndex=Integer.MAX_VALUE;
    int intCloseLength=-1;

    int intNegativeMinus=-1;

    for(int i=0;i<strOperators.length;i++) {
      int intNextIndex=-1;

      if(strOperators[i].equals("-")) {
        intNextIndex=intIndex;

        if(intNegativeMinus!=-1)
          intNextIndex=intNegativeMinus+1;

        intNextIndex=strNextLine.indexOf(strOperators[i], intNextIndex);

        if(intNextIndex!=-1) {
          int intParenthesisCount=0;

          for(int ia=0;ia<intNextIndex;ia++) {
            if(strNextLine.charAt(ia)=='(')
              ++intParenthesisCount;
            else if(strNextLine.charAt(ia)==')')
              --intParenthesisCount;
          }

          int intBracketCount=0;

          for(int ia=0;ia<intNextIndex;ia++) {
            if(strNextLine.charAt(ia)=='[')
              ++intBracketCount;
            else if(strNextLine.charAt(ia)==']')
              --intBracketCount;
          }

          if(intParenthesisCount==0 && intBracketCount==0) {
            if(intNextIndex<intCloseIndex) {

              boolean blnNegativeMinus=false;

//              if(strOperators[i].equals("-")) {
              blnNegativeMinus=isNegativeMinus(strNextLine, intNextIndex);

              if(blnNegativeMinus) {
                intNegativeMinus=intNextIndex;
                --i;
                continue;
              }
//              }

              if(!blnNegativeMinus) {
                intCloseIndex=intNextIndex;
                intCloseLength=strOperators[i].length();
                strContainer.setStr(strOperators[i]);
              }
            }
          }
          else {
            intNegativeMinus=intNextIndex;
            --i;
            continue;
          }
        }

      }
      else {
        while(true) {

          intNextIndex=strNextLine.indexOf(strOperators[i], intOperators[i]);

          if(intNextIndex==-1)
            break;
          else {
            intOperators[i]=intNextIndex+1;

            int intParenthesisCount=0;

            for(int ia=0;ia<intNextIndex;ia++) {
              if(strNextLine.charAt(ia)=='(')
                ++intParenthesisCount;
              else if(strNextLine.charAt(ia)==')')
                --intParenthesisCount;
            }

            int intBracketCount=0;

            for(int ia=0;ia<intNextIndex;ia++) {
              if(strNextLine.charAt(ia)=='[')
                ++intBracketCount;
              else if(strNextLine.charAt(ia)==']')
                --intBracketCount;
            }

            if(intParenthesisCount==0 && intBracketCount==0) {
              if(intNextIndex<intCloseIndex) {
                intCloseIndex=intNextIndex;
                intCloseLength=strOperators[i].length();
                strContainer.setStr(strOperators[i]);

                break;

/*
                boolean blnNegativeMinus=false;

                if(strOperators[i].equals("-")) {
                  blnNegativeMinus=isNegativeMinus(strNextLine, intNextIndex);

                  if(blnNegativeMinus) {
                    intNegativeMinus=intNextIndex;
                    --i;
                    continue;
                  }
                }

                if(!blnNegativeMinus) {
                  intCloseIndex=intNextIndex;
                  intCloseLength=strOperators[i].length();
                  strContainer.setStr(strOperators[i]);
                }
*/
              }
            }
          }

        }

      }

    }

    if(intCloseIndex!=Integer.MAX_VALUE) {
      intRet[0]=intCloseIndex;
      intRet[1]=intCloseLength;
    }

    return intRet;
  }

  public static int[] intOperatorPrevious(String strNextLine, int intIndex) throws Exception {
    int intRet[]=new int[2];
    intRet[0]=-1;

    String strOperators[]={"<<", ">>", "<=", ">=", "==", "!=", "<", ">", " instanceof ", "||", "|", "&&", "&", "+", "-", "*", "/", "%"};
    int intOperators[]={intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex, intIndex};

    if(intIndex<0)
      return intRet;

    if(strNextLine.indexOf("++")!=-1)
      return intRet;
    else if(strNextLine.indexOf("--")!=-1)
      return intRet;

    int intCloseIndex=Integer.MIN_VALUE;
    int intCloseLength=-1;

    int intNegativeMinus=-1;

    for(int i=0;i<strOperators.length;i++) {
      int intPrevIndex=-1;

      if(strOperators[i].equals("-")) {
        intPrevIndex=intIndex;

        if(intNegativeMinus!=-1)
          intPrevIndex=intNegativeMinus-1;

        intPrevIndex=strNextLine.lastIndexOf(strOperators[i], intPrevIndex);

        if(intPrevIndex!=-1) {
          int intParenthesisCount=0;

          for(int ia=0;ia<intPrevIndex;ia++) {
            if(strNextLine.charAt(ia)=='(')
              ++intParenthesisCount;
            else if(strNextLine.charAt(ia)==')')
              --intParenthesisCount;
          }

          int intBracketCount=0;

          for(int ia=0;ia<intPrevIndex;ia++) {
            if(strNextLine.charAt(ia)=='[')
              ++intBracketCount;
            else if(strNextLine.charAt(ia)==']')
              --intBracketCount;
          }

          if(intParenthesisCount==0 && intBracketCount==0) {
            if(intPrevIndex>intCloseIndex) {
              boolean blnNegativeMinus=false;

//              if(strOperators[i].equals("-")) {
              blnNegativeMinus=isNegativeMinus(strNextLine, intPrevIndex);

              if(blnNegativeMinus) {
                intNegativeMinus=intPrevIndex;
                --i;
                continue;
              }
//              }

              if(!blnNegativeMinus) {
                intCloseIndex=intPrevIndex;
                intCloseLength=strOperators[i].length();
              }
            }
          }
          else {
            intNegativeMinus=intPrevIndex;
            --i;
            continue;
          }
        }

      }
      else {
        while(true) {

          intPrevIndex=strNextLine.lastIndexOf(strOperators[i], intOperators[i]);

//      int intPrevIndex=strNextLine.lastIndexOf(strOperators[i], intIndex);

          if(intPrevIndex==-1)
            break;
          else {
            intOperators[i]=intPrevIndex-1;

            int intParenthesisCount=0;

            for(int ia=0;ia<intPrevIndex;ia++) {
              if(strNextLine.charAt(ia)=='(')
                ++intParenthesisCount;
              else if(strNextLine.charAt(ia)==')')
                --intParenthesisCount;
            }

            int intBracketCount=0;

            for(int ia=0;ia<intPrevIndex;ia++) {
              if(strNextLine.charAt(ia)=='[')
                ++intBracketCount;
              else if(strNextLine.charAt(ia)==']')
                --intBracketCount;
            }

            if(intParenthesisCount==0 && intBracketCount==0) {
              if(intPrevIndex>intCloseIndex) {
                intCloseIndex=intPrevIndex;
                intCloseLength=strOperators[i].length();

                break;
              }
            }
          }

        }

      }

    }

    if(intCloseIndex!=Integer.MIN_VALUE) {
      intRet[0]=intCloseIndex;
      intRet[1]=intCloseLength;
    }

    return intRet;
  }

  public static boolean isNegativeMinus(String strNextLine, int intIndex) {
    String strOperators[]={"<<", ">>", "<=", ">=", "==", "!=", "<", ">", " instanceof ", "||", "|", "&&", "&", "+", "*", "/", "%"};
//    String strOperators[]={"<<", ">>", "<=", ">=", "==", "!=", "<", ">", " instanceof ", "||", "|", "&&", "&", "+", "-", "*", "/", "%"};

    if(intIndex==0)
      return true;

    if(strNextLine.charAt(intIndex-1)=='(')
      return true;

    int intPreviousOperatorIndex=-1;
    int intPreviousOperatorLength=-1;

    for(int i=0;i<strOperators.length;i++) {
      int intNextIndex=strNextLine.lastIndexOf(strOperators[i], intIndex);

      if(intNextIndex==-1)
        continue;

      if(intNextIndex>intPreviousOperatorIndex) {
        intPreviousOperatorIndex=intNextIndex;
        intPreviousOperatorLength=strOperators[i].length();
      }
    }

    if((intPreviousOperatorIndex+intPreviousOperatorLength)==intIndex)
      return true;

    return false;    
  }

  public static int isParseOperandsParenthesisFunctionOrNew(String strNextParenthesis, int intClosingParenthesisIndex) throws Exception {
    int intParenthesisCount=1;

    int intIndex=intClosingParenthesisIndex-1;

    while(true) {
      char chr=strNextParenthesis.charAt(intIndex);

      if(chr=='(') {
        --intParenthesisCount;

        if(intParenthesisCount==0)
          break;
      }
      else if(chr==')') {
        ++intParenthesisCount;
      }

      --intIndex;
    }

    if((intIndex-1)<0)
      return -1;

    if(Character.isLetter(strNextParenthesis.charAt(intIndex-1)) || Character.isDigit(strNextParenthesis.charAt(intIndex-1))) {
      intIndex-=2;

      while(true) {
        if(intIndex<0)
          break;

        char chr=strNextParenthesis.charAt(intIndex);

        if(Character.isLetter(chr) || Character.isDigit(chr) || chr==' ' || chr=='.' || chr=='[' || chr==']') {
          --intIndex;
          continue;
        }
        else if(chr==')') {
          intParenthesisCount=1;

          --intIndex;

          while(true) {
            char chr2=strNextParenthesis.charAt(intIndex);

            if(chr2=='(') {
              --intParenthesisCount;

              if(intParenthesisCount==0)
                break;
            }
            else if(chr2==')') {
              ++intParenthesisCount;
            }

            --intIndex;
          }

          --intIndex;
          continue;
        }

        break;
      }

      ++intIndex;

      return intIndex;
    }

    return -1;
  }

  public static String trimString(String strStr) throws Exception {
    while(true) {
      if(strStr.length()==0)
        break;

      if(strStr.charAt(0)==' ') {
        strStr=strStr.substring(1);
        continue;
      }

      break;
    }

    int i=strStr.length()-1;
    for(;i>=0;i--) {
      if(strStr.charAt(i)!=' ')
        break;
    }

    if(i==-1)
      return "";

    ++i;

    strStr=strStr.substring(0, i);

    return strStr;
  }

  public static String executeOperand(String strNextLine, ClassObject classObj, int intAbsoluteLineNumber, Vector vecLocalFields) throws Exception {
if(blnDoShowOutput)
System.out.println("executeOperand:"+strNextLine);

    String strClassNameReturn="";

    if(strNextLine.startsWith("((")) {
      int intParenthesisCount=1;

      int intIndex=2;

      while(true) {
        char chr=strNextLine.charAt(intIndex);

        if(chr=='(') {
          ++intParenthesisCount;
        }
        else if(chr==')') {
          --intParenthesisCount;

          if(intParenthesisCount==0)
            break;
        }

        ++intIndex;
      }

      String strClassCastCheck=strNextLine.substring(2, intIndex);

      Hashtable hashEnums=classObj.getEnums();
      if(hashEnums.containsKey(strClassCastCheck)) {
        throw new Exception("Attempted class cast to enum \""+strClassCastCheck+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
      }

      strClassNameReturn=executeCommand(classObj, intAbsoluteLineNumber, strNextLine, vecLocalFields);

      return strClassNameReturn;

/*
      if(hashImported.containsKey(strClassCastCheck)) {
        strClassNameReturn=executeCommand(classObj, intAbsoluteLineNumber, strNextLine, vecLocalFields);

        return strClassNameReturn;
      }
*/
    }
    else if(strNextLine.startsWith("(")) {
      int intParenthesisCount=1;

      int intIndex=1;

      while(true) {
        char chr=strNextLine.charAt(intIndex);

        if(chr=='(') {
          ++intParenthesisCount;
        }
        else if(chr==')') {
          --intParenthesisCount;

          if(intParenthesisCount==0)
            break;
        }

        ++intIndex;
      }

      String strClassCastCheck=strNextLine.substring(1, intIndex);

      Hashtable hashEnums=classObj.getEnums();
      if(hashEnums.containsKey(strClassCastCheck)) {
        throw new Exception("Attempted class cast to enum \""+strClassCastCheck+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
      }

      strClassNameReturn=executeCommand(classObj, intAbsoluteLineNumber, strNextLine, vecLocalFields);

      return strClassNameReturn;
    }

    if(strNextLine.equals("\"\""))
      return "java.lang.String";
    else if(strNextLine.equals("'a'"))
      return "char";
    else if(strNextLine.equals("true"))
      return "boolean";
    else if(strNextLine.equals("false"))
      return "boolean";

    if(strNextLine.startsWith("++") || strNextLine.startsWith("--")) {
      String strCommand=strNextLine.substring(2);
      strClassNameReturn=executeCommand(classObj, intAbsoluteLineNumber, strCommand, vecLocalFields);

      return strClassNameReturn;

/*
      String strFieldName=strNextLine.substring(2);

      for(int i=vecLocalFields.size()-1;i>=0;i--) {
        Vector vecCurrentBraces=(Vector)vecLocalFields.elementAt(i);

        for(int ia=0;ia<vecCurrentBraces.size();ia++) {
          FieldObject nextField=(FieldObject)vecCurrentBraces.elementAt(ia);

          if(nextField.getFieldName().equals(strFieldName))
            return nextField.getClassName();
        }
      }

      Hashtable hashInstanceFields=classObj.getInstanceFields();
      FieldObject nextField=(FieldObject)hashInstanceFields.get(strFieldName);
      if(nextField!=null) {
        return nextField.getClassName();
      }
      else {
        Hashtable hashStaticFields=classObj.getStaticFields();
        nextField=(FieldObject)hashStaticFields.get(strFieldName);
        if(nextField!=null) {
          return nextField.getClassName();
        }
        else {
          int intPeriodIndex=strFieldName.indexOf('.');

          if(intPeriodIndex==-1) {
            throw new Exception("Encountered unknown field increment \""+strFieldName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
          }
          else {
            int intPeriodIndex2=strFieldName.indexOf('.', intPeriodIndex+1);

            if(intPeriodIndex2==-1) {
              String strClassName=strFieldName.substring(0, intPeriodIndex);

              strFieldName=strFieldName.substring(intPeriodIndex+1);

              strClassName=(String)hashImported.get(strClassName);

              ClassObject classObj2=(ClassObject)hashClasses.get(strClassName);

              if(classObj2!=null) {
                hashStaticFields=classObj2.getStaticFields();

                nextField=(FieldObject)hashStaticFields.get(strFieldName);

                if(nextField!=null)
                  return nextField.getClassName();
                else
                  throw new Exception("Encountered unknown field increment \""+strFieldName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
              }
            }
            else {
              String strOuterClassName=strFieldName.substring(0, intPeriodIndex);
              String strInnerClassName=strFieldName.substring(intPeriodIndex+1, intPeriodIndex2);
              strFieldName=strFieldName.substring(intPeriodIndex2+1);

              String strClassName=(String)hashImported.get(strOuterClassName);
              strClassName+="$"+strInnerClassName;

              ClassObject classObj2=(ClassObject)hashClasses.get(strClassName);

              if(classObj2!=null) {
                hashStaticFields=classObj2.getStaticFields();

                nextField=(FieldObject)hashStaticFields.get(strFieldName);

                if(nextField!=null)
                  return nextField.getClassName();
                else
                  throw new Exception("Encountered unknown field increment \""+strFieldName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
              }

            }
          }
        }
      }
*/

    }

    if(strNextLine.endsWith("++") || strNextLine.endsWith("--")) {
      String strCommand=strNextLine.substring(0, strNextLine.length()-2);
      strClassNameReturn=executeCommand(classObj, intAbsoluteLineNumber, strCommand, vecLocalFields);

      return strClassNameReturn;

/*
      String strFieldName=strNextLine.substring(0, strNextLine.length()-2);

      for(int i=vecLocalFields.size()-1;i>=0;i--) {
        Vector vecCurrentBraces=(Vector)vecLocalFields.elementAt(i);

        for(int ia=0;ia<vecCurrentBraces.size();ia++) {
          FieldObject nextField=(FieldObject)vecCurrentBraces.elementAt(ia);

          if(nextField.getFieldName().equals(strFieldName))
            return nextField.getClassName();
        }
      }

      Hashtable hashInstanceFields=classObj.getInstanceFields();
      FieldObject nextField=(FieldObject)hashInstanceFields.get(strFieldName);
      if(nextField!=null) {
        return nextField.getClassName();
      }
      else {
        Hashtable hashStaticFields=classObj.getStaticFields();
        nextField=(FieldObject)hashStaticFields.get(strFieldName);
        if(nextField!=null) {
          return nextField.getClassName();
        }
        else {
          int intPeriodIndex=strFieldName.indexOf('.');

          if(intPeriodIndex==-1) {
            throw new Exception("Encountered unknown field increment \""+strFieldName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
          }
          else {
            int intPeriodIndex2=strFieldName.indexOf('.', intPeriodIndex+1);

            if(intPeriodIndex2==-1) {
              String strClassName=strFieldName.substring(0, intPeriodIndex);

              strFieldName=strFieldName.substring(intPeriodIndex+1);

              strClassName=(String)hashImported.get(strClassName);

              ClassObject classObj2=(ClassObject)hashClasses.get(strClassName);

              if(classObj2!=null) {
                hashStaticFields=classObj2.getStaticFields();

                nextField=(FieldObject)hashStaticFields.get(strFieldName);

                if(nextField!=null)
                  return nextField.getClassName();
                else
                  throw new Exception("Encountered unknown field increment \""+strFieldName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
              }
            }
            else {
              String strOuterClassName=strFieldName.substring(0, intPeriodIndex);
              String strInnerClassName=strFieldName.substring(intPeriodIndex+1, intPeriodIndex2);
              strFieldName=strFieldName.substring(intPeriodIndex2+1);

              String strClassName=(String)hashImported.get(strOuterClassName);
              strClassName+="$"+strInnerClassName;

              ClassObject classObj2=(ClassObject)hashClasses.get(strClassName);

              if(classObj2!=null) {
                hashStaticFields=classObj2.getStaticFields();

                nextField=(FieldObject)hashStaticFields.get(strFieldName);

                if(nextField!=null)
                  return nextField.getClassName();
                else
                  throw new Exception("Encountered unknown field increment \""+strFieldName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
              }

            }
          }
        }
      }
*/

    }

    int intPreviousIndex=strNextLine.length()-1;

/*
        String strOperators[]={"<=", ">=", "==", "!=", "<", ">", "instanceof"};

        while(true) {

          int intLeastIndex=Integer.MAX_VALUE;

          for(int i=0;i<strOperators.length;i++) {
            int intNextIndex=strNextLine.indexOf(strOperators[i]);
            if(intNextIndex!=-1) {
              if(intNextIndex<intLeastIndex) {
                intLeastIndex=intNextIndex;
              }
            }
          }

          if(intLeastIndex==Integer.MAX_VALUE)
            break;

          int intPreviousIndex=intLeastIndex-1;
*/

    while(true) {
      if(strNextLine.charAt(intPreviousIndex)==' ') {
        intPreviousIndex--;
        continue;
      }

      break;
    }


    if(strNextLine.charAt(intPreviousIndex)==')') {
//System.out.println("executeOperand: "+strNextLine);
      strClassNameReturn=executeCommand(classObj, intAbsoluteLineNumber, strNextLine.substring(0, intPreviousIndex+1), vecLocalFields);

      return strClassNameReturn;

/*
      int intPrevious2Index=intPreviousIndex;

      while(true) {
        if(intPrevious2Index==-1)
          break;

        char chr=strNextLine.charAt(intPrevious2Index);

        if(chr==')') {
          int intParenthesisCount=1;

          --intPrevious2Index;

          while(true) {
            if(strNextLine.charAt(intPrevious2Index)=='(') {
              --intParenthesisCount;

              if(intParenthesisCount==0)
                break;
            }
            else if(strNextLine.charAt(intPrevious2Index)==')') {
              ++intParenthesisCount;
            }

            --intPrevious2Index;
          }

          --intPrevious2Index;

          continue;
        }
        else if(Character.isLetter(chr) || Character.isDigit(chr)) {
          --intPrevious2Index;

          continue;
        }
        else if(chr==' ') {
          --intPrevious2Index;

          continue;
        }
        else if(chr=='.') {
          --intPrevious2Index;

          continue;
        }
        else if(chr=='[') {
          --intPrevious2Index;

          continue;
        }
        else if(chr==']') {
          --intPrevious2Index;

          continue;
        }

        break;
      }

//System.out.println("index:"+intPrevious2Index);

      if(intPrevious2Index==-1) {
        String strCommand=strNextLine.substring(0, intPreviousIndex+1);
        while(true) {
          if(strCommand.startsWith("(")) {
            int intParenthesisCount=1;

            int intIndex=1;

            while(true) {
              char chr=strNextLine.charAt(intIndex);

              if(chr=='(') {
                ++intParenthesisCount;
              }
              else if(chr==')') {
                --intParenthesisCount;

                if(intParenthesisCount==0)
                  break;
              }

              ++intIndex;
            }

            ++intIndex;

            if(intIndex==strCommand.length()) {
              strCommand=strCommand.substring(1, strCommand.length()-1);
              continue;
            }
          }

          break;
        }

        strClassNameReturn=executeCommand(classObj, intAbsoluteLineNumber, strCommand, vecLocalFields);

        return strClassNameReturn;
      }
      else {
        char chrPrev=strNextLine.charAt(intPrevious2Index);

        if(Character.isLetter(chrPrev) || Character.isDigit(chrPrev)) {
          --intPrevious2Index;
          while(true) {
            chrPrev=strNextLine.charAt(intPrevious2Index);

            if(intPrevious2Index==-1) {
              ++intPrevious2Index;
              break;
            }

            if(Character.isLetter(chrPrev) || Character.isDigit(chrPrev) || chrPrev=='.') {
              --intPrevious2Index;
              continue;
            }
            else if(chrPrev==' ') {
              ++intPrevious2Index;
              break;
            }
            else if(chrPrev=='(') {
              ++intPrevious2Index;
              break;
            }
            else if(chrPrev==')') {
              --intPrevious2Index;

              int intParenthesisCount=1;

              while(true) {
                chrPrev=strNextLine.charAt(intPrevious2Index);

                if(chrPrev=='(') {
                  --intParenthesisCount;
                  if(intParenthesisCount==0)
                    break;
                }
                else if(chrPrev==')') {
                  ++intParenthesisCount;
                }

                --intPrevious2Index;
              }

              --intPrevious2Index;
            }
          }

          String strCommand=strNextLine.substring(intPrevious2Index, intPreviousIndex+1);

          strClassNameReturn=executeCommand(classObj, intAbsoluteLineNumber, strCommand, vecLocalFields);

          return strClassNameReturn;
        }
        else {
//character at intPrevious2Index is a '(' or a ' ', so increment by 1
          ++intPrevious2Index;

          String strCommand=strNextLine.substring(intPrevious2Index, intPreviousIndex+1);

          while(true) {

            if(strCommand.startsWith("(")) {
              int intParenthesisCount=1;

              int intIndex=1;

              while(true) {
                char chr=strNextLine.charAt(intIndex);

                if(chr=='(') {
                  ++intParenthesisCount;
                }
                else if(chr==')') {
                  --intParenthesisCount;

                  if(intParenthesisCount==0)
                    break;
                }

                ++intIndex;
              }

              ++intIndex;

              if(intIndex==strCommand.length()) {
                strCommand=strCommand.substring(1, strCommand.length()-1);
                continue;
              }
            }

            break;
          }

          strClassNameReturn=executeCommand(classObj, intAbsoluteLineNumber, strCommand, vecLocalFields);

          return strClassNameReturn;
        }

      }
*/
    }
    else if(strNextLine.charAt(intPreviousIndex)==']') {
      strClassNameReturn=executeCommand(classObj, intAbsoluteLineNumber, strNextLine.substring(0, intPreviousIndex+1), vecLocalFields);

      return strClassNameReturn;
    }
    else if(strNextLine.charAt(intPreviousIndex)=='l') {
      int intPrevious2Index=intPreviousIndex-1;

      boolean blnIsField=false;

      if(!Character.isDigit(strNextLine.charAt(0)))
        blnIsField=true;

/*
      while(true) {
        if(intPrevious2Index==-1) {
//                ++intPrevious2Index;
          break;
        }

        if(Character.isDigit(strNextLine.charAt(intPrevious2Index))) {
          --intPrevious2Index;
          continue;
        }
        else if(Character.isLetter(strNextLine.charAt(intPrevious2Index))) {
          --intPrevious2Index;
          blnIsField=true;
          break;
        }
        else if(strNextLine.charAt(intPrevious2Index)=='.') {
          --intPrevious2Index;
          blnIsField=true;
          break;
        }

        break;
      }
*/

      if(blnIsField) {
        String strCommand=strNextLine.substring(0, intPreviousIndex+1);

        strClassNameReturn=executeCommand(classObj, intAbsoluteLineNumber, strCommand, vecLocalFields);

        return strClassNameReturn;

/*
        while(true) {
          if(intPrevious2Index==-1) {
            ++intPrevious2Index;
            break;
          }

          if(Character.isDigit(strNextLine.charAt(intPrevious2Index)) || Character.isLetter(strNextLine.charAt(intPrevious2Index))) {
            --intPrevious2Index;
            continue;
          }
          else if(strNextLine.charAt(intPrevious2Index)=='.') {
            --intPrevious2Index;
            continue;
          }
          else if(strNextLine.charAt(intPrevious2Index)==')') {
            --intPrevious2Index;

            int intParenthesisCount=1;

            while(true) {
              if(strNextLine.charAt(intPrevious2Index)=='(') {
                --intParenthesisCount;
                if(intParenthesisCount==0)
                  break;
              }
              else if(strNextLine.charAt(intPrevious2Index)==')') {
                ++intParenthesisCount;
              }

              --intPrevious2Index;
            }

            --intPrevious2Index;

            continue;
          }

          ++intPrevious2Index;

          break;
        }

        String strCommand=strNextLine.substring(intPrevious2Index, intPreviousIndex+1);

        strClassNameReturn=executeCommand(classObj, intAbsoluteLineNumber, strCommand, vecLocalFields);

        return strClassNameReturn;
*/

      }
      else
        return "long";
    }
    else if(strNextLine.charAt(intPreviousIndex)=='f') {
      int intPrevious2Index=intPreviousIndex-1;

      boolean blnIsField=false;

      if(!Character.isDigit(strNextLine.charAt(0)))
        blnIsField=true;

/*
      while(true) {
        if(intPrevious2Index==-1) {
//                ++intPrevious2Index;
          break;
        }

        if(Character.isDigit(strNextLine.charAt(intPrevious2Index))) {
          --intPrevious2Index;
          continue;
        }
        else if(Character.isLetter(strNextLine.charAt(intPrevious2Index))) {
          --intPrevious2Index;
          blnIsField=true;
          break;
        }
        else if(strNextLine.charAt(intPrevious2Index)=='.') {
//                --intPrevious2Index;
          break;
        }

        break;
      }
*/

      if(blnIsField) {
        String strCommand=strNextLine.substring(0, intPreviousIndex+1);

        strClassNameReturn=executeCommand(classObj, intAbsoluteLineNumber, strCommand, vecLocalFields);

        return strClassNameReturn;

/*
        while(true) {
          if(intPrevious2Index==-1) {
            ++intPrevious2Index;
            break;
          }

          if(Character.isDigit(strNextLine.charAt(intPrevious2Index)) || Character.isLetter(strNextLine.charAt(intPrevious2Index))) {
            --intPrevious2Index;
            continue;
          }
          else if(strNextLine.charAt(intPrevious2Index)=='.') {
            --intPrevious2Index;
            continue;
          }
          else if(strNextLine.charAt(intPrevious2Index)==')') {
            --intPrevious2Index;

            int intParenthesisCount=1;

            while(true) {
              if(strNextLine.charAt(intPrevious2Index)=='(') {
                --intParenthesisCount;
                if(intParenthesisCount==0)
                  break;
              }
              else if(strNextLine.charAt(intPrevious2Index)==')') {
                ++intParenthesisCount;
              }

              --intPrevious2Index;
            }

            --intPrevious2Index;

            continue;
          }

          ++intPrevious2Index;

          break;
        }

        String strCommand=strNextLine.substring(intPrevious2Index, intPreviousIndex+1);

        strClassNameReturn=executeCommand(classObj, intAbsoluteLineNumber, strCommand, vecLocalFields);

        return strClassNameReturn;
*/

      }
      else
        return "float";
    }
    else if(strNextLine.charAt(intPreviousIndex)=='d') {
      int intPrevious2Index=intPreviousIndex-1;

      boolean blnIsField=false;

      if(!Character.isDigit(strNextLine.charAt(0)))
        blnIsField=true;

/*
      while(true) {
        if(intPrevious2Index==-1) {
//                ++intPrevious2Index;
          break;
        }

        if(Character.isDigit(strNextLine.charAt(intPrevious2Index))) {
          --intPrevious2Index;
          continue;
        }
        else if(Character.isLetter(strNextLine.charAt(intPrevious2Index))) {
          --intPrevious2Index;
          blnIsField=true;
          break;
        }
        else if(strNextLine.charAt(intPrevious2Index)=='.') {
//                --intPrevious2Index;
          break;
        }

        break;
      }
*/

      if(blnIsField) {
        String strCommand=strNextLine.substring(0, intPreviousIndex+1);

        strClassNameReturn=executeCommand(classObj, intAbsoluteLineNumber, strCommand, vecLocalFields);

        return strClassNameReturn;

/*
        while(true) {
          if(intPrevious2Index==-1) {
            ++intPrevious2Index;
            break;
          }

          if(Character.isDigit(strNextLine.charAt(intPrevious2Index)) || Character.isLetter(strNextLine.charAt(intPrevious2Index))) {
            --intPrevious2Index;
            continue;
          }
          else if(strNextLine.charAt(intPrevious2Index)=='.') {
            --intPrevious2Index;
            continue;
          }
          else if(strNextLine.charAt(intPrevious2Index)==')') {
            --intPrevious2Index;

            int intParenthesisCount=1;

            while(true) {
              if(strNextLine.charAt(intPrevious2Index)=='(') {
                --intParenthesisCount;
                if(intParenthesisCount==0)
                  break;
              }
              else if(strNextLine.charAt(intPrevious2Index)==')') {
                ++intParenthesisCount;
              }

              --intPrevious2Index;
            }

            --intPrevious2Index;

            continue;
          }

          ++intPrevious2Index;

          break;
        }

        String strCommand=strNextLine.substring(intPrevious2Index, intPreviousIndex+1);

        strClassNameReturn=executeCommand(classObj, intAbsoluteLineNumber, strCommand, vecLocalFields);

        return strClassNameReturn;
*/

      }
      else
        return "double";
    }
    else if(Character.isDigit(strNextLine.charAt(intPreviousIndex))) {
      int intPrevious2Index=intPreviousIndex-1;

      boolean blnIsField=false;

      if(!Character.isDigit(strNextLine.charAt(0)))
        blnIsField=true;

/*
      while(true) {
        if(intPrevious2Index==-1) {
//                ++intPrevious2Index;
          break;
        }

        if(Character.isDigit(strNextLine.charAt(intPrevious2Index))) {
          --intPrevious2Index;
          continue;
        }
        else if(Character.isLetter(strNextLine.charAt(intPrevious2Index))) {
          --intPrevious2Index;
          blnIsField=true;
          break;
        }
        else if(strNextLine.charAt(intPrevious2Index)=='.') {
          --intPrevious2Index;
          blnIsField=true;
          break;
        }

        break;
      }
*/

      if(blnIsField) {
        String strCommand=strNextLine.substring(0, intPreviousIndex+1);

        strClassNameReturn=executeCommand(classObj, intAbsoluteLineNumber, strCommand, vecLocalFields);

        return strClassNameReturn;

/*
        while(true) {
          if(intPrevious2Index==-1) {
            ++intPrevious2Index;
            break;
          }

          if(Character.isDigit(strNextLine.charAt(intPrevious2Index)) || Character.isLetter(strNextLine.charAt(intPrevious2Index))) {
            --intPrevious2Index;
            continue;
          }
          else if(strNextLine.charAt(intPrevious2Index)=='.') {
            --intPrevious2Index;
            continue;
          }
          else if(strNextLine.charAt(intPrevious2Index)==')') {
            --intPrevious2Index;

            int intParenthesisCount=1;

            while(true) {
              if(strNextLine.charAt(intPrevious2Index)=='(') {
                --intParenthesisCount;
                if(intParenthesisCount==0)
                  break;
              }
              else if(strNextLine.charAt(intPrevious2Index)==')') {
                ++intParenthesisCount;
              }

              --intPrevious2Index;
            }

            --intPrevious2Index;

            continue;
          }

          ++intPrevious2Index;

          break;
        }

        String strCommand=strNextLine.substring(intPrevious2Index, intPreviousIndex+1);

        executeCommand(classObj, intAbsoluteLineNumber, strCommand, vecLocalFields);
*/

      }
      else {
        String strCommand=strNextLine.substring(0, intPreviousIndex+1);

        if(strCommand.indexOf('.')==-1)
          return "int";
        else
          return "double";
      }
    }
    else {
      String strCommand=strNextLine.substring(0, intPreviousIndex+1);

      strClassNameReturn=executeCommand(classObj, intAbsoluteLineNumber, strCommand, vecLocalFields);

/*
      int intPrevious2Index=intPreviousIndex-1;

      while(true) {
        if(intPrevious2Index==-1) {
          ++intPrevious2Index;
          break;
        }

        if(Character.isDigit(strNextLine.charAt(intPrevious2Index)) || Character.isLetter(strNextLine.charAt(intPrevious2Index))) {
          --intPrevious2Index;
          continue;
        }
        else if(strNextLine.charAt(intPrevious2Index)=='.') {
          --intPrevious2Index;
          continue;
        }
        else if(strNextLine.charAt(intPrevious2Index)==')') {
          --intPrevious2Index;

          int intParenthesisCount=1;

          while(true) {
            if(strNextLine.charAt(intPrevious2Index)=='(') {
              --intParenthesisCount;
              if(intParenthesisCount==0)
                break;
            }
            else if(strNextLine.charAt(intPrevious2Index)==')') {
              ++intParenthesisCount;
            }

            --intPrevious2Index;
          }

          --intPrevious2Index;

          continue;
        }

        ++intPrevious2Index;

        break;
      }

      String strCommand=strNextLine.substring(intPrevious2Index, intPreviousIndex+1);

      strClassNameReturn=executeCommand(classObj, intAbsoluteLineNumber, strCommand, vecLocalFields);
*/
    }

    return strClassNameReturn;
  }

  public static int parseParameters(String strNextLine, Vector vecParameters, ClassObject classObj, Vector vecLocalFields, int intAbsoluteLineNumber) throws Exception {
if(blnDoShowOutput)
System.out.println("parseParameters: "+strNextLine);

    int intRet=-1;

    int intIndex=0;
    int intIndex2=0;

    while(true) {
      char chr=strNextLine.charAt(intIndex2);

      if(chr=='(') {
        int intParenthesisCount=1;

        ++intIndex2;

        while(true) {
          char chr2=strNextLine.charAt(intIndex2);

          if(chr2=='(') {
            ++intParenthesisCount;
          }
          else if(chr2==')') {
            --intParenthesisCount;

            if(intParenthesisCount==0)
              break;
          }

          ++intIndex2;
        }

//        ++intIndex2;
      }
      else if(chr==')') {
        String strOperands=strNextLine.substring(intIndex, intIndex2);
//System.out.println("strOperands: "+strOperands);

        Vector vecOperands=parseOperands(strOperands);
//System.out.println("vecOperands: "+vecOperands.size());

        Vector vecOperandsClasses=new Vector();

        for(int i=0;i<vecOperands.size();i++) {
          String strNextOperand=(String)vecOperands.elementAt(i);
//System.out.println("strNextOperand: "+strNextOperand);
          String strClassOperand=executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
//System.out.println("strClassOperand: "+strClassOperand);
          vecOperandsClasses.addElement(strClassOperand);
        }

        if(vecOperandsClasses.size()==1)
          vecParameters.addElement(new FieldObject((String)vecOperandsClasses.elementAt(0)));
        else {
          boolean blnIsString=false;
          for(int i=0;i<vecOperandsClasses.size();i++) {
            String strNextClass=(String)vecOperandsClasses.elementAt(i);
            if(strNextClass.equals("java.lang.String")) {
              vecParameters.addElement(new FieldObject("java.lang.String"));
              blnIsString=true;

              break;
            }
          }

          if(!blnIsString && vecOperandsClasses.size()>1) {
            int intByte=0;
            int intShort=1;
            int intInt=2;
            int intLong=3;
            int intFloat=4;
            int intDouble=5;

            int intHighest=intByte;

            for(int i=0;i<vecOperandsClasses.size();i++) {
              String strNextClass=(String)vecOperandsClasses.elementAt(i);
              if(strNextClass.equals("byte")) {
              }
              else if(strNextClass.equals("short")) {
                if(intHighest<intShort)
                  intHighest=intShort;
              }
              else if(strNextClass.equals("int")) {
                if(intHighest<intInt)
                  intHighest=intInt;
              }
              else if(strNextClass.equals("long")) {
                if(intHighest<intLong)
                  intHighest=intLong;
              }
              else if(strNextClass.equals("float")) {
                if(intHighest<intFloat)
                  intHighest=intFloat;
              }
              else if(strNextClass.equals("double")) {
                if(intHighest<intDouble)
                  intHighest=intDouble;

                break;
              }
            }

            if(intHighest==intByte)
              vecParameters.addElement(new FieldObject("byte"));
            else if(intHighest==intShort)
              vecParameters.addElement(new FieldObject("short"));
            else if(intHighest==intInt)
              vecParameters.addElement(new FieldObject("int"));
            else if(intHighest==intLong)
              vecParameters.addElement(new FieldObject("long"));
            else if(intHighest==intFloat)
              vecParameters.addElement(new FieldObject("float"));
            else if(intHighest==intDouble)
              vecParameters.addElement(new FieldObject("double"));
          }
        }

//        intRet=intIndex2-1;

        intRet=intIndex2+1;

        break;
      }
      else if(chr==',') {
        String strOperands=strNextLine.substring(intIndex, intIndex2);

        Vector vecOperands=parseOperands(strOperands);

        Vector vecOperandsClasses=new Vector();

        for(int i=0;i<vecOperands.size();i++) {
          String strNextOperand=(String)vecOperands.elementAt(i);
          vecOperandsClasses.addElement(executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields));
        }

        if(vecOperandsClasses.size()==1)
          vecParameters.addElement(new FieldObject((String)vecOperandsClasses.elementAt(0)));
        else {
          boolean blnIsString=false;
          for(int i=0;i<vecOperandsClasses.size();i++) {
            String strNextClass=(String)vecOperandsClasses.elementAt(i);
            if(strNextClass.equals("java.lang.String")) {
              vecParameters.addElement(new FieldObject("java.lang.String"));
              blnIsString=true;

              break;
            }
          }

          if(!blnIsString && vecOperandsClasses.size()>1) {
            int intByte=0;
            int intShort=1;
            int intInt=2;
            int intLong=3;
            int intFloat=4;
            int intDouble=5;

            int intHighest=intByte;

            for(int i=0;i<vecOperandsClasses.size();i++) {
              String strNextClass=(String)vecOperandsClasses.elementAt(i);
              if(strNextClass.equals("byte")) {
              }
              else if(strNextClass.equals("short")) {
                if(intHighest<intShort)
                  intHighest=intShort;
              }
              else if(strNextClass.equals("int")) {
                if(intHighest<intInt)
                  intHighest=intInt;
              }
              else if(strNextClass.equals("long")) {
                if(intHighest<intLong)
                  intHighest=intLong;
              }
              else if(strNextClass.equals("float")) {
                if(intHighest<intFloat)
                  intHighest=intFloat;
              }
              else if(strNextClass.equals("double")) {
                if(intHighest<intDouble)
                  intHighest=intDouble;

                break;
              }
            }

            if(intHighest==intByte)
              vecParameters.addElement(new FieldObject("byte"));
            else if(intHighest==intShort)
              vecParameters.addElement(new FieldObject("short"));
            else if(intHighest==intInt)
              vecParameters.addElement(new FieldObject("int"));
            else if(intHighest==intLong)
              vecParameters.addElement(new FieldObject("long"));
            else if(intHighest==intFloat)
              vecParameters.addElement(new FieldObject("float"));
            else if(intHighest==intDouble)
              vecParameters.addElement(new FieldObject("double"));
          }
        }

        intIndex=intIndex2+1;

        while(true) {
          char chr2=strNextLine.charAt(intIndex);

          if(chr2!=' ')
            break;

          ++intIndex;
        }

        intIndex2=intIndex;

        continue;
      }

      ++intIndex2;
    }

//System.out.println("parseParameters2: "+new FunctionSignature("","",vecParameters).toString());

    return intRet;
  }

  public static int isPeriodParenthesisEndLeast(String strCommand) {
//System.out.println("isPeriodParenthesisEndLeast: "+strCommand);
    int intIndex=0;

    int intBracketCountZ=0;

    while(true) {
      if(intIndex>=strCommand.length())
        break;

      char chr=strCommand.charAt(intIndex);

      if(chr=='.') {
        if(intBracketCountZ==0) {
          break;
        }
      }
      else if(chr=='[') {
        ++intBracketCountZ;
      }
      else if(chr==']') {
        --intBracketCountZ;
      }
      else if(chr=='(') {
        if(intBracketCountZ==0) {
          break;
        }
      }

      ++intIndex;
    }

    return intIndex;

/*
    int intPeriodIndex=strCommand.indexOf('.');

    if(intPeriodIndex==-1)
      intPeriodIndex=Integer.MAX_VALUE;

    int intParenthesisIndex=strCommand.indexOf('(');

    if(intParenthesisIndex==-1)
      intParenthesisIndex=Integer.MAX_VALUE;

    int intEndIndex=strCommand.length();

    int intLeastIndex=-1;

    if(intPeriodIndex<intParenthesisIndex) {
      if(intPeriodIndex<intEndIndex) {
        intLeastIndex=intPeriodIndex;
      }
      else {
        intLeastIndex=intEndIndex;
      }
    }
    else {
      if(intParenthesisIndex<intEndIndex) {
        intLeastIndex=intParenthesisIndex;
      }
      else {
        intLeastIndex=intEndIndex;
      }
    }

    return intLeastIndex;
*/
  }

  public static String getClassNameFromCommandTrail(String strClassName, String strCommandTrail, ClassObject classObj, Vector vecLocalFields, int intAbsoluteLineNumber) throws Exception {
    return getClassNameFromCommandTrail(strClassName, strCommandTrail, classObj, vecLocalFields, intAbsoluteLineNumber, -1);
  }

  public static String getClassNameFromCommandTrail(String strClassName, String strCommandTrail, ClassObject classObj, Vector vecLocalFields, int intAbsoluteLineNumber, int intParseToPeriodIndex) throws Exception {
    if(strCommandTrail.endsWith(";"))
      strCommandTrail=strCommandTrail.substring(0, strCommandTrail.length()-1);

if(blnDoShowOutputExtended) {
System.out.println("getClassNameFromCommandTrail: "+strClassName);
System.out.println("getClassNameFromCommandTrail: "+strCommandTrail);
System.out.println("getClassNameFromCommandTrail: "+classObj.getClassName());
}

    String strRetClass="";

//    if(strCommandTrail.indexOf(' ')!=-1)
//      throw new Exception("Encountered \" \" where none should be found while parsing built in class command for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

    String strClassName0=(String)hashImported.get(strClassName);
    if(strClassName0==null) {
      try {
        Class.forName(strClassName);

        strClassName0=strClassName;
      }
      catch(Exception ex) {
        throw new Exception("Class \""+strClassName+"\" not found for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
      }
    }
    strClassName=strClassName0;

/*
    String strClassName0=(String)hashImported.get(strClassName);
    if(strClassName0==null)
      throw new Exception("Class \""+strClassName+"\" not found for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
    strClassName=strClassName0;
*/

    Class classClass=Class.forName(strClassName);

//System.out.println("getClassNameFromCommandTrail");
//System.out.println(strClassName);
//System.out.println(strCommandTrail);

    while(true) {
      int intLeastIndex=isPeriodParenthesisEndLeast(strCommandTrail);

      if(intLeastIndex==strCommandTrail.length()) {
        if(strCommandTrail.equals("class")) {
          strRetClass="java.lang.Class";

          break;
        }

        Field field=getDeclaredField(classClass, strCommandTrail);

        strRetClass=field.getType().getName();

        break;
      }
      else {
        if(strCommandTrail.charAt(intLeastIndex)=='.') {
          String strFieldName=strCommandTrail.substring(0, intLeastIndex);

//System.out.println("field: "+strFieldName);

          strCommandTrail=strCommandTrail.substring(intLeastIndex+1);

          Field field=getDeclaredField(classClass, strFieldName);

          classClass=field.getType();
        }
        else if(strCommandTrail.charAt(intLeastIndex)=='(') {
          String strFunctionName=strCommandTrail.substring(0, intLeastIndex);

          strCommandTrail=strCommandTrail.substring(intLeastIndex+1);

          Vector vecParameters=new Vector();
          int intParseEnd=parseParameters(strCommandTrail, vecParameters, classObj, vecLocalFields, intAbsoluteLineNumber);

//System.out.println("getClassNameParseParameters: "+vecParameters.size());

          Class classParameters[]=new Class[vecParameters.size()];

          for(int i=0;i<vecParameters.size();i++) {
            FieldObject nextField=(FieldObject)vecParameters.elementAt(i);
            String strNextFieldClass=nextField.getClassName();

            if(strNextFieldClass.startsWith("boolean")) {
              if(strNextFieldClass.endsWith("[]")) {
                int intBracketCount=1;
                strNextFieldClass=strNextFieldClass.substring(0, strNextFieldClass.length()-2);
                while(true) {
                  if(strNextFieldClass.endsWith("[]")) {
                    ++intBracketCount;
                    strNextFieldClass=strNextFieldClass.substring(0, strNextFieldClass.length()-2);
                    continue;
                  }

                  break;
                }

                String strNextFieldClassPre="";
                for(int ia=0;ia<intBracketCount;ia++)
                  strNextFieldClassPre+="[";

                strNextFieldClass=strNextFieldClassPre+"Z";
              }
            }
            else if(strNextFieldClass.startsWith("char")) {
              if(strNextFieldClass.endsWith("[]")) {
                int intBracketCount=1;
                strNextFieldClass=strNextFieldClass.substring(0, strNextFieldClass.length()-2);
                while(true) {
                  if(strNextFieldClass.endsWith("[]")) {
                    ++intBracketCount;
                    strNextFieldClass=strNextFieldClass.substring(0, strNextFieldClass.length()-2);
                    continue;
                  }

                  break;
                }

                String strNextFieldClassPre="";
                for(int ia=0;ia<intBracketCount;ia++)
                  strNextFieldClassPre+="[";

                strNextFieldClass=strNextFieldClassPre+"C";
              }
            }
            else if(strNextFieldClass.startsWith("byte")) {
              if(strNextFieldClass.endsWith("[]")) {
                int intBracketCount=1;
                strNextFieldClass=strNextFieldClass.substring(0, strNextFieldClass.length()-2);
                while(true) {
                  if(strNextFieldClass.endsWith("[]")) {
                    ++intBracketCount;
                    strNextFieldClass=strNextFieldClass.substring(0, strNextFieldClass.length()-2);
                    continue;
                  }

                  break;
                }

                String strNextFieldClassPre="";
                for(int ia=0;ia<intBracketCount;ia++)
                  strNextFieldClassPre+="[";

                strNextFieldClass=strNextFieldClassPre+"B";
              }
            }
            else if(strNextFieldClass.startsWith("short")) {
              if(strNextFieldClass.endsWith("[]")) {
                int intBracketCount=1;
                strNextFieldClass=strNextFieldClass.substring(0, strNextFieldClass.length()-2);
                while(true) {
                  if(strNextFieldClass.endsWith("[]")) {
                    ++intBracketCount;
                    strNextFieldClass=strNextFieldClass.substring(0, strNextFieldClass.length()-2);
                    continue;
                  }

                  break;
                }

                String strNextFieldClassPre="";
                for(int ia=0;ia<intBracketCount;ia++)
                  strNextFieldClassPre+="[";

                strNextFieldClass=strNextFieldClassPre+"S";
              }
            }
            else if(strNextFieldClass.startsWith("int")) {
              if(strNextFieldClass.endsWith("[]")) {
                int intBracketCount=1;
                strNextFieldClass=strNextFieldClass.substring(0, strNextFieldClass.length()-2);
                while(true) {
                  if(strNextFieldClass.endsWith("[]")) {
                    ++intBracketCount;
                    strNextFieldClass=strNextFieldClass.substring(0, strNextFieldClass.length()-2);
                    continue;
                  }

                  break;
                }

                String strNextFieldClassPre="";
                for(int ia=0;ia<intBracketCount;ia++)
                  strNextFieldClassPre+="[";

                strNextFieldClass=strNextFieldClassPre+"I";
              }
            }
            else if(strNextFieldClass.startsWith("float")) {
              if(strNextFieldClass.endsWith("[]")) {
                int intBracketCount=1;
                strNextFieldClass=strNextFieldClass.substring(0, strNextFieldClass.length()-2);
                while(true) {
                  if(strNextFieldClass.endsWith("[]")) {
                    ++intBracketCount;
                    strNextFieldClass=strNextFieldClass.substring(0, strNextFieldClass.length()-2);
                    continue;
                  }

                  break;
                }

                String strNextFieldClassPre="";
                for(int ia=0;ia<intBracketCount;ia++)
                  strNextFieldClassPre+="[";

                strNextFieldClass=strNextFieldClassPre+"F";
              }
            }
            else if(strNextFieldClass.startsWith("long")) {
              if(strNextFieldClass.endsWith("[]")) {
                int intBracketCount=1;
                strNextFieldClass=strNextFieldClass.substring(0, strNextFieldClass.length()-2);
                while(true) {
                  if(strNextFieldClass.endsWith("[]")) {
                    ++intBracketCount;
                    strNextFieldClass=strNextFieldClass.substring(0, strNextFieldClass.length()-2);
                    continue;
                  }

                  break;
                }

                String strNextFieldClassPre="";
                for(int ia=0;ia<intBracketCount;ia++)
                  strNextFieldClassPre+="[";

                strNextFieldClass=strNextFieldClassPre+"J";
              }
            }
            else if(strNextFieldClass.startsWith("double")) {
              if(strNextFieldClass.endsWith("[]")) {
                int intBracketCount=1;
                strNextFieldClass=strNextFieldClass.substring(0, strNextFieldClass.length()-2);
                while(true) {
                  if(strNextFieldClass.endsWith("[]")) {
                    ++intBracketCount;
                    strNextFieldClass=strNextFieldClass.substring(0, strNextFieldClass.length()-2);
                    continue;
                  }

                  break;
                }

                String strNextFieldClassPre="";
                for(int ia=0;ia<intBracketCount;ia++)
                  strNextFieldClassPre+="[";

                strNextFieldClass=strNextFieldClassPre+"D";
              }
            }
            else {
              if(strNextFieldClass.endsWith("[]")) {
                int intBracketCount=1;
                strNextFieldClass=strNextFieldClass.substring(0, strNextFieldClass.length()-2);
                while(true) {
                  if(strNextFieldClass.endsWith("[]")) {
                    ++intBracketCount;
                    strNextFieldClass=strNextFieldClass.substring(0, strNextFieldClass.length()-2);
                    continue;
                  }

                  break;
                }

                String strNextFieldClassPre="";
                for(int ia=0;ia<intBracketCount;ia++)
                  strNextFieldClassPre+="[";
                strNextFieldClassPre+="L";

                strNextFieldClass=strNextFieldClassPre+strNextFieldClass+";";
              }
            }

//System.out.println("strNextFieldClass: \""+strNextFieldClass+"\"");

            if(strNextFieldClass.equals("boolean"))
              classParameters[i]=boolean.class;
            else if(strNextFieldClass.equals("char"))
              classParameters[i]=char.class;
            else if(strNextFieldClass.equals("byte"))
              classParameters[i]=byte.class;
            else if(strNextFieldClass.equals("short"))
              classParameters[i]=short.class;
            else if(strNextFieldClass.equals("int"))
              classParameters[i]=int.class;
            else if(strNextFieldClass.equals("float"))
              classParameters[i]=float.class;
            else if(strNextFieldClass.equals("long"))
              classParameters[i]=long.class;
            else if(strNextFieldClass.equals("double"))
              classParameters[i]=double.class;
            else if(strNextFieldClass.equals("null"))
              classParameters[i]=null;
            else {
//              String strNextFieldClass0=(String)hashImported.get(strNextFieldClass);
//              if(strNextFieldClass0!=null)
//                strNextFieldClass=strNextFieldClass0;
              try {
                classParameters[i]=Class.forName(strNextFieldClass);
              }
              catch(Exception ex) {
                classParameters[i]=Class.forName("java.lang.Object");
              }
            }
          }

          Method method=null;

//for(int i=0;i<classParameters.length;i++) {
//if(classParameters[i]==null)
//System.out.println(i+":null");
//else
//System.out.println(i+":"+classParameters[i].getName());
//}

          method=getDeclaredMethod(classClass, strFunctionName, classParameters);

          if(method==null) {
            for(int i=0;i<classParameters.length;i++) {
              if(classParameters[i]==byte.class)
                classParameters[i]=int.class;
              else if(classParameters[i]==short.class)
                classParameters[i]=int.class;
//              else if(classParameters[i]==int.class)
//                classParameters[i]=long.class;
              else if(classParameters[i]==long.class)
                classParameters[i]=int.class;
              else if(classParameters[i]==float.class)
                classParameters[i]=double.class;
              else if(classParameters[i]==char.class)
                classParameters[i]=int.class;
            }

            method=getDeclaredMethod(classClass, strFunctionName, classParameters);

            if(method==null) {
              for(int i=0;i<classParameters.length;i++) {
                if(classParameters[i]==int.class)
                  classParameters[i]=long.class;
              }

              method=getDeclaredMethod(classClass, strFunctionName, classParameters);

              if(method==null) {
                Method methodsAll[]=classClass.getDeclaredMethods();
                for(int iz=0;iz<methodsAll.length;iz++) {
                  if(methodsAll[iz].getName().equals(strFunctionName)) {
                    if(method!=null)
                      throw new Exception("Function \""+strFunctionName+"\" not found in \""+classClass.getName()+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));

                    method=methodsAll[iz];
                  }
                }

                if(method==null)
                  throw new Exception("Function \""+strFunctionName+"\" not found in \""+classClass.getName()+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
              }
            }
          }

          classClass=method.getReturnType();

          if(intParseEnd==strCommandTrail.length()) {
            strRetClass=classClass.getName();

            break;
          }

          strCommandTrail=strCommandTrail.substring(intParseEnd+1);
//System.out.println("function strCommandTrail: \""+strCommandTrail+"\"");
        }
      }
    }

    if(strRetClass.startsWith("[")) {
      int intBracketCount=1;
      strRetClass=strRetClass.substring(1);

      while(true) {
        if(strRetClass.startsWith("[")) {
          ++intBracketCount;
          strRetClass=strRetClass.substring(1);
          continue;
        }

        break;
      }

      strRetClass=strRetClass.substring(0, strRetClass.length()-1);

      for(int i=0;i<intBracketCount;i++)
        strRetClass=strRetClass+"[]";
    }

    return strRetClass;
  }

  public static Field getDeclaredField(Class classClass, String strFieldName) {
    try {
      Field field=classClass.getDeclaredField(strFieldName);

      return field;
    }
    catch(NoSuchFieldException ex) {
      Class interfaces[]=classClass.getInterfaces();

      for(int i=0;i<interfaces.length;i++) {
        try {
          Field field=interfaces[i].getDeclaredField(strFieldName);

          return field;
        }
        catch(NoSuchFieldException ex2) {
        }
      }

      Class class0=classClass.getSuperclass();
      if(class0!=null)
        return getDeclaredField(class0, strFieldName);
    }

    return null;
  }

  public static Method getDeclaredMethod(Class classClass, String strFunctionName, Class classParameters[]) throws Exception {
//System.out.println("getDeclaredMethod: "+classClass.getName()+", "+strFunctionName+", "+classParameters.length);

    Method retMethod=null;

    try {
      Method methods[]=classClass.getDeclaredMethods();

      boolean blnMethodMatch[]=new boolean[methods.length];
      for(int i=0;i<blnMethodMatch.length;i++)
        blnMethodMatch[i]=true;

      for(int i=0;i<blnMethodMatch.length;i++) {
        if(!methods[i].getName().equals(strFunctionName))
          blnMethodMatch[i]=false;
      }

      for(int i=0;i<blnMethodMatch.length;i++) {
        if(!blnMethodMatch[i])
          continue;

        if(methods[i].getParameterCount()!=classParameters.length)
          blnMethodMatch[i]=false;
      }

      for(int i=0;i<blnMethodMatch.length;i++) {
        if(!blnMethodMatch[i])
          continue;

        Class methodParameters[]=methods[i].getParameterTypes();

//        Class classMatches[]=new Class[classParameters.length];

        for(int ia=0;ia<classParameters.length;ia++) {
          Class classMatch=isMethodParameterMatch(classParameters[ia], methodParameters[ia]);

          if(classMatch==null) {
            blnMethodMatch[i]=false;

            break;
          }
//          else
//            classMatches[ia]=classMatch;
        }

//        vecMatches.addElement(classMatches);
      }

      for(int i=0;i<blnMethodMatch.length;i++) {
        if(blnMethodMatch[i]) {
          retMethod=methods[i];
          break;
        }
      }

      if(retMethod==null)
        throw new NoSuchMethodException("");

//      retMethod=classClass.getDeclaredMethod(strFunctionName, classParameters);
    }
    catch(NoSuchMethodException ne) {
      classClass=classClass.getSuperclass();

      if(classClass!=null)
        retMethod=getDeclaredMethod(classClass, strFunctionName, classParameters);

/*
      if(retMethod==null) {
        Class classInterfaces[]=classClass.getInterfaces();
        for(int i=0;i<classInterfaces.length;i++) {
          retMethod=getDeclaredMethod(classInterfaces[i], strFunctionName, classParameters);

          if(retMethod!=null)
            break;
        }
      }
*/
    }

    return retMethod;
  }

  public static Class isMethodParameterMatch(Class classParameter, Class methodParameter) throws Exception {
    if(classParameter==null)
      return methodParameter;

    Class retClass=null;

    while(true) {
      if(classParameter.getName().equals(methodParameter.getName())) {
        retClass=classParameter;
        return retClass;
      }

      Class interfaces[]=classParameter.getInterfaces();

      for(int i=0;i<interfaces.length;i++) {
        if(isInterfaceMatch(interfaces[i], methodParameter)) {
          retClass=methodParameter;
          return retClass;
        }

/*
        if(interfaces[i].getName().equals(methodParameter.getName())) {
          retClass=interfaces[i];
          return retClass;
        }
*/
      }

      String strClassParameterName=classParameter.getName();
      if(strClassParameterName.startsWith("[")) {
        if(strClassParameterName.equals("[Ljava.lang.Object;"))
          classParameter=Class.forName("java.lang.Object");
        else
          classParameter=Class.forName("[Ljava.lang.Object;");
      }
      else {
        classParameter=classParameter.getSuperclass();
        if(classParameter==null)
          break;
      }
    }

    return retClass;
  }

  public static boolean isInterfaceMatch(Class classInterface, Class methodParameter) {
    if(classInterface.getName().equals(methodParameter.getName()))
      return true;

    Class classA[]=classInterface.getInterfaces();
    for(int i=0;i<classA.length;i++) {
      boolean blnIsMatch=isInterfaceMatch(classA[i], methodParameter);

      if(blnIsMatch)
        return true;
    }

    return false;
  }

  public static void parseArrayInitializer(String strInitializer, ClassObject classObj, int intAbsoluteLineNumber, Vector vecLocalFields) throws Exception {
//System.out.println(strInitializer);

    int intIndex=0;
    int intIndex2=0;

    while(true) {
      if(intIndex2>=strInitializer.length())
        break;

      char chr=strInitializer.charAt(intIndex2);

      if(chr=='(') {
        int intParenthesisCount=1;

        ++intIndex2;

        while(true) {
          char chr2=strInitializer.charAt(intIndex2);

          if(chr2=='(') {
            ++intParenthesisCount;
          }
          else if(chr2==')') {
            --intParenthesisCount;

            if(intParenthesisCount==0)
              break;
          }

          ++intIndex2;
        }
      }
      else if(chr=='[') {
        int intBracketCount=1;

        ++intIndex2;

        while(true) {
          char chr2=strInitializer.charAt(intIndex2);

          if(chr2=='[') {
            ++intBracketCount;
          }
          else if(chr2==']') {
            --intBracketCount;

            if(intBracketCount==0)
              break;
          }

          ++intIndex2;
        }
      }
      else if(chr=='{') {
        int intBraceCount=1;

        ++intIndex2;

        while(true) {
          char chr2=strInitializer.charAt(intIndex2);

          if(chr2=='{') {
            ++intBraceCount;
          }
          else if(chr2=='}') {
            --intBraceCount;

            if(intBraceCount==0)
              break;
          }

          ++intIndex2;
        }
      }
      else if(chr==',') {
        String strElement=strInitializer.substring(intIndex, intIndex2);

        if(strElement.startsWith("{")) {
          String strInitializer0=strElement.substring(1, strElement.length()-1);

          parseArrayInitializer(strInitializer0, classObj, intAbsoluteLineNumber, vecLocalFields);
        }
        else {
          Vector vecOperands=parseOperands(strElement);

          for(int i=0;i<vecOperands.size();i++) {
            String strNextOperand=(String)vecOperands.elementAt(i);
            executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
          }
        }

        ++intIndex2;

        if(strInitializer.charAt(intIndex2)==' ')
          ++intIndex2;

        intIndex=intIndex2;

        continue;
      }

      ++intIndex2;
    }

    String strElement=strInitializer.substring(intIndex, intIndex2);

    if(strElement.startsWith("{")) {
      String strInitializer0=strElement.substring(1, strElement.length()-1);

      parseArrayInitializer(strInitializer0, classObj, intAbsoluteLineNumber, vecLocalFields);
    }
    else {
      Vector vecOperands=parseOperands(strElement);

      for(int i=0;i<vecOperands.size();i++) {
        String strNextOperand=(String)vecOperands.elementAt(i);
        executeOperand(strNextOperand, classObj, intAbsoluteLineNumber, vecLocalFields);
      }
    }
  }

  public static void printConstructorFunctionStack() {
    System.out.println("\n\n\nConstructors: ");

    for(int i=0;i<vecExecutingConstructors.size();i++)
      System.out.println(vecExecutingConstructors.elementAt(i));

    System.out.println("\n\n\nFunctions: ");

    for(int i=0;i<vecExecutingFunctions.size();i++)
      System.out.println(vecExecutingFunctions.elementAt(i));
  }

  public static String getFieldObjectClassByName(String strName, ClassObject classObj, int intAbsoluteLineNumber) throws Exception {
    String strRet="";

    BooleanContainer blnContainer=new BooleanContainer();

    FieldObject fObj=classObj.getFieldObjectByName(strName, blnContainer);

//if(fObj!=null)
//System.out.println("getFieldObjectByName: "+fObj.getClassName());
//else
//System.out.println("getFieldObjectByName: is null");

    if(fObj==null) {
      String classObjName=classObj.getClassName();

      int intDollarIndex=classObjName.indexOf("$");

      if(intDollarIndex==-1) {
        String strSuperclass=classObj.getSuperclass();

        ClassObject classObj2=(ClassObject)hashClasses.get(strSuperclass);

        if(classObj2==null) {
          Class class0=Class.forName(strSuperclass);

          return getFieldObjectByName(class0, strName);
        }
        else {
          return getFieldObjectClassByName(strName, classObj2, intAbsoluteLineNumber);
        }

//        throw new Exception("Unidentified field \""+strName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
      }
      else {
        String classObjNameOuter=classObjName.substring(0, intDollarIndex);

        ClassObject classObjOuter=(ClassObject)hashClasses.get(classObjNameOuter);

        fObj=classObjOuter.getFieldObjectByName(strName, blnContainer);

        if(fObj==null) {
          String strSuperclass=classObj.getSuperclass();

          ClassObject classObj2=(ClassObject)hashClasses.get(strSuperclass);

          if(classObj2==null) {
            Class class0=Class.forName(strSuperclass);

            String strRetZ=getFieldObjectByName(class0, strName);


            if(strRetZ.length()>0)
              return strRetZ;
            else {


              strSuperclass=classObjOuter.getSuperclass();

              classObj2=(ClassObject)hashClasses.get(strSuperclass);

              if(classObj2==null) {
                class0=Class.forName(strSuperclass);

                strRetZ=getFieldObjectByName(class0, strName);

                return strRetZ;

/*
                if(strRet[1].length()>0)
                  return strRet;
                else {
                  throw new Exception("Unidentified field \""+strName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
                }
*/
              }
              else {
                strRetZ=getFieldObjectClassByName(strName, classObj2, intAbsoluteLineNumber);

                return strRetZ;

/*
                if(strRet2[1].length()>0)
                  return strRet2;
                else
                  throw new Exception("Unidentified field \""+strName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
*/
              }


            }


          }
          else {
            String strRetZ=getFieldObjectClassByName(strName, classObj2, intAbsoluteLineNumber);

            if(strRetZ.length()>0)
              return strRetZ;
            else {


              strSuperclass=classObjOuter.getSuperclass();

              classObj2=(ClassObject)hashClasses.get(strSuperclass);

              if(classObj2==null) {
                Class class0=Class.forName(strSuperclass);

                strRetZ=getFieldObjectByName(class0, strName);

                return strRetZ;

/*
                if(strRet[1].length()>0)
                  return strRet;
                else {
                  throw new Exception("Unidentified field \""+strName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
                }
*/
              }
              else {
                strRetZ=getFieldObjectClassByName(strName, classObj2, intAbsoluteLineNumber);

                return strRetZ;

/*
                if(strRet2[1].length()>0)
                  return strRet2;
                else
                  throw new Exception("Unidentified field \""+strName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
*/
              }


            }


          }

//          throw new Exception("Unidentified field \""+strName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
        }
      }
    }

    if(fObj!=null)
      strRet=fObj.getClassName();

    return strRet;
  }

  public static String getFieldObjectByName(ClassObject classObj, String strOperand, String strCommand) throws Exception {
    String strRet="";

    BooleanContainer blnContainer=new BooleanContainer();

    FieldObject fObj=classObj.getFieldObjectByName(strCommand, blnContainer);

//if(fObj!=null)
//System.out.println("getFieldObjectByName: "+fObj.getClassName());
//else
//System.out.println("getFieldObjectByName: is null");

    if(fObj==null) {
      String classObjName=classObj.getClassName();

      int intDollarIndex=classObjName.indexOf("$");

      if(intDollarIndex==-1) {
        String strSuperclass=classObj.getSuperclass();

        ClassObject classObj2=(ClassObject)hashClasses.get(strSuperclass);

        if(classObj2==null) {
          Class class0=Class.forName(strSuperclass);

          return getFieldObjectByName(class0, strCommand);
        }
        else {
          return getFieldObjectByName(classObj2, strOperand, strCommand);
        }

//        throw new Exception("Unidentified field \""+strCommand+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
      }
      else {
        String classObjNameOuter=classObjName.substring(0, intDollarIndex);

        ClassObject classObjOuter=(ClassObject)hashClasses.get(classObjNameOuter);

        fObj=classObjOuter.getFieldObjectByName(strCommand, blnContainer);

        if(fObj==null) {
          String strSuperclass=classObj.getSuperclass();

          ClassObject classObj2=(ClassObject)hashClasses.get(strSuperclass);

          if(classObj2==null) {
            Class class0=Class.forName(strSuperclass);

            String strRetZ=getFieldObjectByName(class0, strCommand);


            if(strRetZ.length()>0)
              return strRetZ;
            else {


              strSuperclass=classObjOuter.getSuperclass();

              classObj2=(ClassObject)hashClasses.get(strSuperclass);

              if(classObj2==null) {
                class0=Class.forName(strSuperclass);

                strRetZ=getFieldObjectByName(class0, strCommand);

                return strRetZ;

/*
                if(strRet[1].length()>0)
                  return strRet;
                else {
                  throw new Exception("Unidentified field \""+strCommand+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
                }
*/
              }
              else {
                strRetZ=getFieldObjectByName(classObj2, strOperand, strCommand);

                return strRetZ;

/*
                if(strRet2[1].length()>0)
                  return strRet2;
                else
                  throw new Exception("Unidentified field \""+strCommand+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
*/
              }


            }


          }
          else {
            String strRetZ=getFieldObjectByName(classObj2, strOperand, strCommand);

            if(strRetZ.length()>0)
              return strRetZ;
            else {


              strSuperclass=classObjOuter.getSuperclass();

              classObj2=(ClassObject)hashClasses.get(strSuperclass);

              if(classObj2==null) {
                Class class0=Class.forName(strSuperclass);

                strRetZ=getFieldObjectByName(class0, strCommand);

                return strRetZ;

/*
                if(strRet[1].length()>0)
                  return strRet;
                else {
                  throw new Exception("Unidentified field \""+strCommand+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
                }
*/
              }
              else {
                strRetZ=getFieldObjectByName(classObj2, strOperand, strCommand);

                return strRetZ;

/*
                if(strRet2[1].length()>0)
                  return strRet2;
                else
                  throw new Exception("Unidentified field \""+strCommand+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
*/
              }


            }


          }

//          throw new Exception("Unidentified field \""+strCommand+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
        }
      }
    }

    if(fObj!=null)
      strRet=FieldObject.getClassName(strOperand, fObj);

    return strRet;
  }

  public static String getFieldObjectByName(Class class0, String strCommand) throws Exception {
    String strRet="";

    try {
      Field field=class0.getDeclaredField(strCommand);

      strRet=field.getType().getName();
    }
    catch(NoSuchFieldException ex) {
      Class interfaces[]=class0.getInterfaces();
      for(int i=0;i<interfaces.length;i++) {
        try {
          Field field=interfaces[i].getDeclaredField(strCommand);

          return field.getType().getName();
        }
        catch(NoSuchFieldException ex2) {
        }
      }

      Class class1=class0.getSuperclass();
      if(class1==null)
        return "";

      strRet=getFieldObjectByName(class1, strCommand);
    }

    return strRet;
  }

  public static String[] getFieldObjectByName2(ClassObject classObj, String strOperand, String strClassRootName) throws Exception {
//System.out.println("getFieldObjectByName2");
//System.out.println(strOperand);
//System.out.println(strClassRootName);
    String strRet[]=new String[2];
    strRet[1]="";

    BooleanContainer blnContainer=new BooleanContainer();

    FieldObject fObj=classObj.getFieldObjectByName(strClassRootName, blnContainer);

    if(fObj==null) {
      String classObjName=classObj.getClassName();

      int intDollarIndex=classObjName.indexOf("$");

      if(intDollarIndex==-1) {
        String strSuperclass=classObj.getSuperclass();

        ClassObject classObj2=(ClassObject)hashClasses.get(strSuperclass);

        if(classObj2==null) {
          Class class0=Class.forName(strSuperclass);

          strRet[0]="true";
          strRet[1]=getFieldObjectByName(class0, strClassRootName);

          return strRet;
        }
        else {
          return getFieldObjectByName2(classObj2, strOperand, strClassRootName);
        }

//        throw new Exception("Unidentified field \""+strClassRootName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
      }
      else {
        String classObjNameOuter=classObjName.substring(0, intDollarIndex);

        ClassObject classObjOuter=(ClassObject)hashClasses.get(classObjNameOuter);

        fObj=classObjOuter.getFieldObjectByName(strClassRootName, blnContainer);

        if(fObj==null) {
          String strSuperclass=classObj.getSuperclass();

          ClassObject classObj2=(ClassObject)hashClasses.get(strSuperclass);

          if(classObj2==null) {
            Class class0=Class.forName(strSuperclass);

            strRet[0]="true";
            strRet[1]=getFieldObjectByName(class0, strClassRootName);

            if(strRet[1].length()>0)
              return strRet;
            else {


              strSuperclass=classObjOuter.getSuperclass();

              classObj2=(ClassObject)hashClasses.get(strSuperclass);

              if(classObj2==null) {
                class0=Class.forName(strSuperclass);

                strRet[0]="true";
                strRet[1]=getFieldObjectByName(class0, strClassRootName);

                return strRet;

/*
                if(strRet[1].length()>0)
                  return strRet;
                else {
                  throw new Exception("Unidentified field \""+strClassRootName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
                }
*/
              }
              else {
                String strRet2[]=getFieldObjectByName2(classObj2, strOperand, strClassRootName);

                return strRet2;

/*
                if(strRet2[1].length()>0)
                  return strRet2;
                else
                  throw new Exception("Unidentified field \""+strClassRootName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
*/
              }


            }

          }
          else {
            String strRet2[]=getFieldObjectByName2(classObj2, strOperand, strClassRootName);

            if(strRet2[1].length()>0)
              return strRet2;
            else {


              strSuperclass=classObjOuter.getSuperclass();

              classObj2=(ClassObject)hashClasses.get(strSuperclass);

              if(classObj2==null) {
                Class class0=Class.forName(strSuperclass);

                strRet[0]="true";
                strRet[1]=getFieldObjectByName(class0, strClassRootName);

                return strRet;

/*
                if(strRet[1].length()>0)
                  return strRet;
                else {
                  throw new Exception("Unidentified field \""+strClassRootName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
                }
*/
              }
              else {
                String strRet3[]=getFieldObjectByName2(classObj2, strOperand, strClassRootName);

                return strRet3;

/*
                if(strRet2[1].length()>0)
                  return strRet2;
                else
                  throw new Exception("Unidentified field \""+strClassRootName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
*/
              }


            }


          }

//          throw new Exception("Unidentified field \""+strClassRootName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
        }
      }
    }

    if(fObj!=null) {
      String strClassRootClass=FieldObject.getClassName(strOperand, fObj);

      if(strClassRootClass.indexOf('[')!=-1) {
        strRet[0]="true";
        strRet[1]="int";
      }
      else {
        strRet[0]="false";
        strRet[1]=strClassRootClass;
      }
    }

    return strRet;
  }

  public static String[] getFunctionObjectBySignature(ClassObject classObj, ClassObject classObjZ, String strFunctionName, String strCommandTrail, Vector vecParameters, BooleanContainer blnContainer0, Vector vecLocalFields, int intAbsoluteLineNumber) throws Exception {
//System.out.println("getFunctionObjectBySignature");
//System.out.println(new FunctionSignature(classObj.getClassName(), strFunctionName, vecParameters).toString());
//System.out.println(vecParameters.size());

    String strRet[]=new String[2];

    BooleanContainer blnContainer=new BooleanContainer();

//    String strClassNameZ=getFunctionObjectBySignature(classObj, strFunctionName, vecParameters, blnContainer);

    FunctionObject fObj=classObj.getFunctionObjectBySignature(new FunctionSignature(classObj.getClassName(), strFunctionName, vecParameters), blnContainer);

    blnContainer0.setBln(blnContainer.getBln());

    if(fObj==null) {
      String classObjName=classObj.getClassName();

      int intDollarIndex=classObjName.indexOf("$");

      if(intDollarIndex==-1) {
        String strSuperclass=classObj.getSuperclass();

        ClassObject classObj2=(ClassObject)hashClasses.get(strSuperclass);

        if(classObj2==null) {
          String strNameFromCommandTrail=getClassNameFromCommandTrail(classObj.getSuperclass(), strCommandTrail, classObjZ, vecLocalFields, intAbsoluteLineNumber);

          strRet[0]="true";
          strRet[1]=strNameFromCommandTrail;

          return strRet;
        }
        else {
          strRet=getFunctionObjectBySignature(classObj2, classObjZ, strFunctionName, strCommandTrail, vecParameters, blnContainer0, vecLocalFields, intAbsoluteLineNumber);

          return strRet;
        }

//        throw new Exception("Unidentified field \""+strCommand+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
      }
      else {
        String classObjNameOuter=classObjName.substring(0, intDollarIndex);

        ClassObject classObjOuter=(ClassObject)hashClasses.get(classObjNameOuter);

        fObj=classObjOuter.getFunctionObjectBySignature(new FunctionSignature(classObjOuter.getClassName(), strFunctionName, vecParameters), blnContainer);

        blnContainer0.setBln(blnContainer.getBln());

        if(fObj==null) {
          String strSuperclass=classObj.getSuperclass();

          ClassObject classObj2=(ClassObject)hashClasses.get(strSuperclass);

          if(classObj2==null) {
            String strNameFromCommandTrail=getClassNameFromCommandTrail(classObj.getSuperclass(), strCommandTrail, classObjZ, vecLocalFields, intAbsoluteLineNumber);

            strRet[0]="true";
            strRet[1]=strNameFromCommandTrail;

            return strRet;
          }
          else {
            strRet=getFunctionObjectBySignature(classObj2, classObjZ, strFunctionName, strCommandTrail, vecParameters, blnContainer0, vecLocalFields, intAbsoluteLineNumber);

            return strRet;
          }

//          throw new Exception("Unidentified function \""+strFunctionName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
        }
      }
    }

    if(fObj!=null) {
      strRet[0]="false";
      strRet[1]=fObj.getSignature().getClassName();

/*
      if(strRet[1].equals("void"))
        strRet[0]="true";
      else
        strRet[0]="false";
*/
    }

    blnContainer0.setBln(blnContainer.getBln());

    return strRet;
  }

  public static String[] getFunctionObjectBySignature2(ClassObject classObj, ClassObject classObjZ, String strFunctionName, String strCommandTrail, Vector vecParameters, FunctionObjectContainer fObjContainer0, Vector vecLocalFields, int intAbsoluteLineNumber, ClassObjectContainer classContainer) throws Exception {
//System.out.println("getFunctionObjectBySignature2");
//System.out.println(new FunctionSignature(classObj.getClassName(), strFunctionName, vecParameters).toString());
//System.out.println(vecParameters.size());
//System.out.println(classObjZ.getClassName());

    String strRet[]=new String[2];

    BooleanContainer blnContainer=new BooleanContainer();

//    String strClassNameZ=getFunctionObjectBySignature(classObj, strFunctionName, vecParameters, blnContainer);

    FunctionObject fObj=classObj.getFunctionObjectBySignature(new FunctionSignature(classObj.getClassName(), strFunctionName, vecParameters), blnContainer);

//if(fObj==null)
//System.out.println("is null");

    fObjContainer0.setFunctionObject(fObj);

    classContainer.setClassObject(classObj);

//    blnContainer0.setBln(blnContainer.getBln());

    if(fObj==null) {
      String classObjName=classObj.getClassName();

      int intDollarIndex=classObjName.indexOf("$");

      if(intDollarIndex==-1) {
        String strSuperclass=classObj.getSuperclass();

        ClassObject classObj2=(ClassObject)hashClasses.get(strSuperclass);

        if(classObj2==null) {
          String strNameFromCommandTrail=getClassNameFromCommandTrail(classObj.getSuperclass(), strCommandTrail, classObjZ, vecLocalFields, intAbsoluteLineNumber);

          strRet[0]="true";
          strRet[1]=strNameFromCommandTrail;

          return strRet;
        }
        else {
          strRet=getFunctionObjectBySignature2(classObj2, classObjZ, strFunctionName, strCommandTrail, vecParameters, fObjContainer0, vecLocalFields, intAbsoluteLineNumber, classContainer);

          return strRet;
        }

//        throw new Exception("Unidentified field \""+strCommand+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
      }
      else {
        String classObjNameOuter=classObjName.substring(0, intDollarIndex);

        ClassObject classObjOuter=(ClassObject)hashClasses.get(classObjNameOuter);

        fObj=classObjOuter.getFunctionObjectBySignature(new FunctionSignature(classObjOuter.getClassName(), strFunctionName, vecParameters), blnContainer);

        fObjContainer0.setFunctionObject(fObj);

        classContainer.setClassObject(classObjOuter);

//        blnContainer0.setBln(blnContainer.getBln());

        if(fObj==null) {
          String strSuperclass=classObj.getSuperclass();

          ClassObject classObj2=(ClassObject)hashClasses.get(strSuperclass);

          if(classObj2==null) {
            String strNameFromCommandTrail=getClassNameFromCommandTrail(classObj.getSuperclass(), strCommandTrail, classObjZ, vecLocalFields, intAbsoluteLineNumber);

            strRet[0]="true";
            strRet[1]=strNameFromCommandTrail;

            return strRet;
          }
          else {
            strRet=getFunctionObjectBySignature2(classObj2, classObjZ, strFunctionName, strCommandTrail, vecParameters, fObjContainer0, vecLocalFields, intAbsoluteLineNumber, classContainer);

            return strRet;
          }

//          throw new Exception("Unidentified function \""+strFunctionName+"\" for file: "+strFilePath+":"+(intAbsoluteLineNumber-1));
        }
      }
    }

    if(fObj!=null) {
      strRet[0]="false";
      strRet[1]=fObj.getReturnClassName();

/*
      if(strRet[1].equals("void"))
        strRet[0]="true";
      else
        strRet[0]="false";
*/
    }

//    blnContainer0.setBln(blnContainer.getBln());

    return strRet;
  }
}