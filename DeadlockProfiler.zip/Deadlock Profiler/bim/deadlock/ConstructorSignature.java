package bim.deadlock;

import java.util.Vector;
import java.io.Serializable;

class ConstructorSignature
implements Serializable {
  String strClassName;
  Vector vecParameters=new Vector(); //contains FieldObjects

  ConstructorSignature(String strClassName, Vector vecParameters) {
    this.strClassName=strClassName;
    this.vecParameters=vecParameters;
  }

  public String getClassName() {
    return strClassName;
  }

  public void setClassName(String strClassName) {
    this.strClassName=strClassName;
  }

  public Vector getParameters() {
    return vecParameters;
  }

  public void setParameters(Vector vecParameters) {
    this.vecParameters=vecParameters;
  }

  public boolean equals(Object obj) {
//System.out.println("checking equals");

    ConstructorSignature sign=(ConstructorSignature)obj;

    if(!strClassName.equals(sign.strClassName))
      return false;

    Vector vecParameters2=sign.getParameters();

    if(vecParameters.size()!=vecParameters2.size())
      return false;

    for(int i=0;i<vecParameters.size();i++) {
      FieldObject nextFO=(FieldObject)vecParameters.elementAt(i);
      FieldObject nextFO2=(FieldObject)vecParameters2.elementAt(i);

      if(!nextFO.strClassName.equals(nextFO2.strClassName))
        return false;

//      if(!nextFO.equals(nextFO2))
//        return false;
    }

//System.out.println("checking equals2:"+vecParameters.size());

    return true;
  }

  public int hashCode() {
    return 0;
  }

  public String toString() {
    String strRet=strClassName+":";

    for(int i=0;i<vecParameters.size();i++) {
      FieldObject nextField=(FieldObject)vecParameters.elementAt(i);
      strRet+=nextField.getClassName()+",";
    }

    if(vecParameters.size()>0)
      strRet=strRet.substring(0, strRet.length()-1);

    return strRet;
  }
}