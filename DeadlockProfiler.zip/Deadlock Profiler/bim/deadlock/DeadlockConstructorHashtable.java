package bim.deadlock;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Map;
import java.util.Iterator;
import java.io.Serializable;

class DeadlockConstructorHashtable extends Hashtable
implements Serializable {

  DeadlockConstructorHashtable() {
    super();
  }

  public Object get(Object obj) {
    Object retObj=super.get(obj);

//printAllConstructors();

    if(retObj==null) {
      ConstructorSignature cSign=(ConstructorSignature)obj;

      Vector vecParameters=cSign.getParameters();

      if(vecParameters.size()==0)
        return null;

      Vector vecParametersAll=new Vector();

      for(int i=0;i<vecParameters.size();i++) {
        FieldObject fObj=(FieldObject)vecParameters.elementAt(i);

        if(fObj.getClassName().equals("null")) {
          Vector vecParametersAllNext=new Vector();

          Iterator iter0=entrySet().iterator();
          while(iter0.hasNext()) {
            Map.Entry mEntry=(Map.Entry)iter0.next();
            ConstructorSignature cSignNext=(ConstructorSignature)mEntry.getKey();
            Vector vecParametersNextZ=cSignNext.getParameters();
            if(vecParameters.size()==vecParametersNextZ.size())
              vecParametersAllNext.addElement(vecParametersNextZ.elementAt(i));
          }

          vecParametersAll.addElement(vecParametersAllNext);
        }
        else {
          Vector vecParametersAllNext=FieldObject.getParametersAll(fObj);

          vecParametersAll.addElement(vecParametersAllNext);
        }
      }

      Vector vecParametersNext=new Vector();
      for(int i=0;i<vecParameters.size();i++)
        vecParametersNext.addElement(new FieldObject(""));

      ConstructorObject cObj=getConstructorObject(cSign.getClassName(), vecParametersNext, 0, vecParametersAll);

      retObj=cObj;

    }

//printAllConstructors();

    return retObj;
  }

  public ConstructorObject getConstructorObject(String strClassName, Vector vecParametersNext, int intIndex, Vector vecParametersAll) {
    ConstructorObject retCObj=null;

    Vector vecParametersAllNext=(Vector)vecParametersAll.elementAt(intIndex);

    int intNumberOfParameters=vecParametersAllNext.size();

    for(int i=0;i<intNumberOfParameters;i++) {
      FieldObject nextField=(FieldObject)vecParametersAllNext.elementAt(i);

      vecParametersNext.setElementAt(nextField, intIndex);

      if(intIndex==(vecParametersAll.size()-1)) {
        retCObj=(ConstructorObject)super.get(new ConstructorSignature(strClassName, vecParametersNext));

        if(retCObj!=null)
          return retCObj;
      }
      else {
        retCObj=getConstructorObject(strClassName, vecParametersNext, intIndex+1, vecParametersAll);

        if(retCObj!=null)
          return retCObj;
      }
    }

    return retCObj;
  }

/*
public void printAllConstructors() {
System.out.println("constructors");
Iterator iter0=entrySet().iterator();
while(iter0.hasNext()) {
Map.Entry mEntry=(Map.Entry)iter0.next();
ConstructorSignature cSign=(ConstructorSignature)mEntry.getKey();
System.out.println(cSign);
}
System.out.println("constructorsend");
}
*/
}