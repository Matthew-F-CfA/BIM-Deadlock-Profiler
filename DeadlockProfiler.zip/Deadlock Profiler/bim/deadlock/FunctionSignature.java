package bim.deadlock;

import java.util.Vector;
import java.io.Serializable;

class FunctionSignature
implements Serializable {
  String strClassName;
  String strFunctionName;
  Vector vecParameters=new Vector(); //contains FieldObjects

  FunctionSignature(String strClassName, String strFunctionName, Vector vecParameters) {
    this.strClassName=strClassName;
    this.strFunctionName=strFunctionName;
    this.vecParameters=vecParameters;
  }

  public String getClassName() {
    return strClassName;
  }

  public void setClassName(String strClassName) {
    this.strClassName=strClassName;
  }

  public String getFunctionName() {
    return strFunctionName;
  }

  public void setFunctionName(String strFunctionName) {
    this.strFunctionName=strFunctionName;
  }

  public Vector getParameters() {
    return vecParameters;
  }

  public void setParameters(Vector vecParameters) {
    this.vecParameters=vecParameters;
  }

  public boolean equals(Object obj) {
    FunctionSignature sign=(FunctionSignature)obj;

    if(!strClassName.equals(sign.strClassName))
      return false;

    if(!strFunctionName.equals(sign.strFunctionName))
      return false;

    Vector vecParameters2=sign.getParameters();

    if(vecParameters.size()!=vecParameters2.size())
      return false;

    for(int i=0;i<vecParameters.size();i++) {
      FieldObject nextFO=(FieldObject)vecParameters.elementAt(i);
      FieldObject nextFO2=(FieldObject)vecParameters2.elementAt(i);

      if(!nextFO.strClassName.equals(nextFO2.strClassName))
        return false;

//      if(!nextFO.equals(nextFO2))
//        return false;
    }

    return true;
  }

  public int hashCode() {
    return 0;
  }

  public String toString() {
    String strRet=strClassName+":"+strFunctionName+":";

    for(int i=0;i<vecParameters.size();i++) {
      FieldObject nextField=(FieldObject)vecParameters.elementAt(i);
//System.out.println("toString:\""+nextField.getClassName()+"\"");
      strRet+=nextField.getClassName()+",";
    }

    if(vecParameters.size()>0)
      strRet=strRet.substring(0, strRet.length()-1);

    return strRet;
  }
}