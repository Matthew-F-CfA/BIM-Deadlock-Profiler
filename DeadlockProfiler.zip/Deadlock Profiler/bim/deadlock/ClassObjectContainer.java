package bim.deadlock;

class ClassObjectContainer {
  ClassObject classObj;

  ClassObjectContainer() {
  }

  ClassObjectContainer(ClassObject classObj) {
    this.classObj=classObj;
  }

  public ClassObject getClassObject() {
    return classObj;
  }

  public void setClassObject(ClassObject classObj) {
    this.classObj=classObj;
  }
}