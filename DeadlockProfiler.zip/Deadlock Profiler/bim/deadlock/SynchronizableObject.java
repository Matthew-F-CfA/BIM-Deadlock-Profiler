package bim.deadlock;

import java.util.Vector;
import java.io.Serializable;

class SynchronizableObject
implements Serializable {
  SynchronizableKey key;
  Vector vecHigherPriority=new Vector(); //Elements are SynchronizableObject
  Vector vecLowerPriority=new Vector(); //Elements are SynchronizableObject

  SynchronizableObject(SynchronizableKey key) {
    this.key=key;
  }

  public SynchronizableKey getKey() {
    return key;
  }

  public void setKey(SynchronizableKey key) {
    this.key=key;
  }

  public Vector getHigherPriority() {
    return vecHigherPriority;
  }

  public void setHigherPriority(Vector vecHigherPriority) {
    this.vecHigherPriority=vecHigherPriority;
  }

  public Vector getLowerPriority() {
    return vecLowerPriority;
  }

  public void setLowerPriority(Vector vecLowerPriority) {
    this.vecLowerPriority=vecLowerPriority;
  }

  public boolean equals(Object obj) {
    SynchronizableObject syncObj=(SynchronizableObject)obj;

    if(syncObj.key.equals(key))
      return true;

    return false;
  }

  public int hashCode() {
    return 0;
  }
}