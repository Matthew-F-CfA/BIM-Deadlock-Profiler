package bim.deadlock;

import java.util.Vector;
import java.io.Serializable;

class FieldObject
implements Serializable {
  String strFieldName;
  String strClassName;
  String strContainerClassName="";
  Boolean blnIsLocal=new Boolean(true);

  FieldObject(String strClassName) {
    this.strClassName=strClassName;
    blnIsLocal=new Boolean(true);
  }

  FieldObject(String strFieldName, String strClassName) {
    this.strFieldName=strFieldName;
    this.strClassName=strClassName;
    blnIsLocal=new Boolean(true);
  }

  FieldObject(String strFieldName, String strClassName, String strContainerClassName) {
    this.strFieldName=strFieldName;
    this.strClassName=strClassName;
    this.strContainerClassName=strContainerClassName;
    blnIsLocal=new Boolean(false);
  }

  public String getFieldName() {
    return strFieldName;
  }

  public void setFieldName(String strFieldName) {
    this.strFieldName=strFieldName;
  }

  public String getClassName() {
    return strClassName;
  }

  public void setClassName(String strClassName) {
    this.strClassName=strClassName;
  }

  public String getContainerClassName() {
    return strContainerClassName;
  }

  public void setContainerClassName(String strContainerClassName) {
    this.strContainerClassName=strContainerClassName;
  }

  public int getArrayDimensions() {
//System.out.println("getArrayDimensions: "+strFieldName);
    int intDimensions=0;

    int intIndex=strClassName.length()-2;
    while(true) {
      if(intIndex<0)
        break;

      if(strClassName.substring(intIndex, intIndex+2).equals("[]")) {
        ++intDimensions;

        intIndex-=2;

        continue;
      }

      break;
    }

    return intDimensions;
  }

  public static boolean hasArrayLength(String strOperand, FieldObject fieldObj) {
//System.out.println("hasArrayLength:"+strOperand);
    int intArrDimensions=fieldObj.getArrayDimensions();

    if(intArrDimensions==0)
      return false;

    int intBracketCount=0;

    int intIndex=strOperand.indexOf('[');

    if(intIndex==-1)
      return true;

    do {
      ++intBracketCount;

      intIndex+=1;

      int intBracketCount2=1;
      while(true) {
        char chr=strOperand.charAt(intIndex);

        if(chr=='[') {
          ++intBracketCount2;
        }
        else if(chr==']') {
          --intBracketCount2;

          if(intBracketCount2==0)
            break;
        }

        ++intIndex;
      }

      ++intIndex;

      if(intIndex==strOperand.length())
        break;

      if(strOperand.charAt(intIndex)!='[')
        break;

    } while(true);

    if(intBracketCount<intArrDimensions)
      return true;

    return false;
  }

  public static String getFieldName(String strOperand) {
    int intIndex=strOperand.indexOf('[');

    if(intIndex==-1)
      return strOperand;

    strOperand=strOperand.substring(0, intIndex);

    return strOperand;
  }

  public static String getClassName(String strOperand, FieldObject fieldObj) {
//System.out.println("strClassName: "+strOperand);
    boolean blnHasArrayLength=FieldObject.hasArrayLength(strOperand, fieldObj);

    if(!blnHasArrayLength) {
      String strFieldClass=fieldObj.getClassName();

      return FieldObject.getFieldName(strFieldClass);
    }

    int intArrayDimensionCount=fieldObj.getArrayDimensions();

    int intArrayDimensions=FieldObject.getArrayDimensions(strOperand);

    int intArrayDimensionsDifference=intArrayDimensionCount-intArrayDimensions;

    String strFieldClass=fieldObj.getClassName();

    strFieldClass=FieldObject.getFieldName(strFieldClass);

    for(int i=0;i<intArrayDimensionsDifference;i++)
      strFieldClass+="[]";

    return strFieldClass;
  }

  public static int getArrayDimensions(String strOperand) {
    int intBracketCount=0;

    int intIndex=strOperand.indexOf('[');

    if(intIndex==-1)
      return 0;

    do {
      ++intBracketCount;

      intIndex+=1;

      int intBracketCount2=1;
      while(true) {
        char chr=strOperand.charAt(intIndex);

        if(chr=='[') {
          ++intBracketCount2;
        }
        else if(chr==']') {
          --intBracketCount2;

          if(intBracketCount2==0)
            break;
        }

        ++intIndex;
      }

      ++intIndex;

      if(intIndex>=strOperand.length() || strOperand.charAt(intIndex)!='[')
        break;

    } while(true);

    return intBracketCount;
  }

  public static Vector getParametersAll(FieldObject fObj) {
    Vector retVec=new Vector();

    retVec.addElement(fObj);

    String strClassName=fObj.getClassName();

//System.out.println(fObj.toString());
    if(strClassName.indexOf('[')!=-1) {
      retVec.addElement(new FieldObject("java.lang.Object"));
    }
    else if(strClassName.equals("boolean")) {
    }
    else if(strClassName.equals("char")) {
      retVec.addElement(new FieldObject("int"));
      retVec.addElement(new FieldObject("float"));
      retVec.addElement(new FieldObject("long"));
      retVec.addElement(new FieldObject("double"));
    }
    else if(strClassName.equals("byte")) {
      retVec.addElement(new FieldObject("short"));
      retVec.addElement(new FieldObject("int"));
      retVec.addElement(new FieldObject("float"));
      retVec.addElement(new FieldObject("long"));
      retVec.addElement(new FieldObject("double"));
    }
    else if(strClassName.equals("short")) {
      retVec.addElement(new FieldObject("int"));
      retVec.addElement(new FieldObject("float"));
      retVec.addElement(new FieldObject("long"));
      retVec.addElement(new FieldObject("double"));
    }
    else if(strClassName.equals("int")) {
      retVec.addElement(new FieldObject("float"));
      retVec.addElement(new FieldObject("long"));
      retVec.addElement(new FieldObject("double"));
    }
    else if(strClassName.equals("float")) {
      retVec.addElement(new FieldObject("double"));
    }
    else if(strClassName.equals("long")) {
      retVec.addElement(new FieldObject("double"));
    }
    else if(strClassName.equals("double")) {
    }
    else {
      try {
        Class classObj=Class.forName(strClassName);

        while(true) {
          Class interfaces[]=classObj.getInterfaces();

          for(int i=0;i<interfaces.length;i++)
            retVec.addElement(new FieldObject(interfaces[i].getName()));

          classObj=classObj.getSuperclass();

          if(classObj==null)
            break;

          retVec.addElement(new FieldObject(classObj.getName()));
        }
      }
      catch(Exception ex) {
      }
    }

    return retVec;
  }

  public static String convertFromBuiltInClassToDeadlockProfilerClass(String strStr) {
    if(strStr.equals("boolean"))
      return "boolean";
    else if(strStr.equals("char"))
      return "char";
    else if(strStr.equals("byte"))
      return "byte";
    else if(strStr.equals("short"))
      return "short";
    else if(strStr.equals("int"))
      return "int";
    else if(strStr.equals("float"))
      return "float";
    else if(strStr.equals("long"))
      return "long";
    else if(strStr.equals("double"))
      return "double";

    if(strStr.startsWith("[")) {
      int intLastBracketIndex=strStr.lastIndexOf("[");

      int intArrayDimensions=intLastBracketIndex+1;

      String strClassName=strStr.substring(intLastBracketIndex+1);

      if(strClassName.endsWith(";")) {
        strClassName=strClassName.substring(0, strClassName.length()-1);

        for(int i=0;i<intArrayDimensions;i++)
          strClassName+="[]";

        return strClassName;
      }
      else {
        if(strClassName.equals("Z"))
          strClassName="boolean";
        else if(strClassName.equals("C"))
          strClassName="char";
        else if(strClassName.equals("B"))
          strClassName="byte";
        else if(strClassName.equals("S"))
          strClassName="short";
        else if(strClassName.equals("I"))
          strClassName="int";
        else if(strClassName.equals("F"))
          strClassName="float";
        else if(strClassName.equals("J"))
          strClassName="long";
        else if(strClassName.equals("D"))
          strClassName="double";

        for(int i=0;i<intArrayDimensions;i++)
          strClassName+="[]";

        return strClassName;
      }
    }

    return strStr;
  }

  public boolean equals(Object obj) {
    FieldObject field=(FieldObject)obj;

    if(strFieldName==null) {
      if(field.strFieldName==null) {
      }
      else {
        return false;
      }
    }
    else {
      if(field.strFieldName==null) {
        return false;
      }
      else {
        if(!strFieldName.equals(field.strFieldName))
          return false;
      }
    }

    if(!strClassName.equals(field.strClassName))
      return false;

    if(!strContainerClassName.equals(field.strContainerClassName))
      return false;

/*
    if(strContainerClassName==null) {
      if(field.strContainerClassName==null) {
      }
      else {
        return false;
      }
    }
    else {
      if(field.strContainerClassName==null) {
        return false;
      }
      else {
        if(!strContainerClassName.equals(field.strContainerClassName))
          return false;
      }
    }
*/

    if(blnIsLocal.booleanValue()!=field.blnIsLocal.booleanValue())
      return false;

    return true;
  }

  public int hashCode() {
    return 0;
  }

  public String toString() {
    String strStr=strClassName;
    if(strFieldName==null)
      strStr+=",";
    else
      strStr+=","+strFieldName;
    if(strContainerClassName==null)
      strStr+=",";
    else
      strStr+=","+strContainerClassName;
    strStr+=","+String.valueOf(blnIsLocal);

    return strStr;
  }
}