package bim.deadlock;

import java.io.Serializable;

class SynchronizableMarker
implements Serializable {
  String strFilePath;
  Integer intAbsoluteLineNumber=new Integer(-1);

  SynchronizableMarker(String strFilePath, int intAbsoluteLineNumber) {
    this.strFilePath=strFilePath;
    this.intAbsoluteLineNumber=new Integer(intAbsoluteLineNumber);
  }

  public String getFilePath() {
    return strFilePath;
  }

  public void setFilePath(String strFilePath) {
    this.strFilePath=strFilePath;
  }

  public int getAbsoluteLineNumber() {
    return intAbsoluteLineNumber.intValue();
  }

  public void setAbsoluteLineNumber(int intAbsoluteLineNumber) {
    this.intAbsoluteLineNumber=new Integer(intAbsoluteLineNumber);
  }
}