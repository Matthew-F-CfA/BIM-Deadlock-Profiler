package bim.deadlock;

import java.util.Vector;
import java.io.Serializable;

class EnumObject
implements Serializable {
  String strEnumName;
  Vector vecEnumValues=new Vector();

  EnumObject(String strEnumName, Vector vecEnumValues) {
    this.strEnumName=strEnumName;
    this.vecEnumValues=vecEnumValues;
  }

  public String getEnumName() {
    return strEnumName;
  }

  public void setEnumName(String strEnumName) {
    this.strEnumName=strEnumName;
  }

  public Vector getEnumValues() {
    return vecEnumValues;
  }

  public void setEnumValues(Vector vecEnumValues) {
    this.vecEnumValues=vecEnumValues;
  }
}