package bim.deadlock;

import java.io.Serializable;

class SynchronizableKey
implements Serializable {
  String strClassName;
  String strFieldName;

  SynchronizableKey(String strFieldName) {
    this.strFieldName=strFieldName;
  }

  SynchronizableKey(String strClassName, String strFieldName) {
    this.strClassName=strClassName;
    this.strFieldName=strFieldName;
  }

  public String getClassName() {
    return strClassName;
  }

  public void setClassName(String strClassName) {
    this.strClassName=strClassName;
  }

  public String getFieldName() {
    return strFieldName;
  }

  public void setFieldName(String strFieldName) {
    this.strFieldName=strFieldName;
  }

  public boolean equals(Object obj) {
    SynchronizableKey key=(SynchronizableKey)obj;

    if(strClassName==null) {
      if(key.strClassName==null) {
        if(strFieldName.equals(key.strFieldName))
          return true;
      }
      else {
      }
    }
    else {
      if(key.strClassName==null) {
      }
      else {
        if(strClassName.equals(key.strClassName) && strFieldName.equals(key.strFieldName))
          return true;
      }
    }

    return false;
  }

  public int hashCode() {
    return 0;
  }
}