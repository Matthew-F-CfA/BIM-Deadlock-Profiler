package bim.deadlock;

import java.util.Comparator;

class PrintOutStringLongComparator
implements Comparator {

  public int compare(Object obj, Object obj2) {
    PrintOutStringLong pOSI=(PrintOutStringLong)obj;
    PrintOutStringLong pOSI2=(PrintOutStringLong)obj2;

    if(pOSI.getLong()<pOSI2.getLong())
      return -1;
    else if(pOSI.getLong()>pOSI2.getLong())
      return 1;

    return 0;
  }

  public boolean equals(Object obj) {
    return false;
  }
}