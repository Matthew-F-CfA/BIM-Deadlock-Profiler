package bim.deadlock;

class StaticInitializerObject {
  String strClassName;
  String strInstructions[]=new String[0];
  int intAbsoluteLineNumber=-1;

  StaticInitializerObject(String strClassName, String strInstructions[], int intAbsoluteLineNumber) {
    this.strClassName=strClassName;
    this.strInstructions=strInstructions;
    this.intAbsoluteLineNumber=intAbsoluteLineNumber;
  }

  public String getClassName() {
    return strClassName;
  }

  public void setClassName(String strClassName) {
    this.strClassName=strClassName;
  }

  public String[] getInstructions() {
    return strInstructions;
  }

  public void setInstructions(String strInstructions[]) {
    this.strInstructions=strInstructions;
  }

  public int getAbsoluteLineNumber() {
    return intAbsoluteLineNumber;
  }

  public void setAbsoluteLineNumber(int intAbsoluteLineNumber) {
    this.intAbsoluteLineNumber=intAbsoluteLineNumber;
  }
}