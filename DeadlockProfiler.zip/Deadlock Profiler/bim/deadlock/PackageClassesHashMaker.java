package bim.deadlock;

import java.io.*;
import java.util.*;

class PackageClassesHashMaker {
  static Hashtable hashPackages=new Hashtable();

  public static void main(String args[]) {
    try {
      if(args.length==0) {
        System.out.println("Usage:");
        System.out.println("  bim.deadlock.PackageClassesHashMaker <absolute path to javadocs api folder>");
        System.out.println("For example: If the javadocs folder \"api\" is located at \"c:\\java\\api\" then use:");
        System.out.println("java bim.deadlock.PackageClassesHashMaker c:\\java\\api");

        return;
      }

      String fSep=System.getProperty("file.separator");

      String strJava=args[0]+fSep+"java";

      appendHashtable(strJava, "");

      String strJavax=args[0]+fSep+"javax";

      appendHashtable(strJavax, "");

      ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(new File("builtInPackageClasses")));
      oos.writeObject(hashPackages);
      oos.close();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  PackageClassesHashMaker() {
  }

  public static void appendHashtable(String strFilePath, String strPackage) throws Exception {
    File fileDir=new File(strFilePath);

    String strFileName=fileDir.getName();

    String strPackage0=strPackage;
    strPackage0+=strFileName;
    strPackage0+=".";

    strPackage+=strFileName+".*";

    Vector vecClasses=new Vector();

    hashPackages.put(strPackage, vecClasses);

    File fileFiles[]=fileDir.listFiles();
    for(int i=0;i<fileFiles.length;i++) {
      if(fileFiles[i].isDirectory())
        appendHashtable(fileFiles[i].getAbsolutePath(), strPackage.substring(0, strPackage.length()-1));
      else {
        String strName=fileFiles[i].getName();
        strName=strName.substring(0, strName.lastIndexOf('.'));
        strName=strName.replace(".", "$");
        vecClasses.addElement(strPackage0+strName);
      }
    }
  }
}