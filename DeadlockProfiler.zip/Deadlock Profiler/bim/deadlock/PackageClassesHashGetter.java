package bim.deadlock;

import java.io.*;
import java.util.*;

class PackageClassesHashGetter {

  public static void main(String args[]) {
    try {
      ObjectInputStream ois=new ObjectInputStream(new FileInputStream(new File("builtInPackageClasses")));
      Hashtable hashPackages=(Hashtable)ois.readObject();
      ois.close();

      Vector vecClasses=(Vector)hashPackages.get(args[0]);
      for(int i=0;i<vecClasses.size();i++)
        System.out.println(vecClasses.elementAt(i));
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  PackageClassesHashGetter() {
  }
}