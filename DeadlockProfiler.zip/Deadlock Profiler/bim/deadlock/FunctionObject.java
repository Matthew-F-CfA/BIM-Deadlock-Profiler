package bim.deadlock;

import java.util.Vector;
import java.io.Serializable;

class FunctionObject
implements Serializable {
  FunctionSignature signature;
  Vector vecFunctionParameters=new Vector();
  String strReturnClassName;
  String strInstructions[]=new String[0];
  Integer intAbsoluteLineNumber=new Integer(-1);
  String strContainerClassName;

  FunctionObject(FunctionSignature signature, Vector vecFunctionParameters, String strReturnClassName, String strInstructions[], int intAbsoluteLineNumber, String strContainerClassName) throws Exception {
    this.signature=signature;
    this.vecFunctionParameters=vecFunctionParameters;
    this.strReturnClassName=strReturnClassName;
    this.strInstructions=strInstructions;
//if(strInstructions==null) {
//System.out.println(signature.getClassName());
//throw new Exception("");
//}
    this.intAbsoluteLineNumber=new Integer(intAbsoluteLineNumber);
    this.strContainerClassName=strContainerClassName;
  }

  public FunctionSignature getSignature() {
    return signature;
  }

  public void setSignature(FunctionSignature signature) {
    this.signature=signature;
  }

  public String getFunctionName() {
    return signature.getFunctionName();
  }

  public void setFunctionName(String strFunctionName) {
    signature.setFunctionName(strFunctionName);
  }

  public Vector getParameters() {
    return signature.getParameters();
  }

  public void setParameters(Vector vecParameters) {
    signature.setParameters(vecParameters);
  }

  public Vector getFunctionParameters() {
    return VectorClone.cloneV(vecFunctionParameters);
  }

  public void setFunctionParameters(Vector vecFunctionParameters) {
    this.vecFunctionParameters=vecFunctionParameters;
  }

  public String getReturnClassName() {
    return strReturnClassName;
  }

  public void setReturnClassName(String strReturnClassName) {
    this.strReturnClassName=strReturnClassName;
  }

  public String[] getInstructions() {
    return strInstructions;
  }

  public void setInstructions(String strInstructions[]) {
    this.strInstructions=strInstructions;
  }

  public int getAbsoluteLineNumber() {
    return intAbsoluteLineNumber.intValue();
  }

  public void setAbsoluteLineNumber(int intAbsoluteLineNumber) {
    this.intAbsoluteLineNumber=new Integer(intAbsoluteLineNumber);
  }

  public String getContainerClassName() {
    return strContainerClassName;
  }

  public void setContainerClassName(String strContainerClassName) {
    this.strContainerClassName=strContainerClassName;
  }

  public String getFilePath() {
    return ((ClassObject)DeadlockExecutor.hashClasses.get(strContainerClassName)).getFilePath();
  }
}