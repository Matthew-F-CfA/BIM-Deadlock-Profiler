package bim.deadlock;

import java.util.Comparator;

class PrintOutStringIntComparator
implements Comparator {

  public int compare(Object obj, Object obj2) {
    PrintOutStringInt pOSI=(PrintOutStringInt)obj;
    PrintOutStringInt pOSI2=(PrintOutStringInt)obj2;

    if(pOSI.getInt()<pOSI2.getInt())
      return -1;
    else if(pOSI.getInt()>pOSI2.getInt())
      return 1;

    return 0;
  }

  public boolean equals(Object obj) {
    return false;
  }
}