package bim.deadlock;

import java.io.*;
import java.util.*;

class PackageClassesHashMakerAppend {
  static Hashtable hashPackages=new Hashtable();

  public static void main(String args[]) {
    try {
      if(args.length==0) {
        System.out.println("Usage:");
        System.out.println("  bim.deadlock.PackageClassesHashMakerAppend <absolute path to javadocs folder>");
        System.out.println("For example: If the javadocs folder \"java\\io\" is located at \"c:\\java\\io\" then use:");
        System.out.println("java bim.deadlock.PackageClassesHashMakerAppend c:\\java");
        System.out.println("Executing this command will iterate through all the folders in \"c:\\java\" and add them as packages.");

        return;
      }

      ObjectInputStream ois=new ObjectInputStream(new FileInputStream(new File("builtInPackageClasses")));
      hashPackages=(Hashtable)ois.readObject();
      ois.close();

//      String fSep=System.getProperty("file.separator");

      String strJava=args[0];

      appendHashtable(strJava, "");

      ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(new File("builtInPackageClasses")));
      oos.writeObject(hashPackages);
      oos.close();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  PackageClassesHashMakerAppend() {
  }

  public static void appendHashtable(String strFilePath, String strPackage) throws Exception {
    File fileDir=new File(strFilePath);

    String strFileName=fileDir.getName();

    String strPackage0=strPackage;
    strPackage0+=strFileName;
    strPackage0+=".";

    strPackage+=strFileName+".*";

    Vector vecClasses=new Vector();

    hashPackages.put(strPackage, vecClasses);

    File fileFiles[]=fileDir.listFiles();
    for(int i=0;i<fileFiles.length;i++) {
      if(fileFiles[i].isDirectory())
        appendHashtable(fileFiles[i].getAbsolutePath(), strPackage.substring(0, strPackage.length()-1));
      else {
        String strName=fileFiles[i].getName();
        strName=strName.substring(0, strName.lastIndexOf('.'));
        strName=strName.replace(".", "$");
        vecClasses.addElement(strPackage0+strName);
      }
    }
  }
}