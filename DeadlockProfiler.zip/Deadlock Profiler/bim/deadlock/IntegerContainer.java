package bim.deadlock;

class IntegerContainer {
  int intInt=-1;

  IntegerContainer() {
  }

  IntegerContainer(int intInt) {
    this.intInt=intInt;
  }

  public int getInt() {
    return intInt;
  }

  public void setInt(int intInt) {
    this.intInt=intInt;
  }
}