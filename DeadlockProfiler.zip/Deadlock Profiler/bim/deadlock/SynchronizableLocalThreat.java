package bim.deadlock;

import java.io.Serializable;

class SynchronizableLocalThreat
implements Serializable {
  SynchronizableMarker syncMarker;
  SynchronizableKey syncKey;

  SynchronizableLocalThreat(SynchronizableMarker syncMarker, SynchronizableKey syncKey) {
    this.syncMarker=syncMarker;
    this.syncKey=syncKey;
  }

  public SynchronizableMarker getMarker() {
    return syncMarker;
  }

  public void setMarker(SynchronizableMarker syncMarker) {
    this.syncMarker=syncMarker;
  }

  public SynchronizableKey getKey() {
    return syncKey;
  }

  public void setKey(SynchronizableKey syncKey) {
    this.syncKey=syncKey;
  }

  public boolean equals(Object obj) {
    SynchronizableLocalThreat syncLT=(SynchronizableLocalThreat)obj;

    if(!syncMarker.strFilePath.equals(syncLT.syncMarker.strFilePath))
      return false;

    if(syncMarker.intAbsoluteLineNumber.intValue()!=syncLT.syncMarker.intAbsoluteLineNumber.intValue())
      return false;

    if(!syncKey.strClassName.equals(syncLT.syncKey.strClassName))
      return false;

    if(!syncKey.strFieldName.equals(syncLT.syncKey.strFieldName))
      return false;

    return true;
  }

  public int hashCode() {
    return 0;
  }
}