package bim.deadlock;

import java.io.Serializable;
import java.util.Hashtable;

class BraceInfoObject
implements Serializable {
  Hashtable hashBraceSynchronized=new Hashtable(); //Keys are Integer curly brace index and Values are SynchronizableObject
  Hashtable hashBraceMarker=new Hashtable(); //Keys are Integer curly brace index and Values are SynchronizableMarker

  BraceInfoObject(Hashtable hashBraceSynchronized, Hashtable hashBraceMarker) {
    this.hashBraceSynchronized=hashBraceSynchronized;
    this.hashBraceMarker=hashBraceMarker;
  }

  public Hashtable getBraceSynchronized() {
    return hashBraceSynchronized;
  }

  public void setBraceSynchronized(Hashtable hashBraceSynchronized) {
    this.hashBraceSynchronized=hashBraceSynchronized;
  }

  public Hashtable getBraceMarker() {
    return hashBraceMarker;
  }

  public void setBraceMarker(Hashtable hashBraceMarker) {
    this.hashBraceMarker=hashBraceMarker;
  }
}