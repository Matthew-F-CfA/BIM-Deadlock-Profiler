package bim.deadlock;

class BufferedReaderArray {
  String strLines[]=new String[0];
  int intIndex=0;

  BufferedReaderArray(String strLines[]) {
    this.strLines=strLines;
  }

  public String readLine() {
    if(intIndex==strLines.length)
      return null;

    ++intIndex;

    return strLines[intIndex-1];
  }

  public void pushLine() {
    --intIndex;
  }

  public boolean isAtEnd() {
    if(intIndex==strLines.length)
      return true;

    return false;
  }
}