package bim.deadlock;

import java.util.Vector;
import java.io.Serializable;

class ConstructorObject
implements Serializable {
  ConstructorSignature signature;
  Vector vecConstructorParameters=new Vector();
  String strInstructions[]=new String[0];
  Integer intAbsoluteLineNumber=new Integer(-1);
  String strContainerClassName;

  ConstructorObject(ConstructorSignature signature, Vector vecConstructorParameters, String strInstructions[], int intAbsoluteLineNumber, String strContainerClassName) throws Exception {
    this.signature=signature;
    this.vecConstructorParameters=vecConstructorParameters;
    this.strInstructions=strInstructions;
//if(strInstructions==null) {
//System.out.println(signature.getClassName());
//throw new Exception("");
//}
    this.intAbsoluteLineNumber=new Integer(intAbsoluteLineNumber);
    this.strContainerClassName=strContainerClassName;
  }

  public ConstructorSignature getSignature() {
    return signature;
  }

  public void setSignature(ConstructorSignature signature) {
    this.signature=signature;
  }

  public Vector getConstructorParameters() {
    return VectorClone.cloneV(vecConstructorParameters);
  }

  public void setConstructorParameters(Vector vecConstructorParameters) {
    this.vecConstructorParameters=vecConstructorParameters;
  }

  public String[] getInstructions() {
    return strInstructions;
  }

  public void setInstructions(String strInstructions[]) {
    this.strInstructions=strInstructions;
  }

  public int getAbsoluteLineNumber() {
    return intAbsoluteLineNumber.intValue();
  }

  public void setAbsoluteLineNumber(int intAbsoluteLineNumber) {
    this.intAbsoluteLineNumber=new Integer(intAbsoluteLineNumber);
  }

  public String getContainerClassName() {
    return strContainerClassName;
  }

  public void setContainerClassName(String strContainerClassName) {
    this.strContainerClassName=strContainerClassName;
  }

  public String getFilePath() {
    return ((ClassObject)DeadlockExecutor.hashClasses.get(strContainerClassName)).getFilePath();
  }
}