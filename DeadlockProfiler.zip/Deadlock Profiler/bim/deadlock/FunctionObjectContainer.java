package bim.deadlock;

class FunctionObjectContainer {
  FunctionObject functionObj;

  FunctionObjectContainer() {
  }

  FunctionObjectContainer(FunctionObject functionObj) {
    this.functionObj=functionObj;
  }

  public FunctionObject getFunctionObject() {
    return functionObj;
  }

  public void setFunctionObject(FunctionObject functionObj) {
    this.functionObj=functionObj;
  }
}