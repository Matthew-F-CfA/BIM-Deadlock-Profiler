package bim.deadlock;

import java.util.Hashtable;
import java.util.Map;
import java.util.Iterator;
import java.util.Vector;
import java.io.Serializable;

class DeadlockFunctionHashtable extends Hashtable
implements Serializable {

  DeadlockFunctionHashtable() {
    super();
  }

  public Object get(Object obj) {
    Object retObj=super.get(obj);

    if(retObj==null) {
      FunctionSignature fSign=(FunctionSignature)obj;

//System.out.println("deadlockFunctionHashtable:functionSignature:"+fSign.toString());

      Vector vecParameters=fSign.getParameters();

      if(vecParameters.size()==0)
        return null;

      Vector vecParametersAll=new Vector();

      for(int i=0;i<vecParameters.size();i++) {
        FieldObject fObj=(FieldObject)vecParameters.elementAt(i);

        if(fObj.getClassName().equals("null")) {
          Vector vecParametersAllNext=new Vector();

          Iterator iter0=entrySet().iterator();
          while(iter0.hasNext()) {
            Map.Entry mEntry=(Map.Entry)iter0.next();
            FunctionSignature fSignNext=(FunctionSignature)mEntry.getKey();
            Vector vecParametersNextZ=fSignNext.getParameters();
            if(vecParameters.size()==vecParametersNextZ.size())
              vecParametersAllNext.addElement(vecParametersNextZ.elementAt(i));
          }

          vecParametersAll.addElement(vecParametersAllNext);
        }
        else {
          Vector vecParametersAllNext=FieldObject.getParametersAll(fObj);

          vecParametersAll.addElement(vecParametersAllNext);
        }
      }

      Vector vecParametersNext=new Vector();
      for(int i=0;i<vecParameters.size();i++)
        vecParametersNext.addElement(new FieldObject(""));

      FunctionObject fObj=getFunctionObject(fSign.getClassName(), fSign.getFunctionName(), vecParametersNext, 0, vecParametersAll);

      retObj=fObj;

    }

    return retObj;
  }

  public FunctionObject getFunctionObject(String strClassName, String strFunctionName, Vector vecParametersNext, int intIndex, Vector vecParametersAll) {
    FunctionObject retFObj=null;

    Vector vecParametersAllNext=(Vector)vecParametersAll.elementAt(intIndex);

    int intNumberOfParameters=vecParametersAllNext.size();

    for(int i=0;i<intNumberOfParameters;i++) {
      FieldObject nextField=(FieldObject)vecParametersAllNext.elementAt(i);

      vecParametersNext.setElementAt(nextField, intIndex);

      if(intIndex==(vecParametersAll.size()-1)) {
        retFObj=(FunctionObject)super.get(new FunctionSignature(strClassName, strFunctionName, vecParametersNext));

        if(retFObj!=null)
          return retFObj;
      }
      else {
        retFObj=getFunctionObject(strClassName, strFunctionName, vecParametersNext, intIndex+1, vecParametersAll);

        if(retFObj!=null)
          return retFObj;
      }
    }

    return retFObj;
  }
}