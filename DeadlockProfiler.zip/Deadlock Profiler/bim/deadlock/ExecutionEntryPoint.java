package bim.deadlock;

class ExecutionEntryPoint {
  String strClassName;
  FunctionSignature signature;
  boolean blnIsStatic=false;

  ExecutionEntryPoint(String strClassName, FunctionSignature signature, boolean blnIsStatic) {
    this.strClassName=strClassName;
    this.signature=signature;
    this.blnIsStatic=blnIsStatic;
  }

  public String getClassName() {
    return strClassName;
  }

  public void setClassName(String strClassName) {
    this.strClassName=strClassName;
  }

  public FunctionSignature getSignature() {
    return signature;
  }

  public void setSignature(FunctionSignature signature) {
    this.signature=signature;
  }

  public boolean isStatic() {
    return blnIsStatic;
  }

  public void setIsStatic(boolean blnIsStatic) {
    this.blnIsStatic=blnIsStatic;
  }
}